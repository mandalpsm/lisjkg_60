PROFREEHOST UPLOAD (Academic Research Explorer v22)
===================================================
Upload these THREE files together into the SAME folder, inside your domain's htdocs folder:

    htdocs/index.html        (~720 KB)
    htdocs/dataset-1.bin     (5.2 MB)
    htdocs/dataset-2.bin     (5.2 MB)

- Do NOT upload dist/index.html from the project: it is about 14.5 MB, and the host deletes HTML/JS/text files over 1 MB.
- Do NOT upload server/, Dockerfile or package.json: ProFreeHost cannot run Node.js. The front end does not call that server.
- With FTP (e.g. FileZilla) send the .bin files in BINARY mode (Transfer > Transfer type > Binary).
- After uploading, open your site and hard-refresh (Ctrl+F5).
- The map's real country borders download from a public CDN on the first online visit; offline you get outlines and markers.
