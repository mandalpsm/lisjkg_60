# Academic Research Explorer (v20)
Layout: `src/index.template.html` (page markup with placeholders), `src/css/*` and `src/js/*` (one file per original block, in page order; the `litreview-js` file is the Literature Review module), `data/embedded-dataset.txt` (compressed dataset), `scripts/build.js`, `server/server.js`.

    npm install
    npm start        # builds dist/index.html and serves http://localhost:3000
    npm run build    # only produces dist/index.html, a single file that also works offline

API: `GET /api/health`, `GET /api/dataset`, `GET|PUT|DELETE /api/drafts/:id`. The front end still reads its embedded data and localStorage, so the API is an optional back end for your own extensions.
Edit files under `src/`, then rebuild. To replace the dataset, put new `GZB64:`-prefixed or plain JSON `{m,r}` text in `data/embedded-dataset.txt`.


## Added modules
- `src/js/23-scholar-intel-js.js`: Semantic Layer tabs (Coverage, Global rankings, Top & identity, Profiles with scholar-controlled claims, Mentorship trees, Analytics, Ask (NL)). Exposes `window.X5`.
- `src/js/24-discovery-js.js`: Discovery search cards under the hero (Top Journals, Referee Finder, Trends, ORCID, Authors by name, DOI) and the Geographic map view inside the Knowledge Graph window.

## v22 fixes
- `src/js/25-geo-js.js`: Knowledge Graph geographic map rebuilt on a 250-entry country/territory registry (UN M49 regions and sub-regions), real country borders (Natural Earth via world-atlas, cached after first online load), zoom/pan, search, region views and per-country panels. Offline: outline plus a marker for every country.
- Diamond OA / LIS journal lists: article title click no longer throws (`x4Detail` is now exported); each article has a direct Knowledge Graph button; Back restores the results.
- Article detail pages now include a Knowledge graph button.
- ORCID: matching now requires shared DOIs/titles plus a compatible name (ORCID public API + OpenAlex); KG author nodes use resolved scholar identities, show verified ORCID, and can find and verify an ORCID.
