
/* ===== Mind Mapping + Semantic Layer + Linked Open Data (added; existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const st=document.createElement('style');st.textContent=`
.x3 .tabs{display:flex;gap:4px;flex-wrap:wrap;border-bottom:2px solid var(--brand);margin:8px 0 12px}
.x3 .tabs button{border:0;background:none;padding:8px 13px;border-radius:8px 8px 0 0;font-weight:700;color:var(--brand)}
.x3 .tabs button.on{background:var(--brand);color:#fff}
.x3 .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}
.x3 select,.x3 input[type=text],.x3 input[type=number],.x3 textarea{border:1px solid var(--line);border-radius:8px;padding:6px 8px;background:#fff;font:inherit}
.x3 textarea{width:100%;font-family:ui-monospace,Consolas,monospace;font-size:12px}
.x3 table{width:100%;border-collapse:collapse;font-size:12.5px}.x3 th,.x3 td{text-align:left;padding:6px;border-bottom:1px solid var(--line);vertical-align:top}
.x3 .chip{display:inline-block;border:1px solid var(--line);background:#f3f8fb;border-radius:999px;padding:2px 9px;font-size:12px;margin:2px;cursor:pointer}
.x3 .card{border:1px solid var(--line);border-radius:10px;padding:10px;margin:8px 0;background:#fff}
.x3 .mmwrap{display:grid;grid-template-columns:minmax(0,1fr) 250px;gap:10px}
.x3 .mmstage{border:1px solid var(--line);border-radius:10px;background:#fff;height:600px;overflow:hidden}
.x3 .mmstage svg{width:100%;height:100%;cursor:grab;touch-action:none}
.x3 .mmside{border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12.5px;max-height:600px;overflow:auto}
.x3 .mmside button{margin:2px}.x3 .bad{color:#b42318}.x3 .ok{color:var(--ok)}
.sample-header .toolbar #mmBtn{background:#e6f6ee!important;color:#0f6b46!important}
.sample-header .toolbar #semBtn{background:#eaf0fb!important;color:#1f4e8c!important}
.sample-header .toolbar #lodBtn{background:#fdeeee!important;color:#a12b2b!important}
@media(max-width:800px){.x3 .mmwrap{grid-template-columns:1fr}}`;
document.head.appendChild(st);

/* ---------- shared helpers ---------- */
const H=(t,b)=>{$('#modalCard').classList.add('x2-wide');showModal(`<div class="x3"><h2>${t}</h2>${b}</div>`)};
const SC=`<label>Scope <select id="x3n"><option>20</option><option selected>50</option><option>100</option><option>200</option><option>500</option></select> top results</label>`;
const hits=()=>{const n=+(Q('#x3n')?.value||50);let a=currentResults.map(h=>h.i).filter(i=>typeof i==='number');if(!a.length)a=[...Array(Math.min(n,R.length)).keys()];return a.slice(0,n)};
const slug=s=>norm(s).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'x';
const stem=s=>norm(s).replace(/\([^)]*\)/g,' ').replace(/[-_\/]/g,' ').replace(/[^a-z0-9 ]/g,'').split(/\s+/).filter(Boolean).map(w=>w.length>3?w.replace(/ies$/,'y').replace(/([^s])s$/,'$1'):w).join(' ');
function tabbed(title,names,render,start){let cur=start||names[0][0];H(title,`<div class="tabs">${names.map(([k,l])=>`<button data-t="${k}">${l}</button>`).join('')}</div><div id="x3b"></div>`);const go=k=>{cur=k;QA('.x3 .tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===k));render(k,Q('#x3b'))};QA('.x3 .tabs button').forEach(b=>b.onclick=()=>go(b.dataset.t));go(cur)}
const lsGet=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch{return d}};

/* =====================  1. MIND MAPPING  ===================== */
const MM={t:null,sel:null,k:1,x:0,y:0,id:0,nodes:[]};
const MC={root:'#14213d',keyword:'#7c3aed',author:'#c2410c',journal:'#047857',publisher:'#b45309',country:'#be123c',year:'#475569',paper:'#184e77',custom:'#0f766e'};
const BR={keyword:'Keywords',author:'Authors',journal:'Journals',publisher:'Publishers',country:'Countries',year:'Years'};
const mn=(label,ctype,o)=>Object.assign({id:++MM.id,label:String(label),ctype,kids:[],col:false,note:''},o);
const FS=12,RH=28,wd=n=>Math.min(n.label.length,40)*6.6+22,vis=n=>n.col?[]:n.kids;
const lh=n=>n._h=vis(n).length?vis(n).reduce((a,c)=>a+lh(c),0):1;
const mmFind=(id,n=MM.t)=>{if(n.id===id)return n;for(const c of n.kids){const f=mmFind(id,c);if(f)return f}return null};
const mmParent=(id,n=MM.t)=>{for(const c of n.kids){if(c.id===id)return n;const f=mmParent(id,c);if(f)return f}return null};
function mmBuild(ix,br,per,deep,label){
 const root=mn(label||state.query||'Research results','root'),objs=ix.map(i=>recObj(i));
 const get={keyword:o=>splitKeywords(o.keywords),author:o=>splitAuthors(o.authors),journal:o=>[o.source],publisher:o=>[o.publisher],country:o=>[o.country],year:o=>[String(o.year||'')]};
 br.forEach(b=>{const m=new Map();objs.forEach(o=>new Set(get[b](o).map(x=>(x||'').trim()).filter(Boolean)).forEach(l=>{const k=norm(l),e=m.get(k)||{l,p:[]};e.p.push(o);m.set(k,e)}));
  const B=mn(BR[b],b,{branch:1});
  [...m.values()].sort((a,c)=>c.p.length-a.p.length).slice(0,per).forEach(e=>{const L=mn(e.l+' ('+e.p.length+')',b,{term:e.l,pids:e.p.map(o=>o.index)});
   if(deep){e.p.slice().sort((a,c)=>c.cites-a.cites).slice(0,4).forEach(o=>L.kids.push(mn(o.title,'paper',{pi:o.index})));L.col=true}B.kids.push(L)});
  if(B.kids.length)root.kids.push(B)});
 return root}
function mmLayout(){const r=MM.t,k=vis(r);k.forEach(lh);const tot=k.reduce((a,c)=>a+c._h,0);let acc=0;const Ra=[],La=[];k.forEach(c=>{(acc<tot/2?Ra:La).push(c);acc+=c._h});
 const place=(n,x,top,s)=>{n.x=x;n.y=top+n._h*RH/2;let t=top;vis(n).forEach(c=>{place(c,x+s*(wd(n)/2+46+wd(c)/2),t,s);t+=c._h*RH})};
 r.x=0;r.y=0;const side=(arr,s)=>{const h=arr.reduce((a,c)=>a+c._h,0);let t=-h*RH/2;arr.forEach(c=>{place(c,s*(wd(r)/2+46+wd(c)/2),t,s);t+=c._h*RH})};side(Ra,1);side(La,-1)}
function mmDraw(){mmLayout();const nodes=[],edges=[];(function walk(n,p){nodes.push(n);if(p)edges.push([p,n]);vis(n).forEach(c=>walk(c,n))})(MM.t,null);
 const col=n=>MC[n.ctype]||MC.custom;
 const e=edges.map(([p,c])=>{const s=c.x>p.x?1:-1,x1=p.x+s*wd(p)/2,x2=c.x-s*wd(c)/2,mx=(x1+x2)/2;return `<path d="M${x1},${p.y}C${mx},${p.y} ${mx},${c.y} ${x2},${c.y}" fill="none" stroke="${col(c)}" stroke-opacity=".55" stroke-width="${p===MM.t?2.4:1.4}"/>`}).join('');
 const nd=nodes.map(n=>{const w=wd(n),dark=n.ctype==='root'||n.branch,lab=n.label.length>40?n.label.slice(0,39)+'…':n.label;
  return `<g data-id="${n.id}" style="cursor:pointer"><title>${esc(n.label+(n.note?'\n'+n.note:''))}</title><rect x="${n.x-w/2}" y="${n.y-11}" width="${w}" height="22" rx="${n.ctype==='root'?11:6}" fill="${dark?col(n):'#fff'}" stroke="${col(n)}" stroke-width="${MM.sel===n.id?3.2:1.4}"/><text x="${n.x}" y="${n.y+4}" text-anchor="middle" font-size="${FS}" font-family="Segoe UI,Arial,sans-serif" fill="${dark?'#fff':'#162033'}">${esc(lab)}</text>${n.kids.length&&n!==MM.t?`<text x="${n.x+(n.x>=0?w/2+9:-w/2-9)}" y="${n.y+4}" text-anchor="middle" font-size="12" fill="${col(n)}" data-tg="1">${n.col?'⊕':'⊖'}</text>`:''}${n.note?`<circle cx="${n.x+w/2-3}" cy="${n.y-11}" r="4" fill="#f59e0b"/>`:''}</g>`}).join('');
 Q('#mmg').innerHTML=e+nd;MM.nodes=nodes;mmSide()}
const bounds=()=>{const ns=MM.nodes;return{x0:Math.min(...ns.map(n=>n.x-wd(n)/2))-40,x1:Math.max(...ns.map(n=>n.x+wd(n)/2))+40,y0:Math.min(...ns.map(n=>n.y))-30,y1:Math.max(...ns.map(n=>n.y))+30}};
const mmApply=()=>Q('#mmg').setAttribute('transform',`translate(${MM.x},${MM.y}) scale(${MM.k})`);
function mmFit(){const b=bounds(),s=Q('#mmstage'),W=s.clientWidth,Hh=s.clientHeight;MM.k=Math.min(W/(b.x1-b.x0),Hh/(b.y1-b.y0),1.4);MM.x=W/2-(b.x0+b.x1)/2*MM.k;MM.y=Hh/2-(b.y0+b.y1)/2*MM.k;mmApply()}
function mmSide(){const n=MM.sel&&mmFind(MM.sel),el=Q('#mmside');if(!n){el.innerHTML='<b>Mind map</b><p>Click a node to select it. ⊕/⊖ expands or collapses a branch. Drag the background to pan and use the wheel to zoom.</p><p>Branches are built from the current search results; add your own nodes and notes, then save or export.</p>';return}
 const can=!!n.term;
 el.innerHTML=`<b>${esc(n.label)}</b><div class="tiny">${esc(n.ctype)}</div>${n.note?`<p>📝 ${esc(n.note)}</p>`:''}<div><button class="ghost" data-a="add">＋ Child</button><button class="ghost" data-a="ren">✎ Rename</button><button class="ghost" data-a="note">📝 Note</button>${n.kids.length?`<button class="ghost" data-a="tog">${n.col?'Expand':'Collapse'}</button>`:''}${n!==MM.t?'<button class="ghost" data-a="del">🗑 Delete</button>':''}${can?'<button class="primary" data-a="srch">⌕ Search this</button><button class="ghost" data-a="sub">Map this topic</button>':''}${n.ctype==='paper'&&n.pi!==undefined?'<button class="primary" data-a="det">Open record</button>':''}</div>`}
function mmSearch(n){const t=n.term;closeModal();state.savedOnly=false;if(typeof clearFilters==='function')clearFilters(true);state.advanced=[];$('#advRows').innerHTML='';addAdvRow();state.query='';
 if(n.ctype==='keyword'||n.ctype==='author')state.query='"'+t+'"';
 else if(n.ctype==='journal'){state.source=String(S.indexOf(t));$('#sourceFilter').value=state.source}
 else if(n.ctype==='publisher'){state.publisher=String(PUB.indexOf(t));$('#publisherFilter').value=state.publisher}
 else if(n.ctype==='country'){state.country=String(CO.indexOf(t));$('#countryFilter').value=state.country}
 else if(n.ctype==='year'){state.yearSet=new Set([+t]);$$('[data-year]').forEach(x=>x.checked=x.dataset.year===t)}
 $('#q').value=state.query;state.page=1;document.body.classList.add('has-search');doSearch();toast('Search: '+t)}
const mdOut=(n,d=0)=>'  '.repeat(d)+'- '+n.label+(n.note?' — '+n.note:'')+'\n'+n.kids.map(c=>mdOut(c,d+1)).join('');
const fmOut=n=>`<node TEXT="${esc(n.label)}">${n.note?`<node TEXT="${esc(n.note)}" COLOR="#b45309"/>`:''}${n.kids.map(fmOut).join('')}</node>`;
function mmSvg(){const b=bounds(),w=b.x1-b.x0,h=b.y1-b.y0;return{w,h,s:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${b.x0} ${b.y0} ${w} ${h}" width="${w}" height="${h}"><rect x="${b.x0}" y="${b.y0}" width="${w}" height="${h}" fill="#fff"/>${Q('#mmg').innerHTML}</svg>`}}
function mmPng(){const {s,w,h}=mmSvg(),img=new Image(),sc=Math.min(2,8000/Math.max(w,h));img.onload=()=>{const c=document.createElement('canvas');c.width=w*sc;c.height=h*sc;const x=c.getContext('2d');x.scale(sc,sc);x.drawImage(img,0,0,w,h);c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='mindmap.png';a.click()})};img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s)}
function mmOpen(){
 H('✺ Mind Map',`<div class="row">${SC}${Object.keys(BR).map(b=>`<label><input type="checkbox" class="mmb" value="${b}" ${['keyword','author','journal','year'].includes(b)?'checked':''}> ${BR[b]}</label>`).join('')}<label>Items per branch <input type="number" id="mmper" value="6" min="2" max="25" style="width:60px"></label><label><input type="checkbox" id="mmdeep" checked> Show top papers</label><button class="primary" id="mmgo">Build map</button></div>
 <div class="row"><button class="ghost" id="mmfit">⤢ Fit</button><button class="ghost" id="mmexp">Expand all</button><button class="ghost" id="mmcol">Collapse all</button><button class="ghost" id="mmsave">💾 Save</button><select id="mmload"><option value="">Load saved map…</option>${Object.keys(lsGet('x3Maps',{})).map(k=>`<option>${esc(k)}</option>`).join('')}</select><span class="nav-spacer"></span><button class="ghost" data-x="md">Markdown</button><button class="ghost" data-x="mm">FreeMind</button><button class="ghost" data-x="json">JSON</button><button class="ghost" data-x="svg">SVG</button><button class="ghost" data-x="png">PNG</button></div>
 <div class="mmwrap"><div class="mmstage" id="mmstage"><svg id="mmsvg"><g id="mmg"></g></svg></div><div class="mmside" id="mmside"></div></div>`);
 const build=()=>{MM.id=0;MM.sel=null;MM.t=mmBuild(hits(),QA('.mmb:checked').map(x=>x.value),+Q('#mmper').value||6,Q('#mmdeep').checked);mmDraw();mmFit()};
 Q('#mmgo').onclick=build;if(MM.t){mmDraw();mmFit()}else build();
 const all=(n,v)=>{n.kids.length&&(n.col=v);n.kids.forEach(c=>all(c,v))};
 Q('#mmfit').onclick=mmFit;Q('#mmexp').onclick=()=>{all(MM.t,false);MM.t.col=false;mmDraw();mmFit()};Q('#mmcol').onclick=()=>{MM.t.kids.forEach(c=>all(c,true));mmDraw();mmFit()};
 Q('#mmsave').onclick=()=>{const n=prompt('Name for this mind map');if(!n)return;const m=lsGet('x3Maps',{});m[n]=MM.t;try{localStorage.setItem('x3Maps',JSON.stringify(m));toast('Saved “'+n+'”');mmOpen()}catch{toast('Could not save (storage full)')}};
 Q('#mmload').onchange=e=>{const m=lsGet('x3Maps',{})[e.target.value];if(!m)return;MM.t=m;let mx=0;(function w(n){mx=Math.max(mx,n.id);n.kids.forEach(w)})(m);MM.id=mx;MM.sel=null;mmDraw();mmFit()};
 QA('[data-x]').forEach(b=>b.onclick=()=>{const x=b.dataset.x,nm='mindmap';if(x==='md')download(nm+'.md',mdOut(MM.t),'text/markdown');if(x==='mm')download(nm+'.mm','<map version="1.0.1">'+fmOut(MM.t)+'</map>','application/xml');if(x==='json')download(nm+'.json',JSON.stringify(MM.t,null,1),'application/json');if(x==='svg')download(nm+'.svg',mmSvg().s,'image/svg+xml');if(x==='png')mmPng()});
 const sv=Q('#mmsvg');let drag=null;
 sv.onpointerdown=e=>{if(e.target.closest('[data-id]'))return;drag={x:e.clientX-MM.x,y:e.clientY-MM.y};sv.setPointerCapture(e.pointerId)};
 sv.onpointermove=e=>{if(drag){MM.x=e.clientX-drag.x;MM.y=e.clientY-drag.y;mmApply()}};sv.onpointerup=()=>drag=null;
 sv.onwheel=e=>{e.preventDefault();const r=sv.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top,nk=Math.min(3,Math.max(.15,MM.k*(e.deltaY<0?1.12:.89)));MM.x=px-(px-MM.x)*nk/MM.k;MM.y=py-(py-MM.y)*nk/MM.k;MM.k=nk;mmApply()};
 sv.onclick=e=>{const g=e.target.closest('[data-id]');if(!g)return;const n=mmFind(+g.dataset.id);if(e.target.dataset.tg)n.col=!n.col;else MM.sel=n.id;mmDraw()};
 Q('#mmside').onclick=e=>{const a=e.target.dataset.a,n=MM.sel&&mmFind(MM.sel);if(!a||!n)return;
  if(a==='add'){const l=prompt('New node text');if(l){n.kids.push(mn(l,'custom'));n.col=false}}
  if(a==='ren'){const l=prompt('Rename node',n.label);if(l)n.label=l}
  if(a==='note')n.note=prompt('Note',n.note)||'';
  if(a==='tog')n.col=!n.col;
  if(a==='del'&&confirm('Delete this node and everything below it?')){const p=mmParent(n.id);p.kids=p.kids.filter(c=>c!==n);MM.sel=p.id}
  if(a==='det'){detail(n.pi);return}
  if(a==='srch'){mmSearch(n);return}
  if(a==='sub'){MM.id=0;MM.sel=null;MM.t=mmBuild(n.pids.slice(0,300),QA('.mmb:checked').map(x=>x.value).filter(x=>x!==n.ctype),+Q('#mmper').value||6,Q('#mmdeep').checked,n.term);mmDraw();mmFit();return}
  mmDraw()}}

/* =====================  2. SEMANTIC LAYER  ===================== */
const SEM={};
function semIndex(){if(SEM.kw&&SEM.R===R)return SEM.kw;const kw=new Map(),ab=new Map();
 for(let i=0;i<R.length;i++){const seen=new Set();for(const k0 of splitKeywords(R[i][11])){const k=k0.trim(),key=stem(k);if(!key||seen.has(key))continue;seen.add(key);let e=kw.get(key);if(!e)kw.set(key,e={key,alts:new Map(),p:[]});e.p.push(i);e.alts.set(k,(e.alts.get(k)||0)+1);const m=k.match(/\(([A-Za-z][A-Za-z0-9-]{1,9})\)/);if(m)ab.set(stem(m[1]),key)}}
 for(const [a,t] of ab){const A=kw.get(a),T=kw.get(t);if(A&&T&&A!==T){const have=new Set(T.p);A.p.forEach(i=>have.has(i)||T.p.push(i));A.alts.forEach((v,k)=>T.alts.set(k,(T.alts.get(k)||0)+v));kw.delete(a)}else ab.delete(a)}
 kw.forEach(e=>e.label=[...e.alts].sort((a,b)=>b[1]-a[1])[0][0]);SEM.al=ab;SEM.R=R;return SEM.kw=kw}
function semRel(key){const kw=semIndex(),c=kw.get(key);if(!c)return null;if(c.rel)return c.rel;const co=new Map(),P=c.p.slice(0,3000),n=P.length;
 P.forEach(i=>{const seen=new Set();splitKeywords(R[i][11]).forEach(k=>{let kk=stem(k);kk=SEM.al.get(kk)||kk;if(kk!==key&&!seen.has(kk)&&kw.has(kk)){seen.add(kk);co.set(kk,(co.get(kk)||0)+1)}})});
 const rel={broader:[],narrower:[],related:[]};
 co.forEach((v,k)=>{if(v<2)return;const m=kw.get(k).p.length,a=v/n,b=v/m;if(a>=.6&&m>=1.5*n)rel.broader.push([k,v,a]);else if(b>=.6&&n>=1.5*m)rel.narrower.push([k,v,b]);else{const j=v/(n+m-v);if(j>=.03)rel.related.push([k,v,j])}});
 Object.values(rel).forEach(a=>{a.sort((x,y)=>y[2]-x[2]||y[1]-x[1]);a.length=Math.min(a.length,10)});return c.rel=rel}
function semSearch(q){const kw=semIndex(),qs=stem(q),qt=qs.split(' ').filter(Boolean),tk=tokens(q).filter(t=>t.length>2),seeds=[],ex=kw.get(SEM.al.get(qs)||qs);if(ex)seeds.push(ex);
 qt.length&&[...kw.values()].filter(e=>e!==ex&&qt.every(t=>(' '+e.key).includes(' '+t))).sort((a,b)=>b.p.length-a.p.length).slice(0,4).forEach(e=>seeds.push(e));
 const w=new Map(),why=new Map(),exp=[],add=(e,wt,role)=>e.p.forEach(i=>{w.set(i,(w.get(i)||0)+wt);(why.get(i)||why.set(i,new Set()).get(i)).add(e.label+' · '+role)});
 seeds.forEach((e,k)=>{add(e,k?2:3,k?'contains':'concept');if(k<2){const r=semRel(e.key);r.narrower.slice(0,5).forEach(([x])=>{const d=kw.get(x);add(d,1.5,'narrower');exp.push(['narrower',d.label])});r.related.slice(0,5).forEach(([x])=>{const d=kw.get(x);add(d,1,'related');exp.push(['related',d.label])})}});
 if(tk.length)INDEX.forEach((x,i)=>{if(tk.every(t=>x.t.includes(t))){w.set(i,(w.get(i)||0)+2.5);(why.get(i)||why.set(i,new Set()).get(i)).add('title match')}});
 return{seeds,exp,why,out:[...w].map(([i,s])=>[i,s+.15*Math.log1p(R[i][0])]).sort((a,b)=>b[1]-a[1]).slice(0,30)}}
const ONT=[['Paper','dcterms:creator','Author'],['Paper','schema:isPartOf','Journal'],['Paper','dcterms:publisher','Publisher'],['Paper','dcterms:subject','Concept'],['Paper','dcterms:issued','Year'],['Journal','schema:publisher','Publisher'],['Publisher','schema:location','Country'],['Concept','skos:broader / narrower / related','Concept']];
const ONC={Paper:['schema:ScholarlyArticle','bibo:AcademicArticle'],Author:['foaf:Person'],Journal:['schema:Periodical'],Publisher:['foaf:Organization'],Concept:['skos:Concept'],Country:['schema:Country'],Year:['xsd:gYear']};
function semOv(el){el.innerHTML='<p class="tiny">Building semantic index…</p>';setTimeout(()=>{const au=new Set();R.forEach(r=>splitAuthors(r[1]).forEach(a=>au.add(norm(a))));
 const cnt={Paper:R.length,Author:au.size,Journal:S.length,Publisher:PUB.length,Country:CO.length,Year:new Set(R.map(r=>r[3])).size,Concept:semIndex().size};
 const pos={Paper:[330,130],Author:[80,40],Journal:[330,25],Concept:[580,40],Year:[580,225],Publisher:[80,225],Country:[330,245]};
 const ln=ONT.filter(x=>x[0]!==x[2]).map(([a,p,b])=>{const [x1,y1]=pos[a],[x2,y2]=pos[b];return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#94a3b8" stroke-width="1.5"/><text x="${(x1+x2)/2}" y="${(y1+y2)/2-3}" font-size="10" text-anchor="middle" fill="#1f4e8c">${esc(p)}</text>`}).join('');
 const bx=Object.entries(pos).map(([k,[x,y]])=>`<rect x="${x-55}" y="${y-17}" width="110" height="34" rx="8" fill="${k==='Paper'?'#184e77':'#fff'}" stroke="#184e77"/><text x="${x}" y="${y-2}" text-anchor="middle" font-size="12" font-weight="700" fill="${k==='Paper'?'#fff':'#184e77'}">${k}</text><text x="${x}" y="${y+11}" text-anchor="middle" font-size="9.5" fill="${k==='Paper'?'#dbeafe':'#687386'}">${cnt[k].toLocaleString()} instances</text>`).join('');
 el.innerHTML=`<div class="note">The semantic layer models the bibliographic data as an ontology (classes + relations) mapped to Schema.org, Dublin Core, FOAF, BIBO and SKOS. Keywords become SKOS concepts with synonym merging and broader/narrower/related links inferred from co-occurrence.</div><svg viewBox="0 0 660 270" style="width:100%;max-height:300px">${ln}${bx}</svg>
 <table><tr><th>Class</th><th>Mapped to</th><th>Instances</th></tr>${Object.keys(pos).map(k=>`<tr><td><b>${k}</b></td><td>${ONC[k].join(', ')}</td><td>${cnt[k].toLocaleString()}</td></tr>`).join('')}</table>
 <table style="margin-top:10px"><tr><th>Domain</th><th>Property</th><th>Range</th></tr>${ONT.map(r=>`<tr><td>${r[0]}</td><td>${esc(r[1])}</td><td>${r[2]}</td></tr>`).join('')}</table>`},30)}
function semCn(el){el.innerHTML='<div class="row"><input type="text" id="x3cq" placeholder="Find a concept…" size="32"><button class="ghost" id="x3cg">Find</button></div><div id="x3cl"></div><div id="x3cd"></div>';const kw=semIndex();
 const list=q=>{const t=stem(q);Q('#x3cl').innerHTML=[...kw.values()].filter(e=>!t||e.key.includes(t)).sort((x,y)=>y.p.length-x.p.length).slice(0,40).map(e=>`<span class="chip" data-c="${esc(e.key)}">${esc(e.label)} <b>${e.p.length}</b></span>`).join('')||'<span class="tiny">No matching concept</span>'};
 const show=k=>{const e=kw.get(SEM.al.get(k)||k);if(!e)return;const r=semRel(e.key),ch=a=>a.map(([x,v])=>`<span class="chip" data-c="${esc(x)}">${esc(kw.get(x).label)} <small>${v}</small></span>`).join('')||'—';
  Q('#x3cd').innerHTML=`<div class="card"><h3 style="margin:0 0 4px">${esc(e.label)}</h3><div class="tiny">skos:Concept · ${e.p.length} papers</div><p><b>Alternative labels:</b> ${[...e.alts.keys()].filter(a=>a!==e.label).slice(0,8).map(esc).join('; ')||'—'}</p><p><b>Broader</b> ${ch(r.broader)}</p><p><b>Narrower</b> ${ch(r.narrower)}</p><p><b>Related</b> ${ch(r.related)}</p><b>Top cited papers</b><ol>${e.p.slice().sort((a,b)=>R[b][0]-R[a][0]).slice(0,8).map(i=>`<li><a href="#" data-p="${i}">${esc(R[i][2])}</a> <span class="tiny">(${R[i][3]}, ${R[i][0]} cites)</span></li>`).join('')}</ol></div>`};
 Q('#x3cg').onclick=()=>list(Q('#x3cq').value);Q('#x3cq').onkeydown=e=>{if(e.key==='Enter')list(e.target.value)};list('');
 Q('#x3b').onclick=e=>{const c=e.target.closest('[data-c]'),p=e.target.closest('[data-p]');if(c)show(c.dataset.c);if(p){e.preventDefault();detail(+p.dataset.p)}}}
function semSs(el){el.innerHTML='<div class="note">Concept-aware search: your query is matched to concepts, expanded with narrower and related concepts, and records are ranked by how strongly they match.</div><div class="row"><input type="text" id="x3sq" placeholder="e.g. information literacy" size="40" value="'+esc(state.query||'')+'"><button class="primary" id="x3sg">Semantic search</button></div><div id="x3sr"></div>';
 const run=q=>{if(!q.trim())return;const r=semSearch(q);Q('#x3sr').innerHTML=(r.seeds.length?`<p><b>Matched concepts:</b> ${r.seeds.map(e=>`<span class="chip" data-q="${esc(e.label)}">${esc(e.label)} · ${e.p.length}</span>`).join('')}</p>`:'<p class="tiny">No concept matched; using title matches only.</p>')+(r.exp.length?`<p><b>Expanded with:</b> ${r.exp.map(([t,l])=>`<span class="chip" data-q="${esc(l)}">${esc(l)} <small>${t}</small></span>`).join('')}</p>`:'')+`<p class="tiny">${r.out.length} top results</p>`+r.out.map(([i,s])=>`<div class="card"><a href="#" data-p="${i}"><b>${esc(R[i][2])}</b></a><div class="tiny">${esc(R[i][1])} · ${R[i][3]} · ${esc(S[R[i][4]]||'')} · ${R[i][0]} cites · score ${s.toFixed(2)}</div><div>${[...(r.why.get(i)||[])].slice(0,6).map(w=>`<span class="chip">${esc(w)}</span>`).join('')}</div></div>`).join('')};
 Q('#x3sg').onclick=()=>run(Q('#x3sq').value);Q('#x3sq').onkeydown=e=>{if(e.key==='Enter')run(e.target.value)};
 Q('#x3b').onclick=e=>{const c=e.target.closest('[data-q]'),p=e.target.closest('[data-p]');if(c){Q('#x3sq').value=c.dataset.q;run(c.dataset.q)}if(p){e.preventDefault();detail(+p.dataset.p)}}}

/* ---- RDF building blocks (shared by Semantic export and Linked Open Data) ---- */
let BASE=localStorage.getItem('x3Base')||'https://example.org/are/';
const PFX={rdf:'http://www.w3.org/1999/02/22-rdf-syntax-ns#',rdfs:'http://www.w3.org/2000/01/rdf-schema#',owl:'http://www.w3.org/2002/07/owl#',xsd:'http://www.w3.org/2001/XMLSchema#',dcterms:'http://purl.org/dc/terms/',schema:'https://schema.org/',foaf:'http://xmlns.com/foaf/0.1/',bibo:'http://purl.org/ontology/bibo/',skos:'http://www.w3.org/2004/02/skos/core#',prism:'http://prismstandard.org/namespaces/basic/2.0/'};
const pfx=()=>({...PFX,ex:BASE+'ontology#'});
const X=n=>{const m=n.match(/^([a-z]+):(.*)$/),p=m&&pfx()[m[1]];return p&&!/^\/\//.test(m[2])?p+m[2]:n};
const C=iri=>{for(const[k,v]of Object.entries(pfx()))if(iri.startsWith(v)&&/^[\w.-]+$/.test(iri.slice(v.length)))return k+':'+iri.slice(v.length);return '<'+iri+'>'};
const lit=s=>'"'+String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r?\n/g,'\\n')+'"';
const PFXT=()=>Object.entries(pfx()).map(([k,v])=>`@prefix ${k}: <${v}> .`).join('\n')+'\n\n';
const cid=k=>BASE+'concept/'+slug(k);
function ontTtl(){let t=PFXT()+`<${BASE}ontology> a owl:Ontology ; rdfs:label "Academic Research Explorer bibliographic ontology" .\n\n`;
 Object.entries(ONC).forEach(([c,sup])=>t+=`ex:${c} a owl:Class ; rdfs:label ${lit(c)} ; rdfs:subClassOf ${sup.join(', ')} .\n`);
 const P={Author:'creator',Journal:'isPartOf',Publisher:'publisher',Concept:'subject',Year:'issued',Country:'location'},M={creator:'dcterms:creator',isPartOf:'schema:isPartOf',publisher:'dcterms:publisher',subject:'dcterms:subject',issued:'dcterms:issued',location:'schema:location'};
 ONT.filter(r=>M[P[r[2]]]&&r[1]===M[P[r[2]]]).forEach(([a,p,b])=>t+=`ex:has${b} a owl:ObjectProperty ; rdfs:subPropertyOf ${p} ; rdfs:domain ex:${a} ; rdfs:range ex:${b} .\n`);
 return t}
function skosTtl(N=150){const kw=semIndex(),top=[...kw.values()].sort((a,b)=>b.p.length-a.p.length).slice(0,N);let t=PFXT()+`<${BASE}scheme> a skos:ConceptScheme ; dcterms:title "Keyword concept scheme" .\n\n`;
 top.forEach(e=>{const r=semRel(e.key),L=(a,p)=>a.slice(0,5).map(([k])=>` skos:${p} <${cid(k)}> ;`).join('');t+=`<${cid(e.key)}> a skos:Concept ; skos:inScheme <${BASE}scheme> ; skos:prefLabel ${lit(e.label)} ;`+[...e.alts.keys()].filter(a=>a!==e.label).slice(0,6).map(a=>` skos:altLabel ${lit(a)} ;`).join('')+L(r.broader,'broader')+L(r.narrower,'narrower')+L(r.related,'related')+` rdfs:comment ${lit(e.p.length+' papers')} .\n`});return t}
function semEx(el){el.innerHTML='<div class="note">Download the ontology or the SKOS concept scheme (top 150 concepts with synonyms and broader/narrower/related links) as Turtle. Load them into GraphDB, Protégé or any triple store.</div><div class="row"><button class="primary" id="x3o">⇩ Ontology (.ttl)</button><button class="primary" id="x3k">⇩ SKOS concepts (.ttl)</button></div>';Q('#x3o').onclick=()=>download('ontology.ttl',ontTtl(),'text/turtle');Q('#x3k').onclick=()=>{toast('Building concept scheme…');setTimeout(()=>download('skos-concepts.ttl',skosTtl(),'text/turtle'),30)}}
/* ---- Research Productivity, Research Impact, Performance Indicators (computed from every record) ---- */
const RPX={};
function rpxBase(){
  if(RPX.R===R&&RPX.d)return RPX.d;
  const years=new Map(),authors=new Map(),journals=new Map(),cites=[];
  let multi=0,auTot=0,doi=0,abs=0,kw=0,url=0,cty=0;
  for(let i=0;i<R.length;i++){
    const r=R[i],y=+r[3]||0,c=+r[0]||0,au=splitAuthors(r[1]),ks=splitKeywords(r[11]),j=S[r[4]]||'';
    cites.push(c);auTot+=au.length;if(au.length>=2)multi++;
    if(r[9])doi++;if(r[12])abs++;if(ks.length)kw++;if(r[8])url++;if(CO[r[7]])cty++;
    if(y){let e=years.get(y);if(!e)years.set(y,e={n:0,c:0,multi:0,au:0});e.n++;e.c+=c;e.au+=au.length;if(au.length>=2)e.multi++}
    const seen=new Set();
    au.forEach(a=>{const k=norm(a);if(!k||seen.has(k))return;seen.add(k);let e=authors.get(k);if(!e)authors.set(k,e={name:a,n:0,c:0});e.n++;e.c+=c});
    if(j){let e=journals.get(j);if(!e)journals.set(j,e={name:j,n:0,c:0});e.n++;e.c+=c}
  }
  cites.sort((a,b)=>b-a);
  RPX.R=R;RPX.d={years,authors,journals,cites,multi,auTot,doi,abs,kw,url,cty,N:R.length};
  return RPX.d;
}
const rpxN=n=>Number(n||0).toLocaleString();
const rpxP=(x,d=1)=>(x==null||!isFinite(x))?'n/a':(100*x).toFixed(d)+'%';
const rpxD=(x,d=2)=>(x==null||!isFinite(x))?'n/a':Number(x).toFixed(d);
function rpxH(c){let h=0;for(let k=0;k<c.length;k++){if(c[k]>=k+1)h=k+1;else break}return h}
function rpxG(c){let s=0,g=0;for(let k=0;k<c.length;k++){s+=c[k];if(s>=(k+1)*(k+1))g=k+1}return g}
function rpxCSS(){if(!document.getElementById('rpxCss')){const s=document.createElement('style');s.id='rpxCss';s.textContent='.rpx-kpi{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:10px 0}.rpx-kpi div{border:1px solid var(--line);border-radius:10px;padding:9px 11px;background:#fff}.rpx-kpi b{display:block;font-size:19px;color:var(--brand)}.rpx-kpi span{font-size:12px;color:var(--muted)}.rpx-row{display:grid;grid-template-columns:110px 1fr 150px;gap:8px;align-items:center;font-size:12.5px;margin:3px 0}.rpx-row i{display:block;height:10px;border-radius:5px;background:var(--brand2)}.rpx-row b{font-weight:600;white-space:nowrap}.x3 h4{margin:14px 0 6px}';document.head.appendChild(s)}return ''}
function rpxBars(rows){const mx=Math.max(1,...rows.map(r=>r.v));return `<div>${rows.map(r=>`<div class="rpx-row"><span>${esc(r.l)}</span><i style="width:${(100*r.v/mx).toFixed(1)}%"></i><b>${rpxN(r.v)}${r.p!=null?' · '+rpxP(r.p):''}</b></div>`).join('')}</div>`}
function rpProd(el){
  rpxCSS();const B=rpxBase(),N=B.N,ys=[...B.years.keys()].sort((a,b)=>a-b);
  const first=ys[0],last=ys[ys.length-1],span=last-first;
  const yr=ys.map((y,k)=>{const e=B.years.get(y),pv=k?B.years.get(ys[k-1]).n:null;return{y,n:e.n,share:e.n/N,cum:0,yoy:pv?(e.n-pv)/pv:null,multi:e.n?e.multi/e.n:null}});
  let cum=0;yr.forEach(r=>{cum+=r.n;r.cum=cum});
  const peak=yr.reduce((a,b)=>b.n>a.n?b:a,yr[0]||{n:0,y:'n/a'});
  const cagr=(span>0&&B.years.get(first).n>0)?Math.pow(B.years.get(last).n/B.years.get(first).n,1/span)-1:null;
  const nA=B.authors.size,perA=nA?[...B.authors.values()].reduce((s,e)=>s+e.n,0)/nA:null;
  const topA=[...B.authors.values()].sort((a,b)=>b.n-a.n||b.c-a.c||a.name.localeCompare(b.name)).slice(0,15);
  const topJ=[...B.journals.values()].sort((a,b)=>b.n-a.n||a.name.localeCompare(b.name)).slice(0,10);
  const kp=[[rpxN(N),'Papers'],[ys.length?first+'–'+last:'n/a','Publication years'],[rpxD(ys.length?N/ys.length:null,0),'Mean papers per year'],
    [peak.y+' ('+rpxN(peak.n)+')','Peak year'],[rpxP(yr.length>1?yr[yr.length-1].yoy:null),'Change, last year vs previous'],
    [rpxP(cagr),'Compound annual growth'],[rpxN(nA),'Distinct authors'],[rpxD(B.auTot/N,2),'Authors per paper'],
    [rpxP(B.multi/N),'Multi-authored papers'],[rpxD(perA,2),'Papers per author'],[rpxN(B.journals.size),'Distinct journals']];
  el.innerHTML=`<div class="note">Research output in this dataset: papers per year, who publishes, and where. Counts describe the records only; they do not measure funding, quality or effort.</div>
  <div class="rpx-kpi">${kp.map(([v,l])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  <h4>Output by year</h4>${rpxBars(yr.map(r=>({l:String(r.y),v:r.n,p:r.share})))}
  <table><tr><th>Year</th><th>Papers</th><th>Share</th><th>Cumulative</th><th>Change vs previous year</th><th>Multi-authored</th></tr>
  ${yr.map(r=>`<tr><td>${r.y}</td><td>${rpxN(r.n)}</td><td>${rpxP(r.share)}</td><td>${rpxN(r.cum)}</td><td>${rpxP(r.yoy)}</td><td>${rpxP(r.multi)}</td></tr>`).join('')}</table>
  <h4>Most productive authors (top 15, by papers)</h4>
  <table><tr><th>Author</th><th>Papers</th><th>Citations</th></tr>${topA.map(a=>`<tr><td>${esc(a.name)}</td><td>${rpxN(a.n)}</td><td>${rpxN(a.c)}</td></tr>`).join('')}</table>
  <h4>Most productive journals (top 10)</h4>
  <table><tr><th>Journal</th><th>Papers</th><th>Share of papers</th></tr>${topJ.map(j=>`<tr><td>${esc(j.name)}</td><td>${rpxN(j.n)}</td><td>${rpxP(j.n/N)}</td></tr>`).join('')}</table>`;
  el.onclick=null;
}
function rpImpact(el){
  rpxCSS();const B=rpxBase(),N=B.N,c=B.cites,n=c.length;
  const total=c.reduce((s,x)=>s+x,0),mean=n?total/n:null,median=n?(n%2?c[(n-1)/2]:(c[n/2-1]+c[n/2])/2):null;
  const h=rpxH(c),g=rpxG(c),thr=n?c[Math.floor(n*.1)]:null,topN=c.filter(x=>x>=thr&&x>0).length,unc=c.filter(x=>x===0).length;
  const buckets=[['0',0,0],['1 to 4',1,4],['5 to 9',5,9],['10 to 24',10,24],['25 to 49',25,49],['50 to 99',50,99],['100 or more',100,Infinity]].map(([l,a,b])=>({l,v:c.filter(x=>x>=a&&x<=b).length,p:n?c.filter(x=>x>=a&&x<=b).length/n:null}));
  const ys=[...B.years.keys()].sort((a,b)=>a-b);
  const yrRows=ys.map(y=>{const e=B.years.get(y);return{y,n:e.n,mean:e.c/e.n}});
  const topIdx=[...Array(R.length).keys()].sort((a,b)=>R[b][0]-R[a][0]||a-b).slice(0,10);
  const jr=[...B.journals.values()].filter(j=>j.n>=10).map(j=>({name:j.name,n:j.n,mean:j.c/j.n,c:j.c})).sort((a,b)=>b.mean-a.mean||a.name.localeCompare(b.name)).slice(0,10);
  el.innerHTML=`<div class="note">Citation counts are a snapshot of the dataset. Older papers have had more time to accumulate citations, so compare years and journals with care.</div>
  <div class="rpx-kpi">${[[rpxN(total),'Total citations'],[rpxD(mean,1),'Mean citations per paper'],[rpxN(median),'Median citations'],[rpxN(R.reduce((m,r)=>Math.max(m,r[0]||0),0)),'Maximum citations'],
   [rpxN(h),'h-index (collection)'],[rpxN(g),'g-index (collection)'],[rpxP(unc/N),'Uncited papers'],[rpxN(topN),'Papers in top 10% (≥ '+rpxN(thr)+' citations)']]
   .map(([v,l])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  <h4>Citation distribution</h4>${rpxBars(buckets)}
  <h4>Mean citations by publication year</h4>
  <table><tr><th>Year</th><th>Papers</th><th>Mean citations</th></tr>${yrRows.map(r=>`<tr><td>${r.y}</td><td>${rpxN(r.n)}</td><td>${rpxD(r.mean,1)}</td></tr>`).join('')}</table>
  <h4>Most cited papers (top 10)</h4>
  <table><tr><th>Title</th><th>Year</th><th>Journal</th><th>Citations</th></tr>${topIdx.map(i=>`<tr><td><button class="ghost" type="button" data-p="${i}">${esc(R[i][2]||'Untitled')}</button></td><td>${R[i][3]||'n/a'}</td><td>${esc(S[R[i][4]]||'')}</td><td>${rpxN(R[i][0])}</td></tr>`).join('')}</table>
  <h4>Journals by mean citations (at least 10 papers, top 10)</h4>
  <table><tr><th>Journal</th><th>Papers</th><th>Mean citations</th><th>Total citations</th></tr>${jr.map(j=>`<tr><td>${esc(j.name)}</td><td>${rpxN(j.n)}</td><td>${rpxD(j.mean,1)}</td><td>${rpxN(j.c)}</td></tr>`).join('')||'<tr><td colspan="4">No journal has 10 or more papers.</td></tr>'}</table>`;
  el.onclick=e=>{const p=e.target.closest('[data-p]');if(p){e.preventDefault();detail(+p.dataset.p)}};
}
function rpPerf(el){
  rpxCSS();const B=rpxBase(),N=B.N,ys=[...B.years.keys()].sort((a,b)=>a-b),first=ys[0],last=ys[ys.length-1],span=last-first;
  const c=B.cites,mean=N?c.reduce((s,x)=>s+x,0)/N:null,median=N?(N%2?c[(N-1)/2]:(c[N/2-1]+c[N/2])/2):null;
  const cagr=(span>0&&B.years.get(first).n>0)?Math.pow(B.years.get(last).n/B.years.get(first).n,1/span)-1:null;
  const hhi=[...B.journals.values()].reduce((s,j)=>s+Math.pow(j.n/N,2),0);
  const perA=B.authors.size?[...B.authors.values()].reduce((s,e)=>s+e.n,0)/B.authors.size:null;
  const rows=[
    ['Productivity','Papers',rpxN(N),'Records in the dataset'],
    ['Productivity','Mean papers per year',rpxD(N/ys.length,0),'Papers ÷ number of years'],
    ['Productivity','Compound annual growth',rpxP(cagr),'(last year ÷ first year)^(1 ÷ span) − 1'],
    ['Collaboration','Authors per paper',rpxD(B.auTot/N,2),'Author–paper links ÷ papers'],
    ['Collaboration','Multi-authored share',rpxP(B.multi/N),'Papers with at least 2 authors ÷ papers'],
    ['Collaboration','Papers per author',rpxD(perA,2),'Author–paper links ÷ distinct authors'],
    ['Impact','Mean citations',rpxD(mean,1),'Total citations ÷ papers'],
    ['Impact','Median citations',rpxN(median),'Middle citation count'],
    ['Impact','h-index',rpxN(rpxH(c)),'Largest h with h papers each cited ≥ h times'],
    ['Impact','g-index',rpxN(rpxG(c)),'Largest g with the top g papers totalling ≥ g² citations'],
    ['Diversity','Distinct journals',rpxN(B.journals.size),'Distinct non-blank journal names'],
    ['Diversity','Distinct countries',rpxN(new Set(R.map(r=>CO[r[7]]).filter(Boolean)).size),'Distinct non-blank countries'],
    ['Diversity','Journal concentration (HHI)',rpxD(hhi,3),'Σ (journal share)²; near 0 = spread out, 1 = one journal']];
  const comp=[['DOI',B.doi],['Abstract',B.abs],['Keywords',B.kw],['Article link',B.url],['Country',B.cty]];
  el.innerHTML=`<div class="note">Indicators computed from every record in the dataset. They describe this collection only. They are not normalised by field or age and are not benchmarks.</div>
  <table><tr><th>Area</th><th>Indicator</th><th>Value</th><th>How it is calculated</th></tr>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td><b>${r[2]}</b></td><td>${esc(r[3])}</td></tr>`).join('')}</table>
  <h4>Data completeness</h4>${rpxBars(comp.map(([l,v])=>({l,v,p:v/N})))}
  <p class="tiny">Share shown after each count is the fraction of all ${rpxN(N)} records that have that field. Missing fields are not counted as zero in any other indicator.</p>`;
  el.onclick=null;
}

const semOpen=s=>tabbed('◈ Semantic Layer',[['ov','Ontology'],['cn','Concepts (SKOS)'],['ss','Semantic search'],['tg','Semantic tags'],['pr','Research Productivity'],['ri','Research Impact'],['pi','Performance Indicators'],['im','Import'],['bc','⛓ Blockchain'],['ex','Export'],...(window.X5?X5.tabs:[])],(k,el)=>k.startsWith('x5')?window.X5.render(k,el):({ov:semOv,cn:semCn,ss:semSs,tg:semTags,pr:rpProd,ri:rpImpact,pi:rpPerf,im:semIm,bc:semBc,ex:semEx})[k](el),s);

/* =====================  3. LINKED OPEN DATA  ===================== */
const lk=()=>lsGet('x3Links',{}),setLk=o=>{try{localStorage.setItem('x3Links',JSON.stringify(o))}catch{toast('Could not store links')}};
const J=u=>onlineFetchJson(u,{timeout:10000,headers:{Accept:'application/json'}}),strip=s=>String(s||'').replace(/<[^>]+>/g,'');
const oa=t=>async q=>((await J('https://api.openalex.org/'+t+'?per-page=5&search='+encodeURIComponent(q))).results||[]).map(x=>({src:'OpenAlex',uri:x.id,label:x.display_name,desc:strip(x.description||x.orcid||x.issn_l||x.host_organization_name||'')}));
const wdS=async q=>((await J('https://www.wikidata.org/w/api.php?action=wbsearchentities&format=json&language=en&origin=*&limit=5&search='+encodeURIComponent(q))).search||[]).map(x=>({src:'Wikidata',uri:x.concepturi||'http://www.wikidata.org/entity/'+x.id,label:x.label,desc:x.description||''}));
const dbS=async q=>((await J('https://lookup.dbpedia.org/api/search?format=json&maxResults=5&query='+encodeURIComponent(q))).docs||[]).map(x=>({src:'DBpedia',uri:[].concat(x.resource)[0],label:strip([].concat(x.label)[0]),desc:strip([].concat(x.comment||'')[0]).slice(0,160)}));
const SRC={keyword:[wdS,dbS,oa('topics')],author:[oa('authors'),wdS],journal:[oa('sources'),wdS],publisher:[oa('publishers'),wdS],country:[wdS,dbS]};
async function lodFind(type,q){const r=await Promise.allSettled(SRC[type].map(f=>f(q)));return{items:r.flatMap(x=>x.status==='fulfilled'?x.value:[]).filter(x=>x.uri),err:r.filter(x=>x.status==='rejected').length}}
const onl=()=>`<div class="note">${navigator.onLine?'🌐 Online: Wikidata, DBpedia and OpenAlex are used.':'⚠ Offline: linking and SPARQL need internet. Saved links and RDF export still work.'}</div>`;
const TYPES=['keyword','author','journal','publisher','country'];
function lodRec(el){el.innerHTML=onl()+`<div class="row"><label>Entity type <select id="x3t">${TYPES.map(t=>`<option>${t}</option>`).join('')}</select></label>${SC}<button class="primary" id="x3auto">Auto-link first 10</button></div><div id="x3rl"></div>`;
 const draw=()=>{const type=Q('#x3t').value,m=new Map(),L=lk();hits().forEach(i=>{const o=recObj(i);({keyword:splitKeywords(o.keywords),author:splitAuthors(o.authors),journal:[o.source],publisher:[o.publisher],country:[o.country]})[type].forEach(l=>{l=(l||'').trim();if(!l)return;const k=norm(l),e=m.get(k)||{l,n:0};e.n++;m.set(k,e)})});
  Q('#x3rl').innerHTML='<table><tr><th>Label</th><th>Papers</th><th>Linked open data URI</th><th></th></tr>'+[...m.values()].sort((a,b)=>b.n-a.n).slice(0,25).map(e=>{const k=type+'|'+norm(e.l),x=L[k];return `<tr data-k="${esc(k)}" data-l="${esc(e.l)}"><td>${esc(e.l)}</td><td>${e.n}</td><td>${x?`<a href="${esc(safeUrl(x.uri))}" target="_blank" rel="noopener">${esc(x.src)}: ${esc(x.label)}</a>`:'—'}</td><td><button class="ghost" data-f="1">${x?'Re-link':'Find'}</button></td></tr><tr><td colspan="4"></td></tr>`}).join('')+'</table>'};
 Q('#x3t').onchange=draw;Q('#x3n').onchange=draw;draw();
 Q('#x3rl').onclick=async e=>{if(e.target.dataset.f){const tr=e.target.closest('tr'),box=tr.nextElementSibling.firstChild;box.textContent='Searching…';const r=await lodFind(Q('#x3t').value,tr.dataset.l);tr.cand=r.items;box.innerHTML=r.items.map((c,j)=>`<div><button class="ghost" data-a="${j}">Accept</button> <b>${esc(c.src)}</b> ${esc(c.label)} <span class="tiny">${esc(c.desc)}</span></div>`).join('')||`<span class="bad">No candidates${r.err?' ('+r.err+' source(s) unreachable)':''}</span>`}
  else if(e.target.dataset.a!==undefined){const p=e.target.closest('tr').previousElementSibling,L=lk();L[p.dataset.k]=p.cand[+e.target.dataset.a];setLk(L);draw();toast('Link saved')}};
 Q('#x3auto').onclick=async()=>{let n=0;for(const tr of QA('#x3rl tr[data-k]').slice(0,10)){if(lk()[tr.dataset.k])continue;const r=await lodFind(Q('#x3t').value,tr.dataset.l),c=r.items.find(x=>norm(x.label)===norm(tr.dataset.l));if(c){const L=lk();L[tr.dataset.k]=c;setLk(L);n++}toast('Auto-linked '+n)}draw()}}
function lodLinked(el){const L=lk(),ks=Object.keys(L);el.innerHTML=`<div class="row"><b>${ks.length} saved link(s)</b><button class="ghost" id="x3lj">⇩ JSON</button><button class="ghost" id="x3lc">Clear all</button></div><table><tr><th>Type</th><th>Entity</th><th>Linked to</th><th></th></tr>${ks.map(k=>`<tr><td>${esc(k.split('|')[0])}</td><td>${esc(k.split('|').slice(1).join('|'))}</td><td><a href="${esc(safeUrl(L[k].uri))}" target="_blank" rel="noopener">${esc(L[k].src)}: ${esc(L[k].label)}</a></td><td><button class="ghost" data-d="${esc(k)}">✕</button></td></tr>`).join('')||'<tr><td colspan="4" class="tiny">No links yet. Use the Reconcile tab.</td></tr>'}</table>`;
 Q('#x3lj').onclick=()=>download('linked-entities.json',JSON.stringify(L,null,1),'application/json');Q('#x3lc').onclick=()=>{if(confirm('Remove all saved links?')){setLk({});lodLinked(el)}};
 el.onclick=e=>{const d=e.target.dataset.d;if(d){const M=lk();delete M[d];setLk(M);lodLinked(el)}}}
function lodSparql(el){const L=lk(),wd=Object.values(L).filter(x=>/wikidata\.org\/entity\/Q\d+$/.test(x.uri)).map(x=>'wd:'+x.uri.split('/').pop()),db=Object.values(L).filter(x=>/dbpedia\.org\/resource\//.test(x.uri)).map(x=>'<'+x.uri+'>');
 const gd=(typeof DB_DEFAULTS!=='undefined'&&DB_DEFAULTS.graphRepo)||'http://localhost:7200/repositories/library';
 const EP={wikidata:'https://query.wikidata.org/sparql',dbpedia:'https://dbpedia.org/sparql',graphdb:gd},
 PR={wd:`PREFIX wd: <http://www.wikidata.org/entity/>\nPREFIX schema: <http://schema.org/>\nSELECT ?item ?itemLabel ?itemDescription ?article WHERE {\n  VALUES ?item { ${wd.join(' ')||'wd:Q5'} }\n  OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> }\n  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }\n}`,db:`PREFIX dbo: <http://dbpedia.org/ontology/>\nSELECT ?s ?abstract WHERE {\n  VALUES ?s { ${db.join(' ')||'<http://dbpedia.org/resource/Library>'} }\n  ?s dbo:abstract ?abstract . FILTER(lang(?abstract)='en')\n}`,gd:`SELECT ?type (COUNT(*) AS ?n) WHERE { ?s a ?type } GROUP BY ?type ORDER BY DESC(?n)`};
 el.innerHTML=onl()+`<div class="row"><label>Endpoint <select id="x3ep"><option value="wikidata">Wikidata</option><option value="dbpedia">DBpedia</option><option value="graphdb">My GraphDB (${esc(gd)})</option></select></label><button class="ghost" data-p="wd">Preset: describe linked Wikidata items</button><button class="ghost" data-p="db">Preset: DBpedia abstracts</button><button class="ghost" data-p="gd">Preset: GraphDB class counts</button></div><textarea id="x3sq" rows="8">${esc(PR.wd)}</textarea><div class="row"><button class="primary" id="x3run">▶ Run query</button><span class="tiny" id="x3st"></span></div><div id="x3res" style="overflow:auto"></div>`;
 el.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{Q('#x3sq').value=PR[b.dataset.p];Q('#x3ep').value={wd:'wikidata',db:'dbpedia',gd:'graphdb'}[b.dataset.p]});
 Q('#x3run').onclick=async()=>{const ep=Q('#x3ep').value,u=EP[ep]+(EP[ep].includes('?')?'&':'?')+(ep==='wikidata'?'format=json&':'')+'query='+encodeURIComponent(Q('#x3sq').value);Q('#x3st').textContent='Running…';
  try{const r=await onlineFetchJson(u,{timeout:25000,headers:{Accept:'application/sparql-results+json'}}),v=r.head?.vars||[],b=r.results?.bindings||[];Q('#x3st').textContent=b.length+' row(s)';
   Q('#x3res').innerHTML=`<table><tr>${v.map(x=>`<th>${esc(x)}</th>`).join('')}</tr>${b.map(row=>`<tr>${v.map(x=>{const c=row[x];if(!c)return '<td></td>';const s=safeUrl(c.value);return `<td>${s?`<a href="${esc(s)}" target="_blank" rel="noopener">${esc(c.value.length>60?'…'+c.value.slice(-50):c.value)}</a>`:esc(c.value.slice(0,300))}</td>`}).join('')}</tr>`).join('')}</table>`}
  catch(e){Q('#x3st').innerHTML='<span class="bad">'+esc(e.message||e)+' — check internet/endpoint/CORS</span>'}}}
function triples(ix,abs){const T=[],L=lk(),seen=new Set(),t=(s,p,o,ty,dt)=>T.push([s,X(p),ty==='i'?X(o):o,ty,dt&&X(dt)]),once=(u,f)=>{if(!seen.has(u)){seen.add(u);f()}},link=(type,label,u)=>{const m=L[type+'|'+norm(label)];if(m)t(u,type==='keyword'?'skos:exactMatch':'owl:sameAs',m.uri,'i')};
 ix.forEach(i=>{const o=recObj(i),doi=(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').trim(),pu=doi?'https://doi.org/'+doi:BASE+'paper/'+i;
  ['schema:ScholarlyArticle','bibo:AcademicArticle','ex:Paper'].forEach(c=>t(pu,'rdf:type',c,'i'));t(pu,'dcterms:title',o.title,'l');
  if(o.year)t(pu,'dcterms:issued',String(o.year),'l','xsd:gYear');if(doi)t(pu,'prism:doi',doi,'l');{const pl=L['paper|'+norm(o.title)];if(pl)t(pu,'owl:sameAs',pl.uri,'i')}if(safeUrl(o.url))t(pu,'schema:url',safeUrl(o.url),'i');t(pu,'ex:citedByCount',String(o.cites||0),'l','xsd:integer');if(abs&&o.abstract)t(pu,'dcterms:abstract',o.abstract,'l');
  splitAuthors(o.authors).forEach(a=>{const u=BASE+'author/'+slug(a);t(pu,'dcterms:creator',u,'i');once(u,()=>{t(u,'rdf:type','foaf:Person','i');t(u,'foaf:name',a,'l');link('author',a,u)})});
  let ju=null;if(o.source){ju=(o.issn&&/\d{4}-?\d{3}[\dXx]/.test(o.issn))?'urn:issn:'+o.issn.match(/\d{4}-?\d{3}[\dXx]/)[0].replace(/^(\d{4})(\d)/,'$1-$2'):BASE+'journal/'+slug(o.source);t(pu,'schema:isPartOf',ju,'i');once(ju,()=>{t(ju,'rdf:type','schema:Periodical','i');t(ju,'dcterms:title',o.source,'l');link('journal',o.source,ju)})}
  if(o.publisher){const u=BASE+'publisher/'+slug(o.publisher);t(pu,'dcterms:publisher',u,'i');once(u,()=>{t(u,'rdf:type','foaf:Organization','i');t(u,'foaf:name',o.publisher,'l');link('publisher',o.publisher,u);if(o.country){const cu=BASE+'country/'+slug(o.country);t(u,'schema:location',cu,'i');once(cu,()=>{t(cu,'rdf:type','schema:Country','i');t(cu,'schema:name',o.country,'l');link('country',o.country,cu)})}})}
  splitKeywords(o.keywords).forEach(k=>{k=k.trim();const key=stem(k);if(!key)return;const u=cid(key);t(pu,'dcterms:subject',u,'i');once(u,()=>{t(u,'rdf:type','skos:Concept','i');t(u,'skos:prefLabel',k,'l');link('keyword',k,u)})})});return T}
const oStr=(o,full)=>o[3]==='i'?(full?'<'+o[2]+'>':C(o[2])):lit(o[2])+(o[4]?'^^'+(full?'<'+o[4]+'>':C(o[4])):'');
function serialize(T,f){if(f==='nt')return T.map(x=>`<${x[0]}> <${x[1]}> ${oStr(x,1)} .`).join('\n');
 if(f==='jsonld'){const g=new Map();T.forEach(([s,p,o,ty,dt])=>{let n=g.get(s);if(!n)g.set(s,n={'@id':s});if(p===PFX.rdf+'type')(n['@type']=n['@type']||[]).push(o);else(n[p]=n[p]||[]).push(ty==='i'?{'@id':o}:dt?{'@value':o,'@type':dt}:o)});return JSON.stringify({'@context':pfx(),'@graph':[...g.values()]},null,1)}
 const g=new Map();T.forEach(x=>(g.get(x[0])||g.set(x[0],[]).get(x[0])).push(x));let s=PFXT();g.forEach((a,k)=>{s+=C(k)+'\n'+a.map(x=>'    '+(x[1]===PFX.rdf+'type'?'a':C(x[1]))+' '+oStr(x)).join(' ;\n')+' .\n\n'});return s}
function lodExp(el){el.innerHTML=`<div class="note">Exports the scoped records as Linked Data (Schema.org, Dublin Core, FOAF, BIBO, SKOS, PRISM). DOIs become real URIs, ISSNs become urn:issn: URIs, and entities you linked in the Reconcile tab are added as owl:sameAs / skos:exactMatch.</div>
 <div class="row">${SC}<label>Format <select id="x3f"><option value="ttl">Turtle</option><option value="jsonld">JSON-LD</option><option value="nt">N-Triples</option></select></label><label><input type="checkbox" id="x3ab"> include abstracts</label></div>
 <div class="row"><label>Base URI for new entities <input type="text" id="x3base" size="34" value="${esc(BASE)}"></label></div>
 <div class="row"><button class="ghost" id="x3pv">Preview</button><button class="primary" id="x3dl">⇩ Download</button><button class="ghost" id="x3cp">Copy</button><button class="ghost" id="x3gd">⬆ Push to GraphDB</button><span class="tiny" id="x3info"></span></div><textarea id="x3out" rows="14" readonly placeholder="Preview appears here"></textarea>`;
 const gen=()=>{BASE=Q('#x3base').value.trim().replace(/\/?$/,'/')||BASE;try{localStorage.setItem('x3Base',BASE)}catch{}const T=triples(hits(),Q('#x3ab').checked),f=Q('#x3f').value,s=serialize(T,f);Q('#x3info').textContent=T.length.toLocaleString()+' triples';return{s,f}};
 Q('#x3pv').onclick=()=>{const {s}=gen();Q('#x3out').value=s.length>20000?s.slice(0,20000)+'\n# … preview truncated; download for the full file':s};
 Q('#x3dl').onclick=()=>{const {s,f}=gen();download('research-linked-data.'+({ttl:'ttl',jsonld:'jsonld',nt:'nt'})[f],s,{ttl:'text/turtle',jsonld:'application/ld+json',nt:'application/n-triples'}[f])};
 Q('#x3cp').onclick=async()=>{try{await navigator.clipboard.writeText(gen().s);toast('Copied')}catch{toast('Copy failed — use Download')}};
 Q('#x3gd').onclick=async()=>{const gd=(typeof DB_DEFAULTS!=='undefined'&&DB_DEFAULTS.graphRepo)||'http://localhost:7200/repositories/library';BASE=Q('#x3base').value.trim().replace(/\/?$/,'/')||BASE;const body=serialize(triples(hits(),Q('#x3ab').checked),'ttl');try{const r=await fetch(gd.replace(/\/$/,'')+'/statements',{method:'POST',headers:{'Content-Type':'text/turtle'},body});if(!r.ok)throw new Error(r.status+' '+r.statusText);toast('Pushed to GraphDB')}catch(e){toast('GraphDB push failed: '+(e.message||e))}}}
const lodOpen=s=>tabbed('🔗 Linked Open Data',[['uri','Open Data URI'],['rec','Reconcile'],['lnk','Linked entities'],['sq','SPARQL'],['ex','Export RDF']],(k,el)=>({uri:lodUri,rec:lodRec,lnk:lodLinked,sq:lodSparql,ex:lodExp})[k](el),s);

/* ===== X4 additions: AI Search, extended Research Gap Finder (+), Semantic tags / Import / Blockchain, Open Data URI tab ===== */
const st4=document.createElement('style');st4.textContent=`
.x3 .badge4{margin-right:4px;display:inline-block;border-radius:999px;padding:2px 10px;font-size:11.5px;font-weight:700;background:#eaf0fb;color:#1f4e8c;margin-left:8px;vertical-align:middle}
.x3 .badge4.ok{background:#e6f6ee;color:#0f6b46}.x3 .badge4.warn{background:#fff4e0;color:#8a5a00}.x3 .badge4.bad{background:#fdeeee;color:#a12b2b}
.x3 .tag4{display:inline-block;border-radius:6px;padding:1px 7px;font-size:11.5px;margin:2px 3px 2px 0;border:1px solid var(--line);background:#f6f8fb;cursor:pointer}
.x3 .tag4 small{opacity:.65;margin-left:3px}
.x3 .tag4.f-Topic{background:#eaf0fb}.x3 .tag4.f-Method{background:#e6f6ee}.x3 .tag4.f-Design{background:#f1ecfa}.x3 .tag4.f-Context{background:#fff4e0}.x3 .tag4.f-Theory{background:#fdeeee}.x3 .tag4.f-Outcome{background:#e8f6f7}.x3 .tag4.f-Type{background:#eef2e2}.x3 .tag4.f-Impact{background:#fbe9f1}.x3 .tag4.f-Recency{background:#eceff3}.x3 .tag4.f-Region{background:#f3ede4}.x3 .tag4.f-MyTags{background:#fff7bf;border-color:#e6cf55}.x3 .tag4.f-Imported{background:#e4f5d9;border-color:#9ccc7a}
.x3 .mono{font-family:ui-monospace,Consolas,monospace;font-size:11.5px;word-break:break-all}
.x3 button.primary,.x3 button.ghost{cursor:pointer}
.x3 .aiwrap{display:flex;flex-direction:column;height:min(74vh,720px)}
.x3 .ailog{flex:1;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:10px;background:#fbfcfe}
.x3 .aimsg{margin:0 0 12px;display:flex;gap:8px}.x3 .aimsg.u{justify-content:flex-end}
.x3 .aibub{max-width:94%;border-radius:12px;padding:9px 12px;border:1px solid var(--line);background:#fff}
.x3 .aimsg.u .aibub{background:var(--brand);color:#fff;border-color:var(--brand)}
.x3 .aires{border:1px solid var(--line);border-radius:9px;padding:8px 10px;margin:7px 0;background:#fff}
.x3 .aires mark{background:#fff2a8;padding:0 1px}
.x3 .aiin{display:flex;gap:8px;margin-top:8px;align-items:flex-end}.x3 .aiin textarea{flex:1;font-family:inherit;font-size:14px}
.x3 .aibar{display:inline-block;height:12px;background:var(--brand);border-radius:3px;vertical-align:middle}
.x3 .gapx{position:relative}
.gap-card{position:relative}
.gap-plus{position:absolute;right:10px;top:10px;width:28px;height:28px;border-radius:50%;border:1.5px solid #8a5a00;background:#fff;color:#8a5a00;font-weight:800;font-size:18px;line-height:1;cursor:pointer;padding:0}
.gap-plus:hover{background:#8a5a00;color:#fff}
.gap-more{margin-top:8px;padding:8px 10px;border-left:3px solid #c98a00;background:#fffaf0;border-radius:6px;font-size:13px}
.gap-more[hidden]{display:none}
.gap-more a,.gap-more button.lnk{margin-right:10px;font-size:12.5px}
.chain-ok{color:#0f6b46;font-weight:700}.chain-bad{color:#b42318;font-weight:700}
.sample-header .toolbar #aiBtn{background:#f1ecfa!important;color:#5b2a9a!important}
`;document.head.appendChild(st4);

/* ---------- storage + crypto helpers ---------- */
const lsPut=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch{toast('Browser storage is full or blocked');return false}};
const K256=[],H256=[];(()=>{const pr=[];for(let n=2;pr.length<64;n++)if(pr.every(p=>n%p))pr.push(n);const fr=x=>Math.floor((x-Math.floor(x))*4294967296);pr.forEach((p,i)=>{K256[i]=fr(Math.cbrt(p));if(i<8)H256[i]=fr(Math.sqrt(p))})})();
function sha256(str){const b=new TextEncoder().encode(String(str)),l=b.length,nw=((l+9+63)>>6)<<4,w=new Uint32Array(nw);for(let i=0;i<l;i++)w[i>>2]|=b[i]<<(24-(i&3)*8);w[l>>2]|=0x80<<(24-(l&3)*8);w[nw-1]=(l*8)>>>0;w[nw-2]=Math.floor(l*8/4294967296);
 let h=H256.slice();const W=new Uint32Array(64);
 for(let o=0;o<nw;o+=16){for(let i=0;i<16;i++)W[i]=w[o+i];for(let i=16;i<64;i++){const a=W[i-15],c=W[i-2];W[i]=(W[i-16]+(((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3))+W[i-7]+(((c>>>17)|(c<<15))^((c>>>19)|(c<<13))^(c>>>10)))>>>0}
  let [a,b2,c2,d,e,f,g,hh]=h;
  for(let i=0;i<64;i++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)),ch=(e&f)^(~e&g),t1=(hh+S1+ch+K256[i]+W[i])>>>0,S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)),mj=(a&b2)^(a&c2)^(b2&c2),t2=(S0+mj)>>>0;hh=g;g=f;f=e;e=(d+t1)>>>0;d=c2;c2=b2;b2=a;a=(t1+t2)>>>0}
  h=[h[0]+a,h[1]+b2,h[2]+c2,h[3]+d,h[4]+e,h[5]+f,h[6]+g,h[7]+hh].map(x=>x>>>0)}
 return h.map(x=>('00000000'+x.toString(16)).slice(-8)).join('')}
function merkle(leaves){if(!leaves.length)return sha256('');let L=leaves.slice();while(L.length>1){if(L.length&1)L.push(L[L.length-1]);const N=[];for(let i=0;i<L.length;i+=2)N.push(sha256(L[i]+L[i+1]));L=N}return L[0]}
function merkleProof(leaves,idx){let L=leaves.slice(),path=[],i=idx;while(L.length>1){if(L.length&1)L.push(L[L.length-1]);path.push({h:L[i^1],left:!!(i&1)});const N=[];for(let k=0;k<L.length;k+=2)N.push(sha256(L[k]+L[k+1]));L=N;i>>=1}return path}
function verifyProof(leaf,path,root){let h=leaf;for(const s of path)h=s.left?sha256(s.h+h):sha256(h+s.h);return h===root}
const doiOf=d=>String(d||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').replace(/^doi:\s*/i,'').trim();
const tnorm=s=>norm(s).replace(/[^a-z0-9]+/g,' ').trim();
const recKey=i=>{const d=doiOf(R[i][9]).toLowerCase();return d||('t:'+sha256(tnorm(R[i][2])).slice(0,16))};
const copyText=async t=>{try{await navigator.clipboard.writeText(t);toast('Copied')}catch{const a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');toast('Copied')}catch{toast('Copy failed')}a.remove()}};
const CSVq=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
const backBtn=(fn,label)=>`<button class="ghost" id="x4back" type="button">← ${label}</button>`;

/* ---------- shared facet dictionaries (also used by the gap finder) ---------- */
const CTX=[['students / learners',/\b(students?|learners?|undergraduates?|pupils?)\b/i],['university / higher education',/\b(universit(?:y|ies)|higher education|college)\b/i],['schools / teachers',/\b(schools?|k-12|teachers?|secondary education|primary education)\b/i],['children / adolescents',/\b(children|adolescents?|youth|teenagers?)\b/i],['older adults',/\b(older adults?|elderly|ageing|aging)\b/i],['healthcare settings',/\b(hospitals?|patients?|clinical|nurses?|healthcare|health care)\b/i],['libraries / librarians',/\b(librar(?:y|ies|ians?))\b/i],['firms / industry',/\b(smes?|small business|firms?|industry|enterprises?|companies)\b/i],['rural / developing regions',/\b(rural|developing countr(?:y|ies)|global south|low-income)\b/i],['public sector / policy',/\b(government|public sector|policy ?makers?)\b/i],['online / social platforms',/\b(online|social media|mooc|e-learning|digital platform)\b/i]];
const DESIGN=[['longitudinal / panel design',/\b(longitudinal|panel data|cohort|follow-up)\b/i],['randomised / experimental design',/\b(randomi[sz]ed|experiment(?:al)?|quasi-experiment\w*)\b/i],['mixed methods',/\bmixed[- ]methods?\b/i],['qualitative inquiry',/\b(qualitative|interviews?|focus groups?|ethnograph\w+)\b/i],['cross-sectional survey',/\b(survey|questionnaire|cross-sectional)\b/i],['systematic review / meta-analysis',/\b(systematic review|meta-analys\w+)\b/i],['case study',/\bcase stud(?:y|ies)\b/i],['computational / data-driven',/\b(machine learning|deep learning|text mining|big data|algorithm\w*)\b/i]];
const THEORY=[['technology acceptance (TAM/UTAUT)',/\b[Tt]echnology [Aa]cceptance|\bTAM\b|\bUTAUT\b/],['social cognitive / self-efficacy',/\b(self-efficacy|social cognitive)\b/i],['constructivist / learning theory',/\b(constructivis\w+|connectivis\w+|learning theory)\b/i],['diffusion of innovations',/\bdiffusion of innovations?\b/i],['information behaviour models',/\binformation (?:seeking|behaviou?r)\b/i],['sustainability frameworks (SDGs)',/\b(sustainab\w+|SDGs?)\b/],['knowledge management theory',/\bknowledge (?:management|sharing)\b/i]];
const OUTC=[['performance / achievement',/\b(performance|achievement|outcomes?)\b/i],['satisfaction / user experience',/\b(satisfaction|user experience|usability)\b/i],['wellbeing / mental health',/\b(well-?being|mental health|stress|anxiety)\b/i],['equity / inclusion / access',/\b(equity|inclusion|inclusive|accessib\w+|digital divide)\b/i],['ethics / privacy / trust',/\b(ethic\w*|privacy|trust|bias|responsible)\b/i],['cost / economic impact',/\b(cost|economic|productivity|return on investment)\b/i]];

/* ---------- semantic tags (auto facets + my tags + imported tags) ---------- */
const TG={cut:null};
function tgCuts(){if(TG.cut&&TG.R===R)return TG.cut;const a=Float64Array.from(R,r=>+r[0]||0).sort();const p=q=>a[Math.min(a.length-1,Math.floor(a.length*q))];TG.R=R;return TG.cut={p95:p(.95),p75:p(.75),p50:p(.5)}}
const tgStore=()=>lsGet('x4Tags',{});
function autoTags(i){const o=recObj(i),txt=(o.title||'')+' '+(o.keywords||'')+' '+(o.abstract||''),out=[],seen=new Set(),add=(f,t)=>{t=String(t||'').trim();if(!t)return;const k=f+'|'+t.toLowerCase();if(seen.has(k))return;seen.add(k);out.push([f,t])};
 splitKeywords(o.keywords).slice(0,6).forEach(k=>add('Topic',k));riMethodsFor(o).forEach(m=>add('Method',m));
 [[DESIGN,'Design'],[CTX,'Context'],[THEORY,'Theory'],[OUTC,'Outcome']].forEach(([L,f])=>L.forEach(([n,re])=>re.test(txt)&&add(f,n)));
 const t=o.title||'';add('Type',/review|meta-analys|bibliometric|scoping|state of the art|overview|mapping/i.test(t)?'Review / synthesis':/theor|conceptual|framework|perspective|viewpoint|editorial|commentary/i.test(t)?'Conceptual / commentary':'Empirical / applied study');
 const c=tgCuts(),n=+o.cites||0;add('Impact',n>=c.p95&&n>0?'Highly cited (top 5%)':n>=c.p75&&n>0?'Well cited (top 25%)':n===0?'Not yet cited':'Moderately cited');
 const my=(M&&M.maxYear)||2025;if(o.year>=my-1)add('Recency','Recent (last 2 years)');else if(o.year<=my-8)add('Recency','Established (8+ years)');else add('Recency','Mid-range');
 if(o.country)add('Region',o.country);return out}
function allTags(i){const s=tgStore()[recKey(i)]||{},a=autoTags(i);(s.user||[]).forEach(t=>a.push(['MyTags',t]));(s.imp||[]).forEach(t=>a.push(['Imported',t]));return a}
function addUserTag(i,tag,kind='user'){tag=String(tag||'').trim();if(!tag)return false;const S=tgStore(),k=recKey(i),e=S[k]||(S[k]={user:[],imp:[]});const arr=e[kind]||(e[kind]=[]);if(!arr.includes(tag))arr.push(tag);return lsPut('x4Tags',S)}
function rmUserTag(i,tag,kind='user'){const S=tgStore(),k=recKey(i);if(S[k]&&S[k][kind]){S[k][kind]=S[k][kind].filter(t=>t!==tag);lsPut('x4Tags',S)}}
const tagHtml=(f,t,n)=>`<span class="tag4 f-${f}" data-tf="${esc(f)}" data-tt="${esc(t)}" title="${esc(f)}">${esc(t)}${n!=null?`<small>${n}</small>`:''}</span>`;
function semTags(el){
 el.innerHTML=`<div class="note">Every record is tagged automatically along ten semantic facets (topic, method, design, context, theory, outcome, article type, citation impact, recency, region). You can add your own tags and import tags from files (Import tab). Tags feed the Blockchain ledger and AI Search.</div>
 <div class="row">${SC}<label>Facet <select id="x4tf"><option value="">All facets</option>${['Topic','Method','Design','Context','Theory','Outcome','Type','Impact','Recency','Region','MyTags','Imported'].map(f=>`<option>${f}</option>`).join('')}</select></label><input type="text" id="x4tq" placeholder="filter tags…" size="18"><button class="ghost" id="x4tj">⇩ Tags JSON</button><button class="ghost" id="x4tc">⇩ Tags CSV</button><button class="ghost" id="x4tt">⇩ Tags Turtle</button></div>
 <div class="row"><b>＋ Tag all listed papers:</b><input type="text" id="x4bulk" placeholder="my tag" size="20"><button class="primary" id="x4bulkb">＋ Add</button><span class="tiny" id="x4tinfo"></span></div><div id="x4tf-body"></div><div id="x4tf-list"></div>`;
 let sel=null;
 const build=()=>{const ix=hits(),fac=Q('#x4tf').value,q=norm(Q('#x4tq').value),M2=new Map();ix.forEach(i=>allTags(i).forEach(([f,t])=>{if(fac&&f!==fac)return;if(q&&!norm(t).includes(q))return;const k=f+'\u0001'+t;(M2.get(k)||M2.set(k,[]).get(k)).push(i)}));
  const byF=new Map();M2.forEach((v,k)=>{const [f,t]=k.split('\u0001');(byF.get(f)||byF.set(f,[]).get(f)).push([t,v])});
  Q('#x4tf-body').innerHTML=[...byF].map(([f,a])=>`<div class="card"><b>${esc(f)}</b> <span class="tiny">${a.length} tags</span><div>${a.sort((x,y)=>y[1].length-x[1].length).slice(0,40).map(([t,v])=>tagHtml(f,t,v.length)).join('')}</div></div>`).join('')||'<p class="tiny">No tags match.</p>';
  Q('#x4tinfo').textContent=ix.length+' papers in scope';TG.map=M2;TG.ix=ix;if(sel)list(sel[0],sel[1])};
 const list=(f,t)=>{sel=[f,t];const v=(TG.map.get(f+'\u0001'+t)||[]).slice().sort((a,b)=>R[b][0]-R[a][0]).slice(0,40);
  Q('#x4tf-list').innerHTML=`<h3>${tagHtml(f,t)} <span class="tiny">${(TG.map.get(f+'\u0001'+t)||[]).length} papers</span></h3>`+v.map(i=>`<div class="card"><a href="#" data-p="${i}"><b>${esc(R[i][2])}</b></a><div class="tiny">${esc(R[i][1])} · ${R[i][3]} · ${R[i][0]} cites</div><div>${allTags(i).map(([ff,tt])=>tagHtml(ff,tt)).join('')}</div><div class="row"><input type="text" data-addtag="${i}" placeholder="＋ add my tag, press Enter" size="26">${(tgStore()[recKey(i)]?.user||[]).map(tt=>`<button class="ghost" data-rm="${i}" data-t="${esc(tt)}">✕ ${esc(tt)}</button>`).join('')}</div></div>`).join('')};
 Q('#x4tf').onchange=build;Q('#x4tq').oninput=build;Q('#x3n').onchange=build;build();
 Q('#x4bulkb').onclick=()=>{const t=Q('#x4bulk').value.trim();if(!t)return toast('Type a tag first');TG.ix.forEach(i=>addUserTag(i,t));toast('Tag added to '+TG.ix.length+' papers');build()};
 el.onclick=e=>{const c=e.target.closest('[data-tt]'),p=e.target.closest('[data-p]'),rm=e.target.closest('[data-rm]');if(rm){rmUserTag(+rm.dataset.rm,rm.dataset.t);build();return}if(c){list(c.dataset.tf,c.dataset.tt);Q('#x4tf-list').scrollIntoView({block:'nearest'})}if(p){e.preventDefault();x4Detail(+p.dataset.p,()=>semOpen('tg'),'Semantic tags')}};
 el.onkeydown=e=>{const a=e.target.dataset?.addtag;if(a!==undefined&&e.key==='Enter'){addUserTag(+a,e.target.value);build()}};
 const rows=()=>TG.ix.map(i=>({id:recKey(i),doi:doiOf(R[i][9]),title:R[i][2],tags:allTags(i).map(([f,t])=>({facet:f,tag:t}))}));
 Q('#x4tj').onclick=()=>download('semantic-tags.json',JSON.stringify({format:'are-semantic-tags/1',records:rows()},null,1),'application/json');
 Q('#x4tc').onclick=()=>download('semantic-tags.csv','doi,title,tags\n'+rows().map(r=>[CSVq(r.doi),CSVq(r.title),CSVq(r.tags.map(t=>t.facet+':'+t.tag).join('; '))].join(',')).join('\n'),'text/csv');
 Q('#x4tt').onclick=()=>{let t=PFXT();rows().forEach(r=>{const pu=r.doi?'https://doi.org/'+r.doi:BASE+'paper/'+slug(r.title);t+=`<${pu}> dcterms:title ${lit(r.title)} ;`+r.tags.map(x=>` dcterms:subject <${BASE}tag/${slug(x.facet)}/${slug(x.tag)}> ;`).join('')+' a schema:ScholarlyArticle .\n';});const seen=new Set();rows().forEach(r=>r.tags.forEach(x=>{const u=BASE+'tag/'+slug(x.facet)+'/'+slug(x.tag);if(seen.has(u))return;seen.add(u);t+=`<${u}> a skos:Concept ; skos:prefLabel ${lit(x.tag)} ; skos:inScheme <${BASE}tag/${slug(x.facet)}> .\n`}));download('semantic-tags.ttl',t,'text/turtle')}}
function x4Detail(i,back,label){detail(i);const b=document.createElement('div');b.innerHTML=backBtn(back,label);Q('#modalBody').prepend(b.firstChild);Q('#x4back').onclick=back}
window.x4Detail=x4Detail;

/* ---------- Import (JSON / CSV / Turtle / N-Triples / JSON-LD) ---------- */
function parseCSV(t){const rows=[];let r=[],f='',q=false;for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++}else q=false}else f+=c}else if(c==='"')q=true;else if(c===','){r.push(f);f=''}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;r.push(f);f='';if(r.length>1||r[0]!=='')rows.push(r);r=[]}else f+=c}r.push(f);if(r.length>1||r[0]!=='')rows.push(r);return rows}
function parseTTL(src){const pre={},T=[];let i=0,n=src.length;const tok=[];
 const rd=()=>{while(i<n){const c=src[i];if(/\s/.test(c)){i++;continue}if(c==='#'){while(i<n&&src[i]!=='\n')i++;continue}break}};
 while(i<n){rd();if(i>=n)break;const c=src[i];
  if(c==='<'){const j=src.indexOf('>',i);tok.push({t:'i',v:src.slice(i+1,j)});i=j+1;continue}
  if(c==='"'||c==="'"){let q=c;if(src.startsWith(c.repeat(3),i))q=c.repeat(3);let j=i+q.length,s='';while(j<n&&!src.startsWith(q,j)){if(src[j]==='\\'){const e=src[j+1];s+=({n:'\n',t:'\t',r:'\r'})[e]??e;j+=2}else s+=src[j++]}j+=q.length;const L={t:'l',v:s};
   if(src.startsWith('^^',j)){j+=2;if(src[j]==='<'){const k=src.indexOf('>',j);L.dt=src.slice(j+1,k);j=k+1}else{const m=/^[^\s;,.()\[\]]+/.exec(src.slice(j));L.dtp=m?m[0]:'';j+=L.dtp.length}}else if(src[j]==='@'){const m=/^@[A-Za-z-]+/.exec(src.slice(j));if(m){L.lang=m[0];j+=m[0].length}}
   tok.push(L);i=j;continue}
  if(';,.[]()'.includes(c)){tok.push({t:'p',v:c});i++;continue}
  const m=/^[^\s;,()\[\]<>"']+/.exec(src.slice(i,i+300));let w=m?m[0]:src[i];i+=w.length;
  if(w.length>1&&w.endsWith('.')&&!/^\d+\.\d+$/.test(w)){w=w.slice(0,-1);tok.push({t:'w',v:w});tok.push({t:'p',v:'.'});continue}tok.push({t:'w',v:w})}
 const res=(x)=>{if(x.t==='i')return x.v;if(x.t==='w'){if(x.v==='a')return PFX.rdf+'type';const k=x.v.indexOf(':');if(k>=0&&pre[x.v.slice(0,k)]!==undefined)return pre[x.v.slice(0,k)]+x.v.slice(k+1);return x.v}if(x.t==='l')return x.v;return null};
 let p=0;while(p<tok.length){const x=tok[p];
  if(x.t==='w'&&/^@?prefix$/i.test(x.v)){const nm=tok[p+1].v.replace(/:$/,''),iri=tok[p+2].v;pre[nm]=iri;p+=3;if(tok[p]&&tok[p].v==='.')p++;continue}
  if(x.t==='w'&&/^@?base$/i.test(x.v)){p+=2;if(tok[p]&&tok[p].v==='.')p++;continue}
  const s=res(x);p++;let pred=null;
  while(p<tok.length){const y=tok[p];if(y.t==='p'&&y.v==='.'){p++;break}if(y.t==='p'&&y.v===';'){p++;pred=null;continue}if(y.t==='p'&&y.v===','){p++;continue}
   if(pred===null){pred=res(y);p++;continue}
   if(y.t==='p'){p++;continue}
   const o=res(y);T.push([s,pred,o,y.t==='l'?'l':'i']);p++}}
 return T}
function parseJSONLD(j){const T=[],g=Array.isArray(j)?j:(j['@graph']||[j]);g.forEach(n=>{const s=n['@id'];if(!s)return;Object.entries(n).forEach(([k,v])=>{if(k==='@id')return;[].concat(v).forEach(x=>{if(k==='@type')T.push([s,PFX.rdf+'type',x,'i']);else if(x&&typeof x==='object'){if(x['@id'])T.push([s,X(k),x['@id'],'i']);else if('@value'in x)T.push([s,X(k),String(x['@value']),'l'])}else if(x!=null)T.push([s,X(k),String(x),'l'])})})});return T}
function graphToImport(T,facet){const by=new Map();T.forEach(t=>(by.get(t[0])||by.set(t[0],[]).get(t[0])).push(t));const ty=PFX.rdf+'type',lab=new Map(),concepts=[],recs=[];
 const P=n=>X(n),pref=P('skos:prefLabel'),alt=P('skos:altLabel'),subj=[P('dcterms:subject'),'http://purl.org/dc/elements/1.1/subject',P('schema:keywords'),'https://schema.org/about','http://schema.org/keywords'],title=[P('dcterms:title'),'http://purl.org/dc/elements/1.1/title','https://schema.org/name','http://schema.org/name'];
 by.forEach((a,s)=>{const l=a.find(t=>t[1]===pref||t[1]===P('rdfs:label'));if(l)lab.set(s,l[2])});
 by.forEach((a,s)=>{const isC=a.some(t=>t[1]===ty&&/Concept$/.test(t[2]));if(isC){const L=a.find(t=>t[1]===pref);if(L){const g=p=>a.filter(t=>t[1]===P('skos:'+p)).map(t=>t[3]==='i'?(lab.get(t[2])||t[2]):t[2]);concepts.push({label:L[2],alts:a.filter(t=>t[1]===alt).map(t=>t[2]),broader:g('broader'),narrower:g('narrower'),related:g('related')})}return}
  const tt=a.find(t=>title.includes(t[1])),doiT=a.find(t=>t[1]===P('prism:doi')||/#doi$/.test(t[1])),doi=doiT?doiT[2]:(/^https?:\/\/(dx\.)?doi\.org\//i.test(s)?doiOf(s):''),tags=a.filter(t=>subj.includes(t[1])).map(t=>t[3]==='i'?(lab.get(t[2])||t[2].split('/').pop().replace(/[-_]+/g,' ')):t[2]);
  if((tt||doi)&&tags.length)recs.push({doi,title:tt?tt[2]:'',tags:tags.map(t=>({facet,tag:t}))})});return{records:recs,concepts}}
function parseImport(text,fmt,facet){text=text.replace(/^﻿/,'').trim();if(!text)throw new Error('Nothing to import');
 if(fmt==='auto'){if(/^[\[{]/.test(text))fmt=/"@(graph|id|context)"/.test(text)?'jsonld':'json';else if(/^(@prefix|@base|PREFIX|<)/im.test(text)||/\s\.\s*$/m.test(text)&&/<http/.test(text))fmt='ttl';else fmt='csv'}
 if(fmt==='ttl')return graphToImport(parseTTL(text),facet);
 if(fmt==='jsonld')return graphToImport(parseJSONLD(JSON.parse(text)),facet);
 if(fmt==='json'){const j=JSON.parse(text),arr=Array.isArray(j)?j:(j.records||j.data||null),norm1=t=>typeof t==='string'?{facet,tag:t}:{facet:t.facet||facet,tag:String(t.tag??t.label??t.name??'')};
  if(arr)return{records:arr.map(r=>({doi:doiOf(r.doi||r.DOI||''),title:r.title||r.Title||'',tags:[].concat(r.tags||r.keywords||r.subjects||[]).flatMap(t=>typeof t==='string'?t.split(/[;|]/):[t]).map(norm1).filter(t=>t.tag.trim())})).filter(r=>r.tags.length),concepts:(j.concepts||[]).map(c=>({label:c.label,alts:c.alts||c.altLabels||[],broader:c.broader||[],narrower:c.narrower||[],related:c.related||[]}))};
  return{records:Object.entries(j).filter(([k,v])=>Array.isArray(v)).map(([k,v])=>({doi:/^10\./.test(doiOf(k))?doiOf(k):'',title:/^10\./.test(doiOf(k))?'':k,tags:v.map(norm1).filter(t=>t.tag.trim())})),concepts:[]}}
 const rows=parseCSV(text),h=rows[0].map(x=>norm(x).trim()),ci=n=>h.findIndex(x=>n.includes(x)),di=ci(['doi']),ti=ci(['title']),gi=ci(['tags','tag','keywords','subjects','subject','concepts']);if(gi<0||(di<0&&ti<0))throw new Error('CSV needs a "doi" or "title" column and a "tags" column');
 return{records:rows.slice(1).map(r=>({doi:doiOf(di>=0?r[di]:''),title:ti>=0?(r[ti]||''):'',tags:String(r[gi]||'').split(/[;|]/).map(t=>t.trim()).filter(Boolean).map(t=>{const m=t.match(/^([A-Za-z]+):(.+)$/);return m&&/^(Topic|Method|Design|Context|Theory|Outcome|Type|Impact|Recency|Region|MyTags|Imported)$/.test(m[1])?{facet:m[1],tag:m[2].trim()}:{facet,tag:t}})})).filter(r=>r.tags.length),concepts:[]}}
const IMP={};
function impMaps(){if(IMP.R===R)return IMP;IMP.R=R;IMP.doi=new Map();IMP.tit=new Map();for(let i=0;i<R.length;i++){const d=doiOf(R[i][9]).toLowerCase();if(d)IMP.doi.set(d,i);const t=tnorm(R[i][2]);if(t&&!IMP.tit.has(t))IMP.tit.set(t,i)}return IMP}
function semIm(el){
 el.innerHTML=`<div class="note"><b>Import semantic tags &amp; concepts.</b> Supported: <b>CSV</b> (columns <code>doi</code>/<code>title</code> + <code>tags</code>), <b>JSON</b> (this app's tag export, <code>{"10.1234/x":["tag"]}</code>, or an array of records), <b>Turtle / N-Triples / JSON-LD</b> (<code>dcterms:subject</code> on papers, <code>skos:Concept</code> with prefLabel/altLabel/broader/narrower). Records are matched to your library by DOI, then by exact title.</div>
 <div class="row"><input type="file" id="x4if" accept=".csv,.json,.jsonld,.ttl,.nt,.txt"><label>Format <select id="x4ifmt"><option value="auto">Auto-detect</option><option value="csv">CSV</option><option value="json">JSON</option><option value="ttl">Turtle / N-Triples</option><option value="jsonld">JSON-LD</option></select></label><label>Facet for imported tags <input type="text" id="x4ifc" value="Imported" size="12"></label></div>
 <textarea id="x4itx" rows="7" placeholder="…or paste CSV / JSON / Turtle here"></textarea>
 <div class="row"><button class="ghost" id="x4ipv">Preview</button><button class="primary" id="x4iap" disabled>⇩ Apply import</button><button class="ghost" id="x4itpl">Download CSV template</button><button class="ghost" id="x4iclr">Remove all imported tags</button><span class="tiny" id="x4iinfo"></span></div><div id="x4ires"></div>`;
 Q('#x4if').onchange=async e=>{const f=e.target.files[0];if(!f)return;Q('#x4itx').value=await f.text();const n=f.name.toLowerCase();Q('#x4ifmt').value=/\.csv$/.test(n)?'csv':/\.jsonld$/.test(n)?'jsonld':/\.json$/.test(n)?'json':/\.(ttl|nt)$/.test(n)?'ttl':'auto';preview()};
 const preview=()=>{try{const facet=Q('#x4ifc').value.trim()||'Imported',P=parseImport(Q('#x4itx').value,Q('#x4ifmt').value,facet),mp=impMaps();let hit=0,miss=[];P.records.forEach(r=>{const i=(r.doi?mp.doi.get(r.doi.toLowerCase()):undefined)??mp.tit.get(tnorm(r.title));if(i===undefined||i===null)miss.push(r);else{r.i=i;hit++}});IMP.P=P;Q('#x4iap').disabled=!(hit||P.concepts.length);
  Q('#x4iinfo').textContent='';Q('#x4ires').innerHTML=`<div class="card"><span class="badge4 ok">${hit} matched</span><span class="badge4 ${miss.length?'warn':''}">${miss.length} not found in library</span><span class="badge4">${P.concepts.length} concepts</span></div>`+(hit?`<table><tr><th>Matched paper</th><th>Tags to add</th></tr>${P.records.filter(r=>r.i!==undefined).slice(0,15).map(r=>`<tr><td>${esc(R[r.i][2])}</td><td>${r.tags.map(t=>tagHtml(t.facet,t.tag)).join('')}</td></tr>`).join('')}</table>`:'')+(miss.length?`<p class="tiny">Unmatched (first 8): ${miss.slice(0,8).map(r=>esc(r.doi||r.title)).join(' · ')}</p>`:'')+(P.concepts.length?`<p><b>Concepts:</b> ${P.concepts.slice(0,25).map(c=>`<span class="chip">${esc(c.label)}${c.alts.length?` <small>+${c.alts.length} syn</small>`:''}</span>`).join('')}</p>`:'')}catch(e){IMP.P=null;Q('#x4iap').disabled=true;Q('#x4ires').innerHTML='<p class="bad">⚠ '+esc(e.message||e)+'</p>'}};
 Q('#x4ipv').onclick=preview;
 Q('#x4iap').onclick=()=>{const P=IMP.P;if(!P)return;let n=0;const S=tgStore();P.records.forEach(r=>{if(r.i===undefined)return;const k=recKey(r.i),e=S[k]||(S[k]={user:[],imp:[]});r.tags.forEach(t=>{const lbl=t.facet&&t.facet!=='Imported'?t.facet+': '+t.tag:t.tag;if(!(e.imp=e.imp||[]).includes(lbl)){e.imp.push(lbl);n++}})});
  const Y=lsGet('x4Syn',{});P.concepts.forEach(c=>{const k=stem(c.label);Y[k]={label:c.label,alts:[...new Set([...(Y[k]?.alts||[]),...c.alts])],rel:[...new Set([...(Y[k]?.rel||[]),...c.broader,...c.narrower,...c.related])]}});
  if(lsPut('x4Tags',S)&&lsPut('x4Syn',Y))toast(n+' tags and '+P.concepts.length+' concepts imported')};
 Q('#x4itpl').onclick=()=>download('semantic-tags-template.csv','doi,title,tags\n10.1000/example,"Example paper title","topic one; topic two; Method:survey"\n','text/csv');
 Q('#x4iclr').onclick=()=>{if(!confirm('Remove all imported tags and imported synonyms?'))return;const S=tgStore();Object.values(S).forEach(e=>e.imp=[]);lsPut('x4Tags',S);lsPut('x4Syn',{});toast('Imported tags removed')}}

/* ---------- Blockchain (local tamper-evident ledger of semantic annotations) ---------- */
const ZERO='0'.repeat(64);
const chainGet=()=>lsGet('x4Chain',[]);
const blockHash=b=>sha256([b.index,b.time,b.prev,b.merkle,b.nonce,b.label,b.n,JSON.stringify(b.meta||{})].join('|'));
function leafFor(i){const o=recObj(i),tags=allTags(i).map(x=>x[0]+':'+x[1]).sort();return sha256(JSON.stringify({id:recKey(i),title:o.title,year:o.year,tags}))}
function verifyChain(C){C=C||chainGet();let prev=ZERO;for(let k=0;k<C.length;k++){const b=C[k];if(b.index!==k)return{ok:false,at:k,why:'index out of sequence'};if(b.prev!==prev)return{ok:false,at:k,why:'previous-hash link broken'};if(blockHash(b)!==b.hash)return{ok:false,at:k,why:'block contents do not match its hash (edited)'};if(!b.hash.startsWith('0'.repeat((b.meta&&b.meta.diff)||0)))return{ok:false,at:k,why:'proof-of-work target not met'};if(merkle((b.items||[]).map(x=>x.leaf))!==b.merkle)return{ok:false,at:k,why:'Merkle root does not match sealed records'};prev=b.hash}return{ok:true,at:-1}}
async function mineBlock(b,diff){const pre='0'.repeat(diff);let n=0;for(;;){b.nonce=n;b.hash=blockHash(b);if(b.hash.startsWith(pre))return b;n++;if(n%2500===0)await new Promise(r=>setTimeout(r,0))}}
const sh=(h,n=10)=>h?h.slice(0,n)+'…'+h.slice(-6):'';
function semBc(el){
 const draw=()=>{const C=chainGet(),V=verifyChain(C);
  el.innerHTML=`<div class="note"><b>Semantic blockchain ledger.</b> Seal the semantic tags of your current result set into a block: each record's tags are hashed (SHA-256), combined in a <b>Merkle tree</b>, and chained to the previous block with optional proof-of-work. Any later change to a sealed block or to a record's tags is detected. <span class="tiny">This is a private, local, tamper-evident chain in your browser — not a public cryptocurrency network. To timestamp publicly, copy a block hash and anchor it with <a href="https://opentimestamps.org" target="_blank" rel="noopener">OpenTimestamps</a> or a DOI service such as Zenodo.</span></div>
  <div class="card"><b>Seal a new block</b><div class="row">${SC}<label>Label <input type="text" id="x4bl" size="24" value="${esc(state.query?'Tags: '+state.query:'Semantic tags snapshot')}"></label><label>Difficulty <select id="x4bd"><option>0</option><option>1</option><option>2</option><option selected>3</option><option>4</option></select></label><button class="primary" id="x4bs">⛓ Seal &amp; mine block</button><span class="tiny" id="x4bi"></span></div></div>
  <div class="row"><b>${C.length} block(s)</b> <span class="badge4 ${V.ok?'ok':'bad'}" id="x4vs">${V.ok?(C.length?'✓ chain valid':'empty'):'✗ invalid at block #'+V.at+': '+esc(V.why)}</span><button class="ghost" id="x4bv">Verify chain</button><button class="ghost" id="x4be">⇩ Export ledger</button><button class="ghost" id="x4bim">⬆ Import ledger</button><button class="ghost" id="x4br">Reset</button></div>
  <div style="overflow:auto"><table><tr><th>#</th><th>Sealed</th><th>Label</th><th>Records</th><th>Merkle root</th><th>Block hash</th><th>Nonce</th><th></th></tr>${C.slice().reverse().map(b=>`<tr><td>${b.index}</td><td class="tiny">${esc(b.time.replace('T',' ').slice(0,19))}</td><td>${esc(b.label)}</td><td>${b.n}</td><td class="mono" title="${b.merkle}">${sh(b.merkle)}</td><td class="mono" title="${b.hash}">${sh(b.hash)}</td><td>${b.nonce}</td><td>${V.ok||b.index<V.at?'<span class="chain-ok">✓</span>':b.index===V.at?'<span class="chain-bad">✗</span>':'<span class="chain-bad">?</span>'}</td></tr>`).join('')||'<tr><td colspan="8" class="tiny">No blocks yet. Seal your first block above — a genesis block is created automatically.</td></tr>'}</table></div>
  <div class="card"><b>Prove a record</b> <span class="tiny">— check that a record's tags were sealed and are unchanged</span><div class="row"><input type="text" id="x4pq" placeholder="DOI or part of the title" size="40"><button class="ghost" id="x4pg">Find &amp; verify</button></div><div id="x4pr"></div></div>
  <textarea id="x4bt" rows="3" style="display:none" placeholder="Paste exported ledger JSON here"></textarea><div class="row" id="x4bimrow" style="display:none"><input type="file" id="x4bf" accept=".json"><button class="primary" id="x4bimgo">Verify &amp; import</button></div>`;
  Q('#x4bs').onclick=async()=>{const btn=Q('#x4bs'),ix=hits();if(!ix.length)return toast('No records in scope');btn.disabled=true;Q('#x4bi').textContent='Hashing '+ix.length+' records…';await new Promise(r=>setTimeout(r,20));
   let C2=chainGet();if(!C2.length){const g={index:0,time:new Date().toISOString(),prev:ZERO,merkle:merkle([]),nonce:0,label:'Genesis block',n:0,meta:{diff:0,type:'genesis'},items:[]};g.hash=blockHash(g);C2=[g]}
   const items=ix.map(i=>({id:recKey(i),title:String(R[i][2]).slice(0,90),leaf:leafFor(i)})),diff=+Q('#x4bd').value,b={index:C2.length,time:new Date().toISOString(),prev:C2[C2.length-1].hash,merkle:merkle(items.map(x=>x.leaf)),nonce:0,label:Q('#x4bl').value.trim()||'Semantic snapshot',n:items.length,meta:{diff,type:'semantic-tags',query:state.query||'',scope:ix.length},items};
   Q('#x4bi').textContent='Mining (difficulty '+diff+')…';await mineBlock(b,diff);C2.push(b);if(lsPut('x4Chain',C2)){toast('Block #'+b.index+' sealed');draw()}else btn.disabled=false};
  Q('#x4bv').onclick=()=>{draw();toast(verifyChain().ok?'Chain verified ✓':'Chain is NOT valid')};
  Q('#x4be').onclick=()=>download('semantic-ledger.json',JSON.stringify({format:'are-semantic-ledger/1',chain:chainGet()},null,1),'application/json');
  Q('#x4br').onclick=()=>{if(confirm('Delete the entire local ledger? This cannot be undone.')){lsPut('x4Chain',[]);draw()}};
  Q('#x4bim').onclick=()=>{Q('#x4bt').style.display='block';Q('#x4bimrow').style.display='flex'};
  Q('#x4bf').onchange=async e=>{if(e.target.files[0])Q('#x4bt').value=await e.target.files[0].text()};
  Q('#x4bimgo').onclick=()=>{try{const j=JSON.parse(Q('#x4bt').value),C3=Array.isArray(j)?j:j.chain,v=verifyChain(C3);if(!Array.isArray(C3)||!C3.length)throw new Error('No chain found');if(!v.ok)throw new Error('Imported ledger is invalid at block #'+v.at+': '+v.why);if(chainGet().length&&!confirm('Replace the current ledger ('+chainGet().length+' blocks) with the imported valid ledger ('+C3.length+' blocks)?'))return;lsPut('x4Chain',C3);toast('Ledger imported and verified');draw()}catch(e){toast('Import failed: '+(e.message||e))}};
  Q('#x4pg').onclick=()=>{const q=Q('#x4pq').value.trim().toLowerCase(),box=Q('#x4pr');if(!q)return;const found=[];C.forEach(b=>(b.items||[]).forEach((it,ix)=>{if(it.id.toLowerCase().includes(q)||it.title.toLowerCase().includes(q))found.push({b,it,ix})}));
   if(!found.length){box.innerHTML='<p class="bad">No sealed record matches.</p>';return}
   const mp=new Map();for(let i=0;i<R.length;i++)mp.set(recKey(i),i);
   box.innerHTML=found.slice(-6).reverse().map(({b,it,ix})=>{const leaves=b.items.map(x=>x.leaf),path=merkleProof(leaves,ix),okP=verifyProof(it.leaf,path,b.merkle),ri=mp.get(it.id),cur=ri!==undefined?leafFor(ri):null,same=cur===it.leaf;
    return `<div class="card"><b>${esc(it.title)}</b><div class="tiny mono">${esc(it.id)}</div><div>${okP?'<span class="chain-ok">✓</span>':'<span class="chain-bad">✗</span>'} Included in block #${b.index} — Merkle proof of ${path.length} step(s) ${okP?'verifies':'FAILS'} against root <span class="mono">${sh(b.merkle)}</span></div><div>${cur===null?'<span class="badge4 warn">record not in current library</span>':same?'<span class="chain-ok">✓</span> Current semantic tags are identical to the sealed version':'<span class="badge4 warn">⚠ Tags changed since sealing</span> — re-seal to record the new state'}</div><div class="row"><button class="ghost" data-cert="${b.index}|${ix}">⇩ Proof certificate</button></div></div>`}).join('');
   box.onclick=e=>{const c=e.target.dataset.cert;if(!c)return;const [bi,ix]=c.split('|').map(Number),b=C[bi],it=b.items[ix];download('proof-'+it.id.replace(/[^a-z0-9]+/gi,'_').slice(0,40)+'.json',JSON.stringify({format:'are-merkle-proof/1',record:it,block:{index:b.index,time:b.time,prev:b.prev,merkle:b.merkle,nonce:b.nonce,label:b.label,n:b.n,meta:{...b.meta},hash:b.hash},proof:merkleProof(b.items.map(x=>x.leaf),ix)},null,1),'application/json')}}};
 draw()}

/* ---------- Research Gap Finder: more gap lenses + (+) detail toggles ---------- */
const gapLinks=(c)=>{const q=(c||[]).filter(Boolean).slice(0,3).map(x=>'"'+x+'"').join(' ');const e=encodeURIComponent(q+' systematic review');return `<a href="https://scholar.google.com/scholar?q=${e}" target="_blank" rel="noopener">Google Scholar ↗</a><a href="https://api.openalex.org/works?search=${encodeURIComponent(q)}" target="_blank" rel="noopener">OpenAlex ↗</a><a href="https://www.semanticscholar.org/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener">Semantic Scholar ↗</a><a href="https://search.crossref.org/?q=${encodeURIComponent(q)}" target="_blank" rel="noopener">Crossref ↗</a>`};
const GAP_DESIGN={'Explicit gap statement':'Replicate or extend the cited study addressing exactly the limitation the authors name; pre-register the design.','Underexplored concept intersection':'Cross-concept study (survey, experiment or text-mining) that measures both constructs in the same sample.','Methodological opportunity':'Triangulate with the under-used method and compare conclusions with the dominant method.','Geographic concentration signal':'Comparative multi-country replication with harmonised measures.'};
function gapRQ(g){if(g.rq)return g.rq;const [a,b]=g.concepts||[];switch(g.type){case 'Explicit gap statement':return `What evidence would resolve the limitation stated in the source abstract${a?` (topic: “${a}”)`:''}?`;case 'Underexplored concept intersection':return `How are “${a}” and “${b}” related, and under which conditions does one shape the other?`;case 'Methodological opportunity':return `Do the dominant findings on “${b}” still hold when studied with “${a}”?`;case 'Geographic concentration signal':return `Do findings on this topic generalise beyond ${a}?`;default:return `What does the literature still fail to explain about ${a||'this topic'}?`}}
function gapPlus(g){return `<div><b>Suggested research question:</b> ${esc(gapRQ(g))}</div><div style="margin-top:4px"><b>Suggested approach:</b> ${esc(g.design||GAP_DESIGN[g.type]||'Scope a focused literature check, then design an empirical or review study that targets this gap.')}</div><div style="margin-top:6px"><b>Validate in the wider literature:</b> ${gapLinks(g.concepts)}<button class="lnk ghost" data-gapq="${esc((g.concepts||[]).join(' '))}">Search in this explorer</button><button class="lnk ghost" data-gapcopy="${esc(gapRQ(g))}">Copy question</button></div>`}
function riMoreGaps(hits){const out=[],N=hits.length;if(!N)return out;const recs=hits.map(h=>({i:h.i,o:recObj(h.i)})),txt=o=>(o.title||'')+' '+(o.keywords||'')+' '+(o.abstract||'');
 const have=new Set(riGapAnalysis(hits).gaps.map(g=>norm(g.statement).slice(0,150))),push=g=>{const k=norm(g.statement).slice(0,150);if(have.has(k))return;have.add(k);out.push(g)};
 // 1. future-work directives (beyond the standard gap cues)
 const FW=/\b(?:should|could|must|needs? to) (?:be )?(?:further )?(?:explored|examined|investigated|addressed|tested|validated|replicated|extended)\b|\bfuture (?:studies|work|investigations?|directions?|scholars?)\b|\bremains? to be\b|\bopen questions?\b|\bunanswered\b|\bunresolved\b|\bwarrants?\b|\bcalls? for\b/i,seenFW=new Set(riExplicitGaps(hits).map(x=>norm(x.text).slice(0,130)));let nf=0;
 for(const r of recs){if(nf>=4)break;for(const s of riSentenceSplit(r.o.abstract)){const k=norm(s).slice(0,130);if(FW.test(s)&&!seenFW.has(k)){seenFW.add(k);nf++;push({type:'Future-work directive',statement:s,papers:[r.i],concepts:splitKeywords(r.o.keywords).slice(0,3),confidence:'high',basis:'Future-work wording found directly in the source abstract.',score:9});break}}}
 // 2-5. coverage lenses
 const cover=L=>L.map(([n,re])=>({n,p:recs.filter(r=>re.test(txt(r.o))).map(r=>r.i)}));
 const lens=(L,type,rq,dsg)=>{if(N<8)return;const c=cover(L),dom=c.slice().sort((a,b)=>b.p.length-a.p.length)[0];if(!dom||dom.p.length<2)return;c.filter(x=>x.n!==dom.n&&x.p.length<=Math.floor(N*.05)).sort((a,b)=>a.p.length-b.p.length).slice(0,2).forEach(x=>push({type,statement:(x.p.length?`Only ${x.p.length} of ${N} analysed records address ${x.n}`:`None of the ${N} analysed records mentions ${x.n}`)+`, whereas ${dom.n} appears in ${dom.p.length}. Closing this imbalance could broaden what the evidence base can support.`,papers:dom.p.slice(0,2).concat(x.p.slice(0,2)),concepts:[x.n,dom.n],confidence:'medium',basis:'Keyword/abstract pattern matching over the selected corpus; absence of a term is not proof the topic is unstudied.',rq:rq(x.n,dom.n),design:dsg,score:5}))};
 lens(CTX,'Context / population gap',(x,d)=>`Do findings from ${d} settings transfer to ${x}, and what moderates the difference?`,'Replicate a core study in the under-represented population or setting and test for measurement invariance.');
 lens(DESIGN,'Study-design gap',(x,d)=>`Would a ${x} approach confirm, refine or contradict conclusions drawn mainly from ${d} evidence?`,'Run a complementary study using the missing design and report convergence/divergence with existing evidence.');
 lens(THEORY,'Theoretical-framework gap',(x,d)=>`Can ${x} explain outcomes that ${d} leaves unexplained?`,'Test competing theoretical models on the same data, or build an integrated framework.');
 lens(OUTC,'Outcome-measure gap',(x,d)=>`What are the ${x} consequences of the phenomena currently assessed mostly through ${d}?`,'Add the missing outcome to an existing design (secondary analysis or follow-up wave).');
 // 6. temporal
 const ys=[...new Set(recs.map(r=>r.o.year).filter(Boolean))].sort((a,b)=>a-b);if(ys.length>=3){const mY=ys[ys.length-1],kws=riTopKeywords(hits,20);let nd=0,ne=0;kws.forEach(k=>{const ps=[...k.papers],rec=ps.filter(i=>recObj(i).year>=mY-1).length,old=ps.filter(i=>recObj(i).year<=mY-3).length;
   if(old>=3&&rec===0&&nd<2){nd++;push({type:'Temporal gap — fading topic',statement:`“${k.label}” appears in ${old} older record(s) but in none from the last two years (${mY-1}–${mY}) of this corpus. Re-examining it with current data or methods may be timely.`,papers:ps.slice(0,4),concepts:[k.label],confidence:'medium',basis:'Year distribution of keyword occurrences in the selected corpus.',rq:`Do earlier findings on “${k.label}” still hold under present-day conditions?`,design:'Update or replicate earlier studies with recent data; examine what changed.',score:4})}
   else if(rec>=1&&old===0&&ps.length<=3&&ne<2){ne++;push({type:'Temporal gap — emerging but thin',statement:`“${k.label}” appears only in recent records (${ps.length} record${ps.length===1?'':'s'}) and not before ${mY-2}. Evidence is still thin, so early systematic work could shape the field.`,papers:ps.slice(0,4),concepts:[k.label],confidence:'medium',basis:'Year distribution of keyword occurrences in the selected corpus.',rq:`What is the evidence base for “${k.label}”, and which questions are still open?`,design:'Scoping review followed by a first confirmatory study.',score:4})}})}
 // 7. visibility gap
 const cs=recs.map(r=>+r.o.cites||0).sort((a,b)=>a-b),med=cs[cs.length>>1]||0,low=recs.slice(0,10).filter(r=>(+r.o.cites||0)<=Math.max(1,Math.floor(med/4)));if(N>=10&&low.length>=2)push({type:'Visibility gap — relevant but under-cited',statement:`${low.length} of the 10 best-matching records have very few citations (≤${Math.max(1,Math.floor(med/4))} versus a median of ${med}). Their ideas may be under-recognised and ripe for replication or extension.`,papers:low.map(r=>r.i).slice(0,4),concepts:splitKeywords(low[0].o.keywords).slice(0,2),confidence:'medium',basis:'Citation counts in the dataset versus rank in this scope.',rq:'Do these under-cited studies replicate, and why did they receive little attention?',design:'Direct replication or citation-context analysis.',score:3});
 // 8. collaboration
 const single=recs.filter(r=>splitAuthors(r.o.authors).length===1);if(N>=10&&single.length/N>=.4)push({type:'Collaboration gap',statement:`${single.length} of ${N} analysed records (${Math.round(single.length/N*100)}%) are single-authored. Multi-team, multi-disciplinary or cross-institutional studies could strengthen reliability and breadth.`,papers:single.slice(0,4).map(r=>r.i),concepts:[],confidence:'medium',basis:'Author counts in the bibliographic metadata.',rq:'How would multi-site collaborative designs change the conclusions in this area?',design:'Consortium or multi-institution study with shared protocol.',score:3});
 // 9. venue concentration
 const vc=new Map();recs.forEach(r=>r.o.source&&vc.set(r.o.source,(vc.get(r.o.source)||0)+1));const vt=[...vc].sort((a,b)=>b[1]-a[1])[0];if(N>=10&&vt&&vt[1]/N>=.4)push({type:'Venue concentration gap',statement:`${vt[1]} of ${N} analysed records appear in a single source (“${vt[0]}”). Work published in other disciplines' venues may be missing from this picture.`,papers:recs.filter(r=>r.o.source===vt[0]).slice(0,3).map(r=>r.i),concepts:[vt[0]],confidence:'medium',basis:'Source/journal field of the selected records.',rq:'What do adjacent disciplines report on this topic that this venue does not cover?',design:'Cross-disciplinary systematic search across venues.',score:3});
 // 10. interdisciplinary pairs among a wider concept set
 const wp=riPairs(hits,20),co=new Set(wp.pairs.map(p=>[norm(p.a),norm(p.b)].sort().join('§'))),top10=new Set(wp.tops.slice(0,10).map(t=>norm(t.label)));let ni=0;
 for(let a=0;a<wp.tops.length&&ni<3;a++)for(let b=a+1;b<wp.tops.length&&ni<3;b++){const A=wp.tops[a],B=wp.tops[b];if(A.count<3||B.count<3)continue;if(top10.has(norm(A.label))&&top10.has(norm(B.label)))continue;if(co.has([norm(A.label),norm(B.label)].sort().join('§')))continue;ni++;push({type:'Interdisciplinary gap — never co-studied',statement:`“${A.label}” (${A.count} records) and “${B.label}” (${B.count} records) never occur together in this corpus.`,papers:[...A.papers].slice(0,2).concat([...B.papers].slice(0,2)),concepts:[A.label,B.label],confidence:'medium',basis:'Zero co-occurrence of two recurring keywords.',rq:`Is there a meaningful relationship between “${A.label}” and “${B.label}”?`,design:'Exploratory mapping study, then a targeted empirical test.',score:3})}
 // 11. thin geography
 const gc=new Map();recs.forEach(r=>r.o.country&&gc.set(r.o.country,(gc.get(r.o.country)||0)+1));const thin=[...gc].filter(x=>x[1]===1);if(N>=15&&gc.size>=3&&thin.length)push({type:'Geographic gap — single-record regions',statement:`Only one analysed record each comes from ${thin.slice(0,5).map(x=>x[0]).join(', ')}${thin.length>5?' and others':''}. Deeper regional evidence is missing for these contexts.`,papers:recs.filter(r=>thin.some(x=>x[0]===r.o.country)).slice(0,4).map(r=>r.i),concepts:thin.slice(0,3).map(x=>x[0]),confidence:'medium',basis:'Country metadata of selected records (publisher country; may differ from study location).',rq:'How do conditions in these under-represented regions change the findings?',design:'Regional case studies or comparative replication.',score:2});
 return out.sort((a,b)=>(b.confidence==='high')-(a.confidence==='high')||b.score-a.score)}
const gapCardHtml=(g,n,user)=>`<div class="gap-card x4gap"><button class="gap-plus" type="button" aria-expanded="false" title="Show research question, approach and validation links">+</button><div class="confidence ${g.confidence}">${esc(g.type)} · ${g.confidence} confidence</div><h3>Gap ${n}</h3><div>${esc(g.statement)}</div>${g.basis?`<div class="evidence-quote"><b>Basis:</b> ${esc(g.basis)}</div>`:''}<div class="ri-tagrow">${(g.concepts||[]).map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}</div>${(g.papers||[]).length?`<div class="tiny" style="margin-top:6px">Evidence: ${g.papers.slice(0,3).map(pi=>esc(recObj(pi).title)).join(' • ')}</div>`:''}${user!==undefined?`<div class="row"><button class="ghost" data-gapdel="${user}">✕ Remove</button></div>`:''}<div class="gap-more" hidden>${gapPlus(g)}</div></div>`;
const origGapModal=window.riGapModal;
window.riGapModal=function(focusIndex=null,graphOnly=false){origGapModal(focusIndex,graphOnly);if(graphOnly)return;const body=Q('#modalBody');if(!body||!body.querySelector('.gap-card')&&!body.querySelector('.ri-actions'))return;
 const hs=riScopeHits(focusIndex),base=riGapAnalysis(hs).gaps;
 [...body.querySelectorAll('.gap-card')].forEach((c,k)=>{if(c.querySelector('.gap-plus'))return;const g=base[k];if(!g)return;c.insertAdjacentHTML('afterbegin','<button class="gap-plus" type="button" aria-expanded="false" title="Show research question, approach and validation links">+</button>');c.insertAdjacentHTML('beforeend',`<div class="gap-more" hidden>${gapPlus(g)}</div>`)});
 const more=riMoreGaps(hs);let shown=0,total=base.length;const UG=()=>lsGet('x4UserGaps',[]);
 const box=document.createElement('div');box.className='ri-section';box.id='gapMoreBox';box.innerHTML=`<h3>＋ More research gaps <span class="badge4">${more.length} additional</span></h3><p class="tiny">Extra lenses: future-work statements, context/population, study design, theory, outcomes, temporal trends, visibility, collaboration, venue, interdisciplinary and geographic gaps. Click <b>+</b> on any card for a research question, approach and validation links.</p><div id="gapMoreList"></div><div class="row"><button class="primary gap" id="gapMoreBtn" type="button">＋ Show more gaps</button><button class="ghost" id="gapAddBtn" type="button">＋ Add my own gap</button></div><div id="gapAddForm" style="display:none" class="card"><textarea id="gapAddTx" rows="3" placeholder="Describe the gap you see…"></textarea><div class="row"><input type="text" id="gapAddCo" placeholder="concepts, comma separated" size="30"><button class="primary" id="gapAddOk" type="button">Save gap</button></div></div><div id="gapUserList"></div>`;
 body.appendChild(box);
 const renderUser=()=>{Q('#gapUserList').innerHTML=UG().map((g,k)=>gapCardHtml({type:'My own gap',statement:g.text,concepts:g.concepts,confidence:'medium',basis:'Added by you.',papers:[]},'U'+(k+1),k)).join('')};renderUser();
 const step=()=>{const nxt=more.slice(shown,shown+4);Q('#gapMoreList').insertAdjacentHTML('beforeend',nxt.map((g,k)=>gapCardHtml(g,total+shown+k+1)).join(''));shown+=nxt.length;const b=Q('#gapMoreBtn');b.textContent=shown>=more.length?'No more gaps':`＋ Show more gaps (${more.length-shown} left)`;b.disabled=shown>=more.length;if(!more.length)Q('#gapMoreList').innerHTML='<div class="note">No additional gap signals in this scope. Increase the analysis scope (Top 40 / Top 100) to enable more lenses.</div>'};
 step();Q('#gapMoreBtn').onclick=step;Q('#gapAddBtn').onclick=()=>{const f=Q('#gapAddForm');f.style.display=f.style.display==='none'?'block':'none'};
 Q('#gapAddOk').onclick=()=>{const t=Q('#gapAddTx').value.trim();if(!t)return toast('Describe the gap first');const L=UG();L.push({text:t,concepts:Q('#gapAddCo').value.split(',').map(x=>x.trim()).filter(Boolean)});lsPut('x4UserGaps',L);Q('#gapAddTx').value='';Q('#gapAddForm').style.display='none';renderUser();toast('Gap added')};
 if(!body.dataset.gapBound){body.dataset.gapBound='1';body.addEventListener('click',e=>{const t=e.target;
  if(t.classList&&t.classList.contains('gap-plus')){const m=t.parentElement.querySelector('.gap-more');if(!m)return;const open=m.hidden;m.hidden=!open;t.textContent=open?'−':'+';t.setAttribute('aria-expanded',String(open));return}
  if(t.dataset&&t.dataset.gapq!==undefined){$('#q').value=t.dataset.gapq;closeModal();$('#searchForm').requestSubmit();return}
  if(t.dataset&&t.dataset.gapcopy!==undefined){copyText(t.dataset.gapcopy);return}
  if(t.dataset&&t.dataset.gapdel!==undefined){const L=lsGet('x4UserGaps',[]);L.splice(+t.dataset.gapdel,1);lsPut('x4UserGaps',L);const u=Q('#gapUserList');if(u)u.innerHTML=L.map((g,k)=>gapCardHtml({type:'My own gap',statement:g.text,concepts:g.concepts,confidence:'medium',basis:'Added by you.',papers:[]},'U'+(k+1),k)).join('')}})}};

/* ---------- AI Search ---------- */
const AI={msgs:[],ctx:null,cfg:lsGet('x4AI',{mode:'local',model:'claude-sonnet-5-5',endpoint:'https://api.openai.com/v1',key:''}),busy:false};
const STOP=new Set('a an the and or of in on for to with by from at as is are was were be been being what which who whom whose how why when where do does did can could should would will shall may might me my we our you your i it its this that these those about into over under between among across any some all most more less than then there here show find list give tell please papers paper articles article studies study research literature work works publications publication regarding related relating using use used based new latest recent top best main key major important highly cited most-cited much many few get want need looking look search explain describe summarise summarize overview summary compare comparison versus vs also not no only just exist exists existing leading lead known field area topic topics about'.split(' '));
const root1=t=>t.replace(/ies$/,'y').replace(/(?<=[a-z]{3})(?:ing|ed|es|s)$/,'');
function aiParse(q0){let s=' '+q0+' ',f={},m;const my=(M&&M.maxYear)||new Date().getFullYear(),cut=re=>{const mm=s.match(re);if(mm)s=s.replace(mm[0],' ');return mm};
 if(m=cut(/\b(?:between|from)\s+((?:19|20)\d\d)\s*(?:and|to|-|–)\s*((?:19|20)\d\d)\b/i)){f.from=+m[1];f.to=+m[2]}
 else{if(m=cut(/\b(?:since|after|from|post|starting)\s+((?:19|20)\d\d)\b/i))f.from=+m[1];if(m=cut(/\b(?:before|until|up to|prior to|through)\s+((?:19|20)\d\d)\b/i))f.to=+m[1];if(m=cut(/\b(?:in|during|of|year)\s+((?:19|20)\d\d)\b/i)){f.from=f.to=+m[1]}}
 if(m=cut(/\b(?:last|past|recent|previous)\s+(\d{1,2})\s+years?\b/i))f.from=my-(+m[1])+1;
 if(m=cut(/(?:more than|over|at least|minimum of|>=?|≥)\s*(\d+)\s*(?:citations?|cites)/i))f.minCites=+m[1];
 if(cut(/\b(highly cited|most cited|top cited|influential|landmark|seminal)\b/i))f.high=true;
 if(cut(/\b(newest|latest|most recent)\b/i))f.sort='newest';
 const ns=' '+norm(s)+' ';for(const c of (CO||[])){if(c&&ns.includes(' '+norm(c)+' ')){f.country=c;s=s.replace(new RegExp('\\b(?:from|in|by|publishers? (?:in|from))?\\s*'+c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','i'),' ');break}}
 const low=norm(q0);let intent='search';if(/\bhypothes/.test(low))intent='hyp';else if(/\b(gaps?|understudied|underexplored|unexplored|research opportunit|future research|what.s missing|missing)\b/.test(low))intent='gaps';else if(/\b(trends?|over time|evolution|growth|timeline|emerging|per year|history)\b/.test(low))intent='trends';else if(/\b(journals?|venues?|where (?:to|can|should) (?:i )?(?:publish|submit))\b/.test(low))intent='journals';else if(/\b(authors?|researchers?|experts?|scholars?|who (?:is|are|has|have|works?|publish))\b/.test(low))intent='authors';else if(/\b(vs\.?|versus|compare|comparison|compared (?:to|with)|difference between)\b/.test(low))intent='compare';
 let cmp=null;if(intent==='compare'){const mm=s.match(/(.+?)\s+(?:vs\.?|versus|compared (?:to|with)|and)\s+(.+)/i)||s.match(/(?:compare|comparison|difference between)\s+(.+?)\s+(?:and|with|to)\s+(.+)/i);if(mm)cmp=[mm[1],mm[2]]}
 const terms=t=>tokens(t).filter(w=>!STOP.has(w)&&!/^(?:19|20)\d\d$/.test(w)&&w.length>1&&!/^(trends?|gaps?|hypothes[ie]s|authors?|journals?|venues?|researchers?|experts?|scholars?|compare|emerging|underexplored|understudied|unexplored|opportunit\w*|growth|timeline|evolution|compar\w*)$/.test(w));
 return{f,intent,terms:terms(s),cmp:cmp&&cmp.map(x=>terms(x)),raw:q0}}
function aiRetrieve(terms,f,cap=60){const T=[...new Set(terms)],syn=lsGet('x4Syn',{});let X2=[];const phr=stem(T.join(' '));if(syn[phr]){X2=syn[phr].alts.concat(syn[phr].rel||[]).flatMap(a=>tokens(a)).filter(w=>!STOP.has(w)&&w.length>2)}
 const mk=t=>{const r=root1(t);return t.length<=3?(x=>new RegExp('\\b'+t+'\\b').test(x)):(x=>x.includes(r))},M1=T.map(t=>({t,f:mk(t)})),M2=[...new Set(X2)].filter(w=>!T.includes(w)).map(t=>({t,f:mk(t)})),phrase=T.length>1?T.map(root1).join(' '):'';
 const ok=i=>{const r=R[i];if(f.from&&r[3]<f.from)return false;if(f.to&&r[3]>f.to)return false;if(f.minCites&&r[0]<f.minCites)return false;if(f.country&&norm(CO[r[7]]||'')!==norm(f.country))return false;return true};
 let sem=new Map();if(T.length){try{semSearch(T.join(' ')).out.forEach(([i,s])=>sem.set(i,s))}catch{}}
 const need=Math.max(1,Math.ceil(T.length*.6)),res=[];let cut=f.minCites||0;if(f.high&&!f.minCites){cut=tgCuts().p95;f=Object.assign({},f,{minCites:Math.max(1,cut)})}
 for(let i=0;i<R.length;i++){if(!ok(i)){continue}if(!T.length){res.push({i,score:Math.log1p(R[i][0]),why:[]});continue}
  const x=INDEX[i];let sc=0,hit=0;const why=[];for(const {t,f:fn} of M1){let w=0;if(fn(x.t))w+=6;if(fn(x.k))w+=5;if(fn(x.b))w+=1.5;if(fn(x.a))w+=3;if(fn(x.s))w+=1.5;if(w){hit++;sc+=w;why.push(t)}}
  for(const {t,f:fn} of M2){if(fn(x.t)||fn(x.k)){sc+=1.5;why.push(t+' (syn)')}}
  const sv=sem.get(i);if(sv){sc+=sv*1.6;if(!hit)hit=1}
  if(hit<need)continue;if(phrase){if(x.t.includes(phrase))sc+=8;if(x.k.includes(phrase))sc+=6;if(x.b.includes(phrase))sc+=3}
  if(hit===T.length)sc+=4;res.push({i,score:sc+.25*Math.log1p(R[i][0]),why})}
 if(f.sort==='newest')res.sort((a,b)=>R[b.i][3]-R[a.i][3]||b.score-a.score);else if(f.high)res.sort((a,b)=>R[b.i][0]-R[a.i][0]);else res.sort((a,b)=>b.score-a.score);
 return{total:res.length,top:res.slice(0,cap)}}
function aiStats(top){const c=(m,k)=>m.set(k,(m.get(k)||0)+1),kw=new Map(),au=new Map(),jo=new Map(),yr=new Map(),co=new Map();top.forEach(({i})=>{const r=R[i];splitKeywords(r[11]).forEach(k=>{const n=norm(k).trim();if(!n)return;const e=kw.get(n)||{n:0,l:k,v:new Map()};e.n++;e.v.set(k,(e.v.get(k)||0)+1);e.l=[...e.v].sort((a,b)=>b[1]-a[1])[0][0];kw.set(n,e)});splitAuthors(r[1]).forEach(a=>{const e=au.get(a)||{n:0,c:0};e.n++;e.c+=r[0];au.set(a,e)});const s=S[r[4]];if(s){const e=jo.get(s)||{n:0,c:0};e.n++;e.c+=r[0];jo.set(s,e)}c(yr,r[3]);const k=CO[r[7]];if(k)c(co,k)});
 const srt=m=>[...m].sort((a,b)=>(b[1].n||b[1])-(a[1].n||a[1]));return{kw:srt(kw).map(([k,e])=>[e.l,e.n]),au:srt(au),jo:srt(jo),yr:[...yr].sort((a,b)=>a[0]-b[0]),co:srt(co)}}
function aiSnippet(i,terms){const a=riSentenceSplit(R[i][12]);if(!a.length)return'';const rs=terms.map(root1);let best=a[0],bs=-1;for(const s of a){const l=norm(s);const n=rs.filter(r=>l.includes(r)).length;if(n>bs){bs=n;best=s}}let h=esc(best.length>300?best.slice(0,297)+'…':best);rs.filter(r=>r.length>2).forEach(r=>{h=h.replace(new RegExp('('+r.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'[a-z]*)','gi'),'<mark>$1</mark>')});return h}
const aiResCard=(r,k,terms)=>{const i=r.i,o=recObj(i),d=doiOf(o.doi),u=safeUrl(o.url)||(d?'https://doi.org/'+d:'');return `<div class="aires"><div><span class="tiny">#${k+1}</span> <a href="#" data-aip="${i}"><b>${esc(o.title)}</b></a></div><div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)} · ${o.cites} cites${u?` · <a href="${esc(u)}" target="_blank" rel="noopener">${d?'DOI':'link'} ↗</a>`:''}</div>${aiSnippet(i,terms)?`<div style="margin-top:3px;font-size:12.5px">${aiSnippet(i,terms)}</div>`:''}${r.why&&r.why.length?`<div>${[...new Set(r.why)].slice(0,6).map(w=>`<span class="chip">${esc(w)}</span>`).join('')}</div>`:''}</div>`};
function aiHist(yr){if(!yr.length)return'';const mx=Math.max(...yr.map(x=>x[1]));return `<table>${yr.map(([y,n])=>`<tr><td style="width:48px">${y}</td><td><span class="aibar" style="width:${Math.max(3,n/mx*70)}%"></span> ${n}</td></tr>`).join('')}</table>`}
function aiFilterChips(f){const a=[];if(f.from&&f.to&&f.from===f.to)a.push('year '+f.from);else{if(f.from)a.push('from '+f.from);if(f.to)a.push('until '+f.to)}if(f.minCites)a.push('≥ '+f.minCites+' citations');if(f.high)a.push('highly cited');if(f.country)a.push('publisher country: '+f.country);if(f.sort==='newest')a.push('newest first');return a.map(x=>`<span class="badge4">${esc(x)}</span>`).join('')}
function aiTrendHtml(top,st){const my=(M&&M.maxYear)||2025,rec=new Map(),old=new Map();top.forEach(({i})=>{const y=R[i][3];splitKeywords(R[i][11]).forEach(k=>{const mp=y>=my-2?rec:old;mp.set(k,(mp.get(k)||0)+1)})});const em=[...rec].filter(([k,n])=>n>=2).map(([k,n])=>[k,n,(old.get(k)||0)]).sort((a,b)=>(b[1]-b[2])-(a[1]-a[2])).slice(0,8);return `<b>Publications per year (matching records)</b>${aiHist(st.yr)}${em.length?`<p><b>Rising themes (last 3 years vs earlier):</b> ${em.map(([k,n,o])=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)} <small>${n} vs ${o}</small></span>`).join('')}</p>`:''}`}
async function aiAnswer(q){const P=aiParse(q);let terms=P.terms,f=P.f;if(!terms.length&&AI.ctx&&!P.cmp){terms=AI.ctx.terms}else if(terms.length&&!P.cmp)AI.ctx={terms,f};if(AI.ctx&&!P.terms.length){f=Object.assign({},AI.ctx.f||{},P.f)}
 const phrase=terms.join(' ');let html='',cards=[],top=[],total=0,follow=[];
 if(P.cmp&&P.cmp[0].length&&P.cmp[1].length){const A=aiRetrieve(P.cmp[0],f,100),B=aiRetrieve(P.cmp[1],f,100),sa=aiStats(A.top),sb=aiStats(B.top),avg=t=>t.length?Math.round(t.reduce((s,x)=>s+R[x.i][0],0)/t.length*10)/10:0,la=P.cmp[0].join(' '),lb=P.cmp[1].join(' ');
  const ka=new Set(sa.kw.slice(0,15).map(x=>x[0])),shared=sb.kw.slice(0,15).map(x=>x[0]).filter(k=>ka.has(k));
  html=`<p><b>Comparison:</b> “${esc(la)}” vs “${esc(lb)}” ${aiFilterChips(f)}</p><table><tr><th></th><th>${esc(la)}</th><th>${esc(lb)}</th></tr><tr><td>Matching records</td><td>${A.total.toLocaleString()}</td><td>${B.total.toLocaleString()}</td></tr><tr><td>Avg. citations (top ${A.top.length}/${B.top.length})</td><td>${avg(A.top)}</td><td>${avg(B.top)}</td></tr><tr><td>Peak year</td><td>${[...sa.yr].sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</td><td>${[...sb.yr].sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</td></tr><tr><td>Top themes</td><td>${sa.kw.slice(0,5).map(x=>esc(x[0])).join('; ')}</td><td>${sb.kw.slice(0,5).map(x=>esc(x[0])).join('; ')}</td></tr><tr><td>Leading venue</td><td>${esc(sa.jo[0]?.[0]||'—')}</td><td>${esc(sb.jo[0]?.[0]||'—')}</td></tr></table>${shared.length?`<p><b>Shared themes:</b> ${shared.slice(0,8).map(k=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)}</span>`).join('')}</p>`:''}<b>Top papers — ${esc(la)}</b>${A.top.slice(0,3).map((r,k)=>aiResCard(r,k,P.cmp[0])).join('')}<b>Top papers — ${esc(lb)}</b>${B.top.slice(0,3).map((r,k)=>aiResCard(r,k,P.cmp[1])).join('')}`;top=A.top.slice(0,5).concat(B.top.slice(0,5));total=A.total+B.total;follow=['Research gaps in '+la,'Trends in '+lb]}
 else{const rr=aiRetrieve(terms,f,80);top=rr.top;total=rr.total;terms=terms.length?terms:[];const st=aiStats(top);
  if(!total){html=`<p>No records matched${phrase?` “${esc(phrase)}”`:''} ${aiFilterChips(f)}. Try fewer or broader terms, or remove filters.</p>`;follow=['Show all highly cited papers','Trends in '+(AI.ctx?.terms||[]).join(' ')]}
  else{const head=`<p>Found <b>${total.toLocaleString()}</b> matching record${total===1?'':'s'}${phrase?` for “${esc(phrase)}”`:''} ${aiFilterChips(f)}</p>`;
   if(P.intent==='gaps'){const g=riGapAnalysis(top.slice(0,40)).gaps.concat(riMoreGaps(top.slice(0,40))).slice(0,6);html=head+`<b>Research gaps detected in the top ${Math.min(40,top.length)} records</b>`+(g.map((x,k)=>`<div class="aires"><span class="badge4 ${x.confidence==='high'?'warn':''}">${esc(x.type)}</span> ${esc(x.statement)}<div class="tiny"><b>Research question:</b> ${esc(gapRQ(x))}</div></div>`).join('')||'<p class="tiny">No defensible gap signals in this scope.</p>')+`<p><button class="ghost" data-aiact="gapfinder">Open full Research Gap Finder for this topic ⌁</button></p>`;follow=['Hypotheses for '+phrase,'Trends in '+phrase]}
   else if(P.intent==='hyp'){const h=riHypotheses(top.slice(0,40)).hyps;html=head+`<b>Alternative hypotheses</b>`+(h.map((x,k)=>`<div class="aires"><b>H${k+1}:</b> ${esc(x.statement)}<div class="tiny"><b>Null:</b> ${esc(x.null)} · ${x.support} supporting record(s)</div></div>`).join('')||'<p class="tiny">Not enough repeated keyword relationships.</p>')+`<p class="tiny">Hypotheses are generated from keyword co-occurrence; they are not findings.</p>`;follow=['Research gaps in '+phrase]}
   else if(P.intent==='trends'){html=head+aiTrendHtml(top,st);follow=['Research gaps in '+phrase,'Top authors in '+phrase]}
   else if(P.intent==='authors'){html=head+`<b>Leading authors in the top ${top.length} matches</b><table><tr><th>Author</th><th>Papers</th><th>Citations</th></tr>${st.au.slice(0,12).map(([a,e])=>`<tr><td>${esc(a)}</td><td>${e.n}</td><td>${e.c}</td></tr>`).join('')}</table>`;follow=['Top journals for '+phrase]}
   else if(P.intent==='journals'){html=head+`<b>Leading venues in the top ${top.length} matches</b><table><tr><th>Journal</th><th>Papers</th><th>Citations</th></tr>${st.jo.slice(0,12).map(([a,e])=>`<tr><td>${esc(a)}</td><td>${e.n}</td><td>${e.c}</td></tr>`).join('')}</table>`;follow=['Top authors in '+phrase]}
   else{const py=[...st.yr].sort((a,b)=>b[1]-a[1])[0];html=head+`<div class="aires" style="background:#f7faff"><b>Overview</b><br>Key themes: ${st.kw.slice(0,8).map(([k,n])=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)} <small>${n}</small></span>`).join('')||'—'}<br>Most active year: <b>${py?py[0]:'—'}</b> · Leading venue: <b>${esc(st.jo[0]?.[0]||'—')}</b> · Leading author: <b>${esc(st.au[0]?.[0]||'—')}</b>${st.co[0]?` · Publisher country: <b>${esc(st.co[0][0])}</b>`:''}</div>`+top.slice(0,8).map((r,k)=>aiResCard(r,k,terms)).join('');follow=['Research gaps in '+phrase,'Trends in '+phrase,'Top authors in '+phrase,'Only since '+(((M&&M.maxYear)||2025)-4)]}}}
 let llm='';if(AI.cfg.mode!=='local'&&AI.cfg.key&&top.length){try{llm=await aiLLM(q,top.slice(0,12))}catch(e){llm=`<div class="note bad">LLM call failed (${esc(e.message||e)}). Showing local semantic answer instead.</div>`}}
 return{html:llm+html,top,follow,total,terms,f}}
async function aiLLM(q,top){const ctx=top.map((r,k)=>{const o=recObj(r.i);return `[${k+1}] ${o.title} — ${o.authors} (${o.year}), ${o.source}, ${o.cites} citations${o.doi?`, DOI ${doiOf(o.doi)}`:''}. Keywords: ${o.keywords||'n/a'}. Abstract: ${(o.abstract||'n/a').slice(0,700)}`}).join('\n\n'),sys='You are a research assistant inside a bibliographic explorer. Answer ONLY from the numbered records provided. Cite records inline as [n]. If the records do not support an answer, say so. Be concise and structured; do not invent references.',user=`Question: ${q}\n\nRecords:\n${ctx}`;let txt;
 if(AI.cfg.mode==='anthropic'){const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':AI.cfg.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:AI.cfg.model||'claude-sonnet-5-5',max_tokens:1200,system:sys,messages:[{role:'user',content:user}]})});if(!r.ok)throw new Error(r.status+' '+(await r.text()).slice(0,120));const j=await r.json();txt=(j.content||[]).map(c=>c.text||'').join('')}
 else{const r=await fetch((AI.cfg.endpoint||'https://api.openai.com/v1').replace(/\/$/,'')+'/chat/completions',{method:'POST',headers:{'content-type':'application/json',Authorization:'Bearer '+AI.cfg.key},body:JSON.stringify({model:AI.cfg.model,messages:[{role:'system',content:sys},{role:'user',content:user}],max_tokens:1200})});if(!r.ok)throw new Error(r.status+' '+(await r.text()).slice(0,120));const j=await r.json();txt=j.choices?.[0]?.message?.content||''}
 let h=esc(txt).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>').replace(/\[(\d{1,2})\]/g,(m,n)=>top[n-1]?`<a href="#" data-aip="${top[n-1].i}">[${n}]</a>`:m);return `<div class="aires" style="background:#f6f1fd;border-color:#c9b3ec"><span class="badge4">✦ ${AI.cfg.mode==='anthropic'?'Claude':'LLM'} answer · grounded in the top ${top.length} records</span><div style="margin-top:6px">${h}</div></div>`}
function aiOpen(prefill,autorun){
 const EX=['What research gaps exist in information literacy?','Highly cited papers on artificial intelligence since 2020','Trends in open access publishing','Who are the leading authors in digital libraries?','Compare bibliometrics vs altmetrics'];
 H('✦ AI Search <span class="badge4" id="aimode"></span>',`<div class="aiwrap"><div class="ailog" id="ailog"></div><div id="aiset" style="display:none" class="card"></div><div class="aiin"><textarea id="aiq" rows="2" placeholder="Ask in natural language — e.g. “highly cited papers on machine learning in libraries since 2019”"></textarea><div style="display:grid;gap:6px"><button class="primary" id="aigo">Ask ✦</button><button class="ghost" id="aicfg" title="AI provider settings">⚙ Settings</button></div></div><div class="tiny" style="margin-top:4px">Understands years, citation thresholds, countries, “gaps”, “trends”, “hypotheses”, “top authors / journals”, “compare X vs Y” and follow-ups.</div></div>`);
 const log=Q('#ailog'),paint=()=>{Q('#aimode').textContent=AI.cfg.mode==='local'||!AI.cfg.key?'local semantic engine · works offline':(AI.cfg.mode==='anthropic'?'Claude · grounded answers':'LLM · grounded answers');Q('#aimode').className='badge4 '+(AI.cfg.mode==='local'||!AI.cfg.key?'ok':'');
  log.innerHTML=(AI.msgs.length?AI.msgs.map(m=>m.u?`<div class="aimsg u"><div class="aibub">${esc(m.u)}</div></div>`:`<div class="aimsg"><div class="aibub">${m.html}${m.top&&m.top.length?`<div class="row"><button class="ghost" data-aiact="apply" data-phrase="${esc((m.terms||[]).join(' '))}">Apply to main search</button><button class="ghost" data-aiact="csv" data-i="${AI.msgs.indexOf(m)}">⇩ CSV</button></div>`:''}${(m.follow||[]).length?`<div>${m.follow.map(x=>`<span class="chip" data-aiq="${esc(x)}">${esc(x)}</span>`).join('')}</div>`:''}</div></div>`).join(''):`<div class="aimsg"><div class="aibub"><b>Ask anything about the ${R.length.toLocaleString()} records in this library.</b><div>${EX.map(x=>`<span class="chip" data-aiq="${esc(x)}">${esc(x)}</span>`).join('')}</div></div></div>`);log.scrollTop=log.scrollHeight};
 const ask=async q=>{q=(q||'').trim();if(!q||AI.busy)return;AI.busy=true;AI.msgs.push({u:q});Q('#aiq').value='';paint();log.insertAdjacentHTML('beforeend','<div class="aimsg"><div class="aibub tiny" id="aithink">Searching and reasoning over the library…</div></div>');log.scrollTop=log.scrollHeight;await new Promise(r=>setTimeout(r,15));
  try{const a=await aiAnswer(q);AI.msgs.push({html:a.html,top:a.top,follow:a.follow,terms:a.terms,f:a.f})}catch(e){AI.msgs.push({html:`<span class="bad">Something went wrong: ${esc(e.message||e)}</span>`})}AI.busy=false;paint()};
 Q('#aigo').onclick=()=>ask(Q('#aiq').value);Q('#aiq').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask(e.target.value)}};
 Q('#aicfg').onclick=()=>{const p=Q('#aiset');if(p.style.display==='block'){p.style.display='none';return}p.style.display='block';const c=AI.cfg;p.innerHTML=`<b>AI provider</b> <span class="tiny">— optional. Local mode needs no key and works offline. With a key, the top matching records are sent to the provider so the model can write a grounded answer. The key is stored only in this browser.</span><div class="row"><label>Mode <select id="aim"><option value="local">Local semantic engine (offline)</option><option value="anthropic">Anthropic (Claude)</option><option value="openai">OpenAI-compatible</option></select></label><label>Model <input type="text" id="aimod" size="22" value="${esc(c.model||'')}"></label></div><div class="row"><label>Endpoint <input type="text" id="aiep" size="36" value="${esc(c.endpoint||'')}"></label><label>API key <input type="password" id="aik" size="30" value="${esc(c.key||'')}" autocomplete="off"></label><button class="primary" id="aisave">Save</button></div>`;Q('#aim').value=c.mode;Q('#aisave').onclick=()=>{AI.cfg={mode:Q('#aim').value,model:Q('#aimod').value.trim(),endpoint:Q('#aiep').value.trim(),key:Q('#aik').value.trim()};lsPut('x4AI',AI.cfg);p.style.display='none';paint();toast('AI settings saved')}};
 log.onclick=e=>{const t=e.target,c=t.closest('[data-aiq]'),pp=t.closest('[data-aip]'),a=t.closest('[data-aiact]');if(c)ask(c.dataset.aiq);if(pp){e.preventDefault();x4Detail(+pp.dataset.aip,()=>aiOpen(),'Back to AI Search')}
  if(a){const act=a.dataset.aiact;if(act==='apply'){const ph=a.dataset.phrase;if(ph){$('#q').value=ph;closeModal();$('#searchForm').requestSubmit()}}
   else if(act==='gapfinder'){const last=[...AI.msgs].reverse().find(m=>m.terms);if(last&&last.terms.length){$('#q').value=last.terms.join(' ');closeModal();$('#searchForm').requestSubmit();setTimeout(()=>riGapModal(),250)}}
   else if(act==='csv'){const m=AI.msgs[+a.dataset.i];download('ai-search-results.csv','title,authors,year,source,cites,doi\n'+m.top.map(r=>{const o=recObj(r.i);return [o.title,o.authors,o.year,o.source,o.cites,doiOf(o.doi)].map(CSVq).join(',')}).join('\n'),'text/csv')}}};
 paint();setTimeout(()=>Q('#aiq')&&Q('#aiq').focus(),50);if(prefill){Q('#aiq').value=prefill;if(autorun)ask(prefill)}}

/* ---------- Open Data URI tab (works offline: resolvable URIs; online: live resolve + save) ---------- */
const E=encodeURIComponent,dpath=d=>d.split('/').map(E).join('/'),under=s=>String(s).trim().replace(/\s+/g,'_'),tcase=s=>String(s).trim().split(/\s+/).map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join('_');
function uriSet(type,label,o){const L=[],add=(n,u,k)=>L.push({n,u,k:k||'page'}),q=E(label);
 if(type==='paper'){const d=doiOf(o.doi);if(d){add('DOI',`https://doi.org/${dpath(d)}`);add('OpenAlex',`https://api.openalex.org/works/doi:${dpath(d)}`,'data');add('Crossref',`https://api.crossref.org/works/${dpath(d)}`,'data');add('OpenCitations',`https://opencitations.net/index/coci/api/v1/metadata/${dpath(d)}`,'data');add('Semantic Scholar',`https://api.semanticscholar.org/graph/v1/paper/DOI:${dpath(d)}?fields=title,year,citationCount,openAccessPdf,externalIds`,'data');add('DataCite',`https://api.datacite.org/dois/${dpath(d)}`,'data');add('Altmetric',`https://api.altmetric.com/v1/doi/${dpath(d)}`,'data');add('Europe PMC',`https://europepmc.org/search?query=DOI:%22${E(d)}%22`)}
  else{add('OpenAlex search',`https://api.openalex.org/works?search=${q}`,'data');add('Crossref search',`https://search.crossref.org/?q=${q}`);add('Semantic Scholar',`https://www.semanticscholar.org/search?q=${q}`);add('Google Scholar',`https://scholar.google.com/scholar?q=${q}`)}
  const u=safeUrl(o.url);if(u)add('Article page',u)}
 else if(type==='author'){add('ORCID search',`https://orcid.org/orcid-search/search?searchQuery=${q}`);add('OpenAlex',`https://api.openalex.org/authors?search=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBLP',`https://dblp.org/search?q=${q}`);add('VIAF',`https://viaf.org/viaf/search?query=local.names%20all%20%22${q}%22`);add('Google Scholar',`https://scholar.google.com/scholar?q=author%3A%22${q}%22`)}
 else if(type==='journal'){const is=o&&o.issn&&(String(o.issn).match(/\d{4}-?\d{3}[\dXx]/)||[])[0];if(is){const i2=is.replace(/^(\d{4})-?(\d)/,'$1-$2').toUpperCase();add('ISSN Portal',`https://portal.issn.org/resource/ISSN/${i2}`);add('Crossref journal',`https://api.crossref.org/journals/${i2}`,'data');add('OpenAlex source',`https://api.openalex.org/sources/issn:${i2}`,'data');add('DOAJ',`https://doaj.org/toc/${i2}`)}add('OpenAlex search',`https://api.openalex.org/sources?search=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('Scimago',`https://www.scimagojr.com/journalsearch.php?q=${q}`)}
 else if(type==='publisher'){add('ROR',`https://ror.org/search?query=${q}`);add('OpenAlex',`https://api.openalex.org/publishers?search=${q}`,'data');add('Crossref members',`https://api.crossref.org/members?query=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`)}
 else if(type==='country'){add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBpedia',`http://dbpedia.org/resource/${E(under(label))}`,'data');add('Wikipedia',`https://en.wikipedia.org/wiki/${E(under(label))}`);add('REST Countries',`https://restcountries.com/v3.1/name/${q}`,'data');add('GeoNames',`https://www.geonames.org/search.html?q=${q}`)}
 else{add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBpedia',`http://dbpedia.org/resource/${E(tcase(label))}`,'data');add('Wikipedia',`https://en.wikipedia.org/w/index.php?search=${q}`);add('LC Subjects',`https://id.loc.gov/search/?q=${q}`);add('OpenAlex topics',`https://api.openalex.org/topics?search=${q}`,'data')}
 return L}
function mintUri(type,label,o){if(type==='paper'){const d=doiOf(o.doi);return d?'https://doi.org/'+dpath(d):BASE+'paper/'+o.index}return type==='keyword'?cid(label):BASE+type+'/'+slug(label)}
function uriLookup(raw){raw=String(raw||'').trim();if(!raw)return null;const r=[];let m;
 if(m=raw.match(/10\.\d{4,9}\/[^\s"<>]+/)){const d=m[0].replace(/[.,;)]+$/,'');return{kind:'DOI',id:d,uri:'https://doi.org/'+dpath(d),links:uriSet('paper','',{doi:d}),curl:`curl -sLH "Accept: application/vnd.citationstyles.csl+json" https://doi.org/${dpath(d)}`}}
 if(m=raw.match(/\b\d{4}-\d{4}-\d{4}-\d{3}[\dXx]\b/)){const o=m[0].toUpperCase();return{kind:'ORCID iD',id:o,uri:'https://orcid.org/'+o,links:[{n:'ORCID record',u:'https://orcid.org/'+o,k:'page'},{n:'ORCID public API',u:'https://pub.orcid.org/v3.0/'+o+'/record',k:'data'},{n:'OpenAlex',u:'https://api.openalex.org/authors/orcid:'+o,k:'data'}],curl:`curl -sH "Accept: application/json" https://pub.orcid.org/v3.0/${o}/record`}}
 if(m=raw.match(/\b\d{4}-\d{3}[\dXx]\b/)){const o=m[0].toUpperCase();return{kind:'ISSN',id:o,uri:'https://portal.issn.org/resource/ISSN/'+o,links:uriSet('journal','',{issn:o}),curl:`curl -s https://api.crossref.org/journals/${o}`}}
 if(m=raw.match(/\bQ\d+\b/)){const o=m[0];return{kind:'Wikidata item',id:o,uri:'http://www.wikidata.org/entity/'+o,links:[{n:'Wikidata page',u:'https://www.wikidata.org/wiki/'+o,k:'page'},{n:'JSON',u:'https://www.wikidata.org/wiki/Special:EntityData/'+o+'.json',k:'data'},{n:'Turtle (RDF)',u:'https://www.wikidata.org/wiki/Special:EntityData/'+o+'.ttl',k:'data'}],curl:`curl -sLH "Accept: text/turtle" http://www.wikidata.org/entity/${o}`}}
 if(m=raw.match(/\b(?:https?:\/\/openalex\.org\/)?([WAISCPF]\d{5,})\b/)){const o=m[1],k={W:'works',A:'authors',I:'institutions',S:'sources',C:'concepts',P:'publishers',F:'funders'}[o[0]];return{kind:'OpenAlex ID ('+k+')',id:o,uri:'https://openalex.org/'+o,links:[{n:'OpenAlex page',u:'https://openalex.org/'+o,k:'page'},{n:'JSON',u:`https://api.openalex.org/${k}/${o}`,k:'data'}],curl:`curl -s https://api.openalex.org/${k}/${o}`}}
 if(m=raw.match(/\b0[a-hj-km-np-tv-z0-9]{6}[0-9]{2}\b/)){const o=m[0];return{kind:'ROR ID',id:o,uri:'https://ror.org/'+o,links:[{n:'ROR page',u:'https://ror.org/'+o,k:'page'},{n:'ROR API',u:'https://api.ror.org/v2/organizations/'+o,k:'data'}],curl:`curl -s https://api.ror.org/v2/organizations/${o}`}}
 const u=safeUrl(raw);if(u)return{kind:'URI',id:u,uri:u,links:[{n:'Open URI',u,k:'page'}],curl:`curl -sIL "${u}"`};return{kind:'Unrecognised',id:raw,uri:'',links:[{n:'Wikidata search',u:'https://www.wikidata.org/w/index.php?search='+E(raw),k:'page'},{n:'OpenAlex search',u:'https://api.openalex.org/works?search='+E(raw),k:'data'}],curl:''}}
const linkChips=L=>L.map(x=>`<a class="chip" style="text-decoration:none" href="${esc(x.u)}" target="_blank" rel="noopener noreferrer" title="${esc(x.u)}">${esc(x.n)}${x.k==='data'?' <small>data</small>':''} ↗</a>`).join('');
const URIT=['paper','author','journal','publisher','country','keyword'],URIL={paper:'Papers',author:'Authors',journal:'Journals',publisher:'Publishers',country:'Countries',keyword:'Keywords'};
async function pingSvc(name,url){const c=new AbortController(),t=setTimeout(()=>c.abort(),9000);try{const r=await fetch(url,{signal:c.signal});clearTimeout(t);return r.ok?`<span class="chain-ok">✓</span> ${name}`:`<span class="chain-bad">✗</span> ${name} (HTTP ${r.status})`}catch(e){clearTimeout(t);return `<span class="chain-bad">✗</span> ${name} (${e.name==='AbortError'?'timeout':'blocked / offline / CORS'})`}}
let LODR=[];
function lodResolve(k){
  const row=LODR[k];if(!row)return;
  const key=norm(row.label);
  const ids=[];
  for(let i=0;i<R.length;i++){const r=R[i];let ok=false;
    if(row.type==='paper')ok=norm(r[2])===key;
    else if(row.type==='author')ok=splitAuthors(r[1]).some(a=>norm(a)===key);
    else if(row.type==='journal')ok=norm(S[r[4]]||'')===key;
    else if(row.type==='publisher')ok=norm(PUB[r[5]]||'')===key;
    else if(row.type==='country')ok=norm(CO[r[7]]||'')===key;
    else if(row.type==='keyword')ok=splitKeywords(r[11]).some(x=>norm(x)===key);
    if(ok)ids.push(i)}
  const cls={paper:'schema:ScholarlyArticle',author:'foaf:Person',journal:'schema:Periodical',publisher:'foaf:Organization',country:'schema:Country',keyword:'skos:Concept'}[row.type]||'owl:Thing';
  const turtle='<'+row.mint+'> a '+cls+' ;\n    rdfs:label '+lit(row.label)+' .';
  showModal(`<h2>Open Data URI: ${esc(row.label)}</h2>
    <p class="tiny">Type: <b>${esc(URIL[row.type]||row.type)}</b> · records in this library: <b>${ids.length.toLocaleString()}</b></p>
    <div class="card"><b>Minted URI</b><div class="mono">${esc(row.mint)}</div>
      <div class="row"><button class="ghost" id="lodResCopy" type="button">Copy URI</button></div>
      <p class="tiny">This URI is minted under your base URI (${esc(BASE)}). It identifies the entity inside this library. It resolves on the web only after you publish that base URI on a server.</p></div>
    <div class="card"><b>Description (Turtle)</b><textarea readonly rows="4" class="mono" style="width:100%">${esc(turtle)}</textarea></div>
    <div class="card"><b>Records</b>${ids.slice(0,10).map(i=>`<div><button class="ghost" type="button" data-lodp="${i}">${esc(R[i][2]||'Untitled')} (${esc(R[i][3]||'n/a')})</button></div>`).join('')||'<p class="tiny">No records.</p>'}${ids.length>10?`<p class="tiny">First 10 of ${ids.length.toLocaleString()} shown.</p>`:''}</div>
    <div class="card"><b>Open data links</b><div>${linkChips(row.links)}</div></div>`);
  $('#lodResCopy').onclick=()=>copyText(row.mint);
  $$('[data-lodp]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.lodp)));
}
function lodUri(el){
 el.innerHTML=`<div class="note"><b>Open Data URIs.</b> Every paper, author, journal, publisher, country and keyword gets <b>working, clickable open-data URIs</b> (DOI, ORCID, ISSN, OpenAlex, Crossref, Wikidata, DBpedia, ROR, GeoNames, LC Subjects …) generated from the data in your library — no internet call is needed to build them. Click a link to open it in a new tab, or use <b>Copy</b>. <b>Resolve online</b> confirms an entity against live services and lets you save the matched URI as an <code>owl:sameAs</code> link used by Export RDF.</div>
 <div class="card"><b>Resolve any identifier</b> <span class="tiny">— paste a DOI, ORCID, ISSN, Wikidata Q-id, OpenAlex ID, ROR ID or URL</span><div class="row"><input type="text" id="x4ul" size="48" placeholder="e.g. 10.1000/182 · 0000-0002-1825-0097 · 1932-6203 · Q42"><button class="primary" id="x4ulg">Get URIs</button></div><div id="x4ulr"></div></div>
 <div class="row"><label>Entity type <select id="x4ut">${URIT.map(t=>`<option value="${t}">${URIL[t]}</option>`).join('')}</select></label>${SC}<input type="text" id="x4uf" placeholder="filter…" size="16"><button class="ghost" id="x4ucopy">Copy all minted URIs</button><button class="ghost" id="x4ujson">⇩ URI table (CSV)</button><button class="ghost" id="x4utest">Test connection</button></div>
 <div class="row"><label>Base URI for minted identifiers <input type="text" id="x4ubase" size="38" value="${esc(BASE)}"></label><span class="tiny">Persistent URIs for your own entities are minted under this base (publish it on a web server for them to resolve).</span></div><div id="x4utr" class="tiny"></div><div id="x4ub" style="overflow:auto"></div>`;
 let rowsCache=[];
 const build=()=>{const type=Q('#x4ut').value,flt=norm(Q('#x4uf').value),m=new Map();
  hits().forEach(i=>{const o=recObj(i);if(type==='paper'){m.set('p'+i,{l:o.title,n:o.cites,o});return}({keyword:splitKeywords(o.keywords),author:splitAuthors(o.authors),journal:[o.source],publisher:[o.publisher],country:[o.country]})[type].forEach(l=>{l=(l||'').trim();if(!l)return;const k=norm(l),e=m.get(k)||{l,n:0,o:type==='journal'?{issn:o.issn}:{}};e.n++;if(type==='journal'&&!e.o.issn&&o.issn)e.o.issn=o.issn;m.set(k,e)})});
  let a=[...m.values()].filter(e=>!flt||norm(e.l).includes(flt));a.sort((x,y)=>y.n-x.n);a=a.slice(0,type==='paper'?40:30);const L=lk();
  rowsCache=a.map(e=>({type,label:e.l,mint:mintUri(type,e.l,e.o),links:uriSet(type,e.l,e.o)}));LODR=rowsCache;
  Q('#x4ub').innerHTML=`<table><tr><th>${URIL[type].replace(/s$/,'')}</th><th>${type==='paper'?'Cites':'Papers'}</th><th>Persistent URI (minted)</th><th>Open data links</th><th></th></tr>${a.map((e,k)=>{const sv=L[(type==='paper'?'paper|'+norm(e.l):type+'|'+norm(e.l))];return `<tr data-k="${k}"><td style="max-width:240px">${esc(e.l)}</td><td>${e.n}</td><td class="mono" style="max-width:230px">${type==="paper"?`<a href="${esc(rowsCache[k].mint)}" target="_blank" rel="noopener">${esc(rowsCache[k].mint)}</a>`:`<button class="ghost" type="button" data-res="${k}" title="Describe this URI inside the app">${esc(rowsCache[k].mint)}</button>`} <button class="ghost" data-cp="${k}">Copy</button>${sv?`<div class="tiny chain-ok">sameAs → <a href="${esc(safeUrl(sv.uri))}" target="_blank" rel="noopener">${esc(sv.src)}: ${esc(sv.label)}</a></div>`:''}</td><td>${linkChips(rowsCache[k].links)}</td><td><button class="ghost" data-rs="${k}">Resolve online</button></td></tr><tr><td colspan="5" id="x4rr${k}" class="tiny"></td></tr>`}).join('')}</table>`};
 Q('#x4ut').onchange=build;Q('#x3n').onchange=build;Q('#x4uf').oninput=build;build();
 Q('#x4ubase').onchange=e=>{BASE=e.target.value.trim().replace(/\/?$/,'/')||BASE;try{localStorage.setItem('x3Base',BASE)}catch{}build()};
 Q('#x4ulg').onclick=()=>{const r=uriLookup(Q('#x4ul').value);Q('#x4ulr').innerHTML=r?`<div class="row"><span class="badge4">${esc(r.kind)}</span>${r.uri?`<span class="mono">${esc(r.uri)}</span><button class="ghost" id="x4ulc">Copy</button>`:''}</div><div>${linkChips(r.links)}</div>${r.curl?`<div class="tiny" style="margin-top:4px">Content negotiation: <span class="mono">${esc(r.curl)}</span></div>`:''}`:''};
 Q('#x4ul').onkeydown=e=>{if(e.key==='Enter')Q('#x4ulg').click()};
 Q('#x4ulr').onclick=e=>{if(e.target.id==='x4ulc')copyText(uriLookup(Q('#x4ul').value).uri)};
 Q('#x4ucopy').onclick=()=>copyText(rowsCache.map(r=>r.mint).join('\n'));
 Q('#x4ujson').onclick=()=>download('open-data-uris.csv','type,label,minted_uri,link_name,link_uri\n'+rowsCache.flatMap(r=>r.links.map(l=>[r.type,r.label,r.mint,l.n,l.u].map(CSVq).join(','))).join('\n'),'text/csv');
 Q('#x4utest').onclick=async()=>{Q('#x4utr').innerHTML='Testing connections…';const r=await Promise.all([pingSvc('OpenAlex','https://api.openalex.org/works?per-page=1'),pingSvc('Crossref','https://api.crossref.org/works?rows=0'),pingSvc('Wikidata','https://www.wikidata.org/w/api.php?action=wbsearchentities&search=test&language=en&format=json&origin=*&limit=1'),pingSvc('DBpedia Lookup','https://lookup.dbpedia.org/api/search?query=test&maxResults=1&format=json'),pingSvc('doi.org','https://doi.org/api/handles/10.1000/182')]);Q('#x4utr').innerHTML=r.join(' &nbsp; ')+'<br>'+(r.every(x=>x.includes('chain-ok'))?'All services reachable — Resolve online will work.':'Unreachable services only affect “Resolve online”; the direct links above still open normally (use Copy if your browser blocks pop-ups).')};
 el.onclick=async e=>{const t=e.target,cp=t.dataset.cp,rs=t.dataset.rs,sv=t.dataset.sv,rz=t.dataset.res;if(rz!==undefined){lodResolve(Number(rz));return}
  if(cp!==undefined){copyText(rowsCache[+cp].mint);return}
  if(rs!==undefined){const k=+rs,row=rowsCache[k],box=Q('#x4rr'+k);box.innerHTML='Resolving…';const tp=row.type;
   try{if(tp==='paper'){const rec=hits().map(i=>recObj(i)).find(o=>o.title===row.label),d=doiOf(rec&&rec.doi);if(!d)throw new Error('This record has no DOI — use the search links above');const w=await J(`https://api.openalex.org/works/doi:${dpath(d)}`);box.dataset.cand=JSON.stringify([{src:'OpenAlex',uri:w.id,label:w.display_name||row.label}]);
     box.innerHTML=`<div><b>Resolved:</b> <a href="${esc(safeUrl(w.id))}" target="_blank" rel="noopener">${esc(w.id)}</a> · ${w.cited_by_count??'?'} citations (OpenAlex) · ${w.open_access?.is_oa?'open access':'closed/unknown access'}${w.open_access?.oa_url?` · <a href="${esc(safeUrl(w.open_access.oa_url))}" target="_blank" rel="noopener">OA copy ↗</a>`:''}<br>${(w.authorships||[]).slice(0,6).map(a=>`${esc(a.author?.display_name||'')}${a.author?.orcid?` <a href="${esc(safeUrl(a.author.orcid))}" target="_blank" rel="noopener">ORCID ↗</a>`:''}`).join(' · ')}<br><button class="ghost" data-sv="${k}|0">Save as owl:sameAs</button></div>`}
    else{const r=await lodFind(tp,row.label);box.dataset.cand=JSON.stringify(r.items);box.innerHTML=r.items.map((c,j)=>`<div><button class="ghost" data-sv="${k}|${j}">Accept</button> <b>${esc(c.src)}</b> <a href="${esc(safeUrl(c.uri))}" target="_blank" rel="noopener">${esc(c.label)} ↗</a> <span class="tiny">${esc(c.desc)}</span></div>`).join('')||`<span class="bad">No candidates${r.err?' ('+r.err+' source(s) unreachable — click “Test connection”)':''}. Use the links in the row.</span>`}}
   catch(err){box.innerHTML=`<span class="bad">${esc(err.message||err)} — live lookup needs internet access and CORS-enabled services. The links in the row still work; click “Test connection” to diagnose.</span>`}return}
  if(sv!==undefined){const [k,j]=sv.split('|').map(Number),box=Q('#x4rr'+k),c=JSON.parse(box.dataset.cand||'[]')[j],row=rowsCache[k];if(!c)return;const L=lk();L[(row.type==='paper'?'paper|':row.type+'|')+norm(row.label)]=c;setLk(L);toast('Link saved');build()}};
}

/* ---------- navigation buttons ---------- */
const sp=Q('.toolbar .nav-spacer');
[['aiBtn','✦','AI Search',()=>aiOpen()],['mmBtn','✺','Mind Map',mmOpen],['semBtn','◈','Semantic Layer',()=>semOpen()],['lodBtn','🔗','Linked Open Data',()=>lodOpen()]].forEach(([id,ic,lb,fn])=>{if(Q('#'+id))return;const b=document.createElement('button');b.className='ghost';b.id=id;b.type='button';b.innerHTML=ic+' <span>'+lb+'</span>';b.onclick=fn;sp?sp.parentNode.insertBefore(b,sp):Q('.toolbar').appendChild(b)});
window.openAISearch=aiOpen;{const hb=document.getElementById('heroAiBtn');if(hb)hb.onclick=()=>{const v=($('#q').value||'').trim();aiOpen(v||undefined,!!v)}}window.openOpenDataURI=()=>lodOpen('uri');window.openSemanticBlockchain=()=>semOpen('bc');window.openMindMap=mmOpen;window.openSemanticLayer=semOpen;window.openLinkedOpenData=lodOpen;
})();
