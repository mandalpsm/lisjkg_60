
/* ===== View modes: Window View · Desktop View · Full Screen View (additive; no existing feature is changed) ===== */
(()=>{
'use strict';
const D=document,H=D.documentElement,Q=s=>D.querySelector(s),KEY='areView',WK='areWinW';
let base='desktop',cur='desktop',realFS=false;
try{const v=localStorage.getItem(KEY);if(v==='window'||v==='desktop')base=v}catch(e){}
const fsEl=()=>D.fullscreenElement||D.webkitFullscreenElement||null;
const reqFS=()=>{const f=H.requestFullscreen||H.webkitRequestFullscreen;if(!f)return Promise.reject(new Error('unsupported'));try{const r=f.call(H,{navigationUI:'hide'});return r&&r.then?r:Promise.resolve()}catch(e){return Promise.reject(e)}};
const exitFS=()=>{const f=D.exitFullscreen||D.webkitExitFullscreen;if(f&&fsEl()){try{const r=f.call(D);if(r&&r.catch)r.catch(()=>{})}catch(e){}}};
const note=m=>{try{if(typeof toast==='function')toast(m)}catch(e){}};
const ICON={
 window:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M3 9h18"/><circle cx="6.2" cy="6.8" r=".6"/><circle cx="8.6" cy="6.8" r=".6"/></svg>',
 desktop:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="4" width="19" height="12.5" rx="2"/><path d="M8.5 20h7M12 16.5V20"/></svg>',
 full:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'};
const LABEL={window:['Window','Window View — the app in a framed, centred window'],desktop:['Desktop','Desktop View — the standard wide layout'],full:['Full screen','Full Screen View — fill the whole screen (Esc to exit)']};

/* controls */
const sw=D.createElement('span');sw.className='view-switch';sw.setAttribute('role','group');sw.setAttribute('aria-label','Display view');
sw.innerHTML='<em>View</em>'+['window','desktop','full'].map(k=>`<button type="button" data-view="${k}" title="${LABEL[k][1]}" aria-label="${LABEL[k][1]}" aria-pressed="false">${ICON[k]}<span>${LABEL[k][0]}</span></button>`).join('');
const tool=Q('.sample-header .toolbar')||Q('.toolbar'),sp=tool&&tool.querySelector('.nav-spacer');
if(tool){if(sp)sp.after(sw);else{sw.style.marginLeft='auto';tool.appendChild(sw)}}
const tb=D.createElement('div');tb.id='viewTitlebar';
tb.innerHTML=`<span class="vt-dots" aria-hidden="false"><i class="r" aria-hidden="true"></i><i class="y" aria-hidden="true"></i><button type="button" data-view="desktop" title="Maximise to Desktop View" aria-label="Maximise to Desktop View"></button></span><span class="vt-title">Academic Research Explorer — Window View</span><span class="vt-sp"></span><label>Window width <span class="vt-w" role="group" aria-label="Window width"><button type="button" data-w="compact" title="Compact window">S</button><button type="button" data-w="standard" title="Standard window">M</button><button type="button" data-w="wide" title="Wide window">L</button></span></label><button type="button" class="vt-fs" data-view="full" title="${LABEL.full[1]}">⛶ Full screen</button>`;
const hd=Q('header.sample-header')||Q('header');if(hd)hd.parentNode.insertBefore(tb,hd);else D.body.insertBefore(tb,D.body.firstChild);
const ex=D.createElement('button');ex.id='viewExit';ex.type='button';ex.innerHTML='✕ Exit full screen <kbd>Esc</kbd>';ex.setAttribute('aria-label','Exit Full Screen View');D.body.appendChild(ex);

const refit=()=>{window.dispatchEvent(new Event('resize'));try{if(window.KG&&KG.canvas&&Q('#modal.open')&&typeof kgResize==='function'){kgResize();if(typeof kgFit==='function')kgFit()}}catch(e){}};
function paint(){H.setAttribute('data-view',cur);sw.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===cur)));
  const fb=sw.querySelector('[data-view=full]');if(fb){const t=cur==='full'?'Exit Full Screen View (Esc)':LABEL.full[1];fb.title=t;fb.setAttribute('aria-label',t)}setTimeout(refit,80)}
function apply(v){cur=v;paint()}
function setView(v){
  if(v==='window'||v==='desktop'){base=v;try{localStorage.setItem(KEY,v)}catch(e){}if(fsEl()){realFS=false;exitFS()}apply(v);return}
  if(v==='full'){
    if(cur==='full'){realFS=false;exitFS();apply(base);return}
    apply('full');
    reqFS().then(()=>{realFS=!!fsEl()}).catch(()=>{realFS=false;note('Browser full screen was blocked here — showing the full-screen layout instead (press F11 for the browser’s own full screen).')})}}
D.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button[data-view]');if(b&&b.dataset.view){setView(b.dataset.view);return}
  const w=e.target.closest&&e.target.closest('button[data-w]');if(w){H.setAttribute('data-win',w.dataset.w);try{localStorage.setItem(WK,w.dataset.w)}catch(er){}setTimeout(refit,80)}
  if(e.target.closest&&e.target.closest('#viewExit'))setView('full')});
const onFs=()=>{if(fsEl()){if(cur==='full')realFS=true;return}if(cur==='full'&&realFS){realFS=false;apply(base)}};
D.addEventListener('fullscreenchange',onFs);D.addEventListener('webkitfullscreenchange',onFs);
D.addEventListener('keydown',e=>{if(e.key==='Escape'&&cur==='full'&&!realFS&&!fsEl()&&!Q('#modal.open'))setView('full')});
window.setAppView=setView;window.getAppView=()=>cur;
apply(base);
})();
