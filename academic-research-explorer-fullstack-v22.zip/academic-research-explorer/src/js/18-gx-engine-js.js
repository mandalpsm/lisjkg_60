
/* ===== GX: optimized, responsive graph engine (auto fit/center, zoom, overlap removal, crossing reduction, readable labels) ===== */
(()=>{
'use strict';
const FONT='Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif';
const CSS=`
.gx{display:flex;flex-direction:column;width:100%;height:100%;min-height:320px;background:#fff;border:1px solid var(--line,#dfe4ec);border-radius:12px;overflow:hidden;position:relative}
.gx.gx-full{position:fixed;inset:0;z-index:3000;border-radius:0;height:100vh;width:100vw;min-height:0}
.gx-bar{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:6px 8px;background:#f7f9fc;border-bottom:1px solid var(--line,#dfe4ec);font-size:12px}
.gx-bar select,.gx-bar input{border:1px solid var(--line,#dfe4ec);border-radius:7px;padding:4px 6px;background:#fff;font:inherit;font-size:12px;max-width:120px}
.gx-bar button{border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:7px;padding:4px 9px;font-size:12px;cursor:pointer;color:var(--brand,#184e77);font-weight:600}
.gx-bar button:hover,.gx-bar button.on{background:#eaf0fb}
.gx-bar .gx-sp{flex:1}.gx-bar .gx-stat{color:#687386;font-size:11.5px}
.gx-st{position:relative;flex:1 1 auto;min-height:200px;background:linear-gradient(#fcfdff,#f5f8fc)}
.gx-st canvas{position:absolute;left:0;top:0;width:100%;height:100%;display:block;touch-action:none;cursor:grab}
.gx-st canvas.drag{cursor:grabbing}
.gx-leg{position:absolute;left:8px;top:8px;background:rgba(255,255,255,.92);border:1px solid var(--line,#dfe4ec);border-radius:8px;padding:5px 8px;font-size:11.5px;max-width:230px;pointer-events:none;line-height:1.7}
.gx-leg i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:-1px}
.gx-tip{position:absolute;pointer-events:none;background:#152033;color:#fff;border-radius:7px;padding:5px 8px;font-size:12px;max-width:300px;display:none;z-index:5;line-height:1.35}
.gx-msg{position:absolute;inset:0;display:none;align-items:center;justify-content:center;color:#687386;font-size:13px;text-align:center;padding:20px}
`;
let cssDone=false;
const rng=seed=>()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* ---------- geometry ---------- */
function segCross(a,b,c,d){
  const o=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
  const d1=o(a,b,c),d2=o(a,b,d),d3=o(c,d,a),d4=o(c,d,b);
  return d1*d2<0&&d3*d4<0;
}
function countCross(N,UE){
  let c=0;
  for(let i=0;i<UE.length;i++){const a=UE[i];
    for(let j=i+1;j<UE.length;j++){const b=UE[j];
      if(a[0]===b[0]||a[0]===b[1]||a[1]===b[0]||a[1]===b[1])continue;
      if(segCross(N[a[0]],N[a[1]],N[b[0]],N[b[1]]))c++}}
  return c;
}
function overlapCount(N,idx){
  let c=0;
  for(let a=0;a<idx.length;a++)for(let b=a+1;b<idx.length;b++){
    const p=N[idx[a]],q=N[idx[b]];
    if((p.fw+q.fw)/2-Math.abs(q.x-p.x)>0.5&&(p.fh+q.fh)/2-Math.abs(q.y-p.y)>0.5)c++}
  return c;
}

/* ---------- layout stages ---------- */
function components(N){
  const seen=new Uint8Array(N.length),out=[];
  for(let s=0;s<N.length;s++){if(seen[s])continue;const comp=[s];seen[s]=1;
    for(let h=0;h<comp.length;h++)for(const u of N[comp[h]].nb)if(!seen[u]){seen[u]=1;comp.push(u)}
    out.push(comp)}
  return out;
}
function radialInit(comp,N,gap){
  if(comp.length===1){N[comp[0]].x=0;N[comp[0]].y=0;return}
  const root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const lvl=new Map([[root,0]]),kids=new Map(),q=[root];
  for(let h=0;h<q.length;h++){const v=q[h];
    for(const u of N[v].nb)if(!lvl.has(u)){lvl.set(u,lvl.get(v)+1);(kids.get(v)||kids.set(v,[]).get(v)).push(u);q.push(u)}}
  const leaves=new Map();
  for(let h=q.length-1;h>=0;h--){const v=q[h],ks=kids.get(v)||[];leaves.set(v,ks.length?ks.reduce((s,k)=>s+leaves.get(k),0):1)}
  const ang=new Map([[root,[0,2*Math.PI]]]);
  q.forEach(v=>{const [a0,a1]=ang.get(v),ks=kids.get(v)||[];let a=a0;const tot=leaves.get(v);
    ks.forEach(k=>{const span=(a1-a0)*leaves.get(k)/tot;ang.set(k,[a,a+span]);a+=span})});
  const byL=new Map();q.forEach(v=>{const L=lvl.get(v);(byL.get(L)||byL.set(L,[]).get(L)).push(v)});
  const R=[0];const maxL=Math.max(...byL.keys());
  for(let L=1;L<=maxL;L++){const arr=byL.get(L)||[],circ=arr.reduce((s,v)=>s+Math.max(N[v].fw,N[v].fh)*1.05,0);R[L]=Math.max(R[L-1]+gap,circ/(2*Math.PI))}
  q.forEach(v=>{const [a0,a1]=ang.get(v),L=lvl.get(v),m=(a0+a1)/2;N[v].x=Math.cos(m)*R[L];N[v].y=Math.sin(m)*R[L]});
}
function forceStage(comp,N,UE,L,iters,rand){
  const n=comp.length;if(n<2)return;
  const pos=new Map(comp.map((v,i)=>[v,i])),X=new Float64Array(n),Y=new Float64Array(n),DX=new Float64Array(n),DY=new Float64Array(n);
  comp.forEach((v,i)=>{X[i]=N[v].x+(rand()-.5)*2;Y[i]=N[v].y+(rand()-.5)*2});
  const es=UE.filter(e=>pos.has(e[0])).map(e=>[pos.get(e[0]),pos.get(e[1]),e[2]]);
  const wmax=Math.max(1,...es.map(e=>e[2])),R=comp.map(v=>N[v].r);
  for(let it=0;it<iters;it++){
    const temp=L*1.2*(1-it/iters)+L*.05;
    DX.fill(0);DY.fill(0);
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
      let dx=X[i]-X[j],dy=Y[i]-Y[j],d2=dx*dx+dy*dy;if(d2<1e-4){dx=rand()-.5;dy=rand()-.5;d2=dx*dx+dy*dy+1e-4}
      const d=Math.sqrt(d2),f=(L*L*(1+(R[i]+R[j])/L))/d2;DX[i]+=dx*f;DY[i]+=dy*f;DX[j]-=dx*f;DY[j]-=dy*f}
    for(const [a,b,w] of es){const dx=X[a]-X[b],dy=Y[a]-Y[b],d=Math.sqrt(dx*dx+dy*dy)||1e-3,f=d/L*(.4+.6*Math.min(1,w/wmax));
      DX[a]-=dx*f;DY[a]-=dy*f;DX[b]+=dx*f;DY[b]+=dy*f}
    for(let i=0;i<n;i++){DX[i]-=X[i]*.012;DY[i]-=Y[i]*.012;
      const d=Math.sqrt(DX[i]*DX[i]+DY[i]*DY[i])||1e-6,m=Math.min(d,temp);X[i]+=DX[i]/d*m;Y[i]+=DY[i]/d*m}
  }
  comp.forEach((v,i)=>{N[v].x=X[i];N[v].y=Y[i]});
}
function removeOverlap(comp,N,rand,maxIt=250){
  for(let it=0;it<maxIt;it++){let moved=false;
    for(let a=0;a<comp.length;a++)for(let b=a+1;b<comp.length;b++){
      const p=N[comp[a]],q=N[comp[b]];let dx=q.x-p.x,dy=q.y-p.y;
      const ox=(p.fw+q.fw)/2-Math.abs(dx),oy=(p.fh+q.fh)/2-Math.abs(dy);
      if(ox>0&&oy>0){moved=true;
        if(dx===0&&dy===0){dx=rand()-.5;dy=rand()-.5}
        if(ox<oy){const s=(ox/2+.6)*(dx>=0?1:-1);p.x-=s;q.x+=s}else{const s=(oy/2+.6)*(dy>=0?1:-1);p.y-=s;q.y+=s}}}
    if(!moved)break}
}
function crossInc(N,UE,inc,vs){
  const A=new Set();vs.forEach(v=>(inc.get(v)||[]).forEach(e=>A.add(e)));let c=0;
  for(const ei of A){const a=UE[ei];
    for(let ej=0;ej<UE.length;ej++){if(ej===ei||(A.has(ej)&&ej<ei))continue;const b=UE[ej];
      if(a[0]===b[0]||a[0]===b[1]||a[1]===b[0]||a[1]===b[1])continue;
      if(segCross(N[a[0]],N[a[1]],N[b[0]],N[b[1]]))c++}}
  return c;
}
function reduceCrossings(comp,N,UEall,rand,ms){
  const set=new Set(comp),UE=UEall.filter(e=>set.has(e[0]));
  if(UE.length<3||comp.length<4)return;
  const inc=new Map();UE.forEach((e,i)=>{(inc.get(e[0])||inc.set(e[0],[]).get(e[0])).push(i);(inc.get(e[1])||inc.set(e[1],[]).get(e[1])).push(i)});
  let total=countCross(N,UE);if(!total)return;
  const t0=performance.now();let stale=0;
  while(performance.now()-t0<ms&&total>0&&stale<4000){
    const v=comp[Math.floor(rand()*comp.length)];
    const near=comp.filter(u=>u!==v).sort((a,b)=>((N[a].x-N[v].x)**2+(N[a].y-N[v].y)**2)-((N[b].x-N[v].x)**2+(N[b].y-N[v].y)**2)).slice(0,8);
    near.push(comp[Math.floor(rand()*comp.length)]);
    const u=near[Math.floor(rand()*near.length)];if(u===v){stale++;continue}
    const ra=N[v].fw*N[v].fh,rb=N[u].fw*N[u].fh;if(Math.max(ra,rb)/Math.min(ra,rb)>2.6){stale++;continue}
    const before=crossInc(N,UE,inc,[v,u]);
    let t=N[v].x;N[v].x=N[u].x;N[u].x=t;t=N[v].y;N[v].y=N[u].y;N[u].y=t;
    const after=crossInc(N,UE,inc,[v,u]);
    if(after<before){total-=before-after;stale=0}else{t=N[v].x;N[v].x=N[u].x;N[u].x=t;t=N[v].y;N[v].y=N[u].y;N[u].y=t;stale++}
  }
}
function circleStage(comp,N,UE,rand){
  const n=comp.length;if(n<3){comp.forEach((v,i)=>{N[v].x=i*N[v].fw*1.5;N[v].y=0});return}
  const set=new Set(comp);let order=[];const seen=new Set();
  const root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const dfs=v=>{seen.add(v);order.push(v);N[v].nb.slice().sort((a,b)=>N[b].wdeg-N[a].wdeg).forEach(u=>{if(!seen.has(u)&&set.has(u))dfs(u)})};dfs(root);
  const es=UE.filter(e=>set.has(e[0]));
  const crossings=ord=>{const p=new Map(ord.map((v,i)=>[v,i]));let c=0;
    for(let i=0;i<es.length;i++){let [a,b]=[p.get(es[i][0]),p.get(es[i][1])];if(a>b)[a,b]=[b,a];
      for(let j=i+1;j<es.length;j++){let [x,y]=[p.get(es[j][0]),p.get(es[j][1])];if(x>y)[x,y]=[y,x];
        if(a===x||a===y||b===x||b===y)continue;if((a<x&&x<b&&b<y)||(x<a&&a<y&&y<b))c++}}return c};
  let best=order.slice(),bc=crossings(best);
  for(let k=0;k<24;k++){const p=new Map(best.map((v,i)=>[v,i])),bar=new Map();
    best.forEach(v=>{const nb=N[v].nb.filter(u=>set.has(u));if(!nb.length){bar.set(v,p.get(v));return}
      let sx=0,sy=0;nb.forEach(u=>{const a=p.get(u)/n*2*Math.PI;sx+=Math.cos(a);sy+=Math.sin(a)});
      let a=Math.atan2(sy,sx);if(a<0)a+=2*Math.PI;bar.set(v,a/(2*Math.PI)*n+(rand()-.5)*.01)});
    const cand=best.slice().sort((a,b)=>bar.get(a)-bar.get(b)),cc=crossings(cand);if(cc<=bc){best=cand;bc=cc}}
  const circ=best.reduce((s,v)=>s+N[v].fw*1.15,0),Rr=Math.max(120,circ/(2*Math.PI));
  best.forEach((v,i)=>{const a=i/n*2*Math.PI;N[v].x=Math.cos(a)*Rr;N[v].y=Math.sin(a)*Rr});
}
function layerStage(comp,N,UE){
  const set=new Set(comp),root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const lvl=new Map([[root,0]]),q=[root];for(let h=0;h<q.length;h++)for(const u of N[q[h]].nb)if(!lvl.has(u)&&set.has(u)){lvl.set(u,lvl.get(q[h])+1);q.push(u)}
  const layers=[];q.forEach(v=>(layers[lvl.get(v)]||(layers[lvl.get(v)]=[])).push(v));
  const idx=new Map();layers.forEach(L=>L.forEach((v,i)=>idx.set(v,i)));
  const bary=(v,adj)=>{const nb=N[v].nb.filter(u=>set.has(u)&&adj(u));return nb.length?nb.reduce((s,u)=>s+idx.get(u),0)/nb.length:idx.get(v)};
  for(let s=0;s<8;s++){
    for(let l=1;l<layers.length;l++){layers[l].sort((a,b)=>bary(a,u=>lvl.get(u)===l-1)-bary(b,u=>lvl.get(u)===l-1));layers[l].forEach((v,i)=>idx.set(v,i))}
    for(let l=layers.length-2;l>=0;l--){layers[l].sort((a,b)=>bary(a,u=>lvl.get(u)===l+1)-bary(b,u=>lvl.get(u)===l+1));layers[l].forEach((v,i)=>idx.set(v,i))}}
  let x=0;layers.forEach(L=>{const w=Math.max(...L.map(v=>N[v].fw));const h=L.reduce((s,v)=>s+N[v].fh*1.1,0);let y=-h/2;
    L.forEach(v=>{N[v].x=x+w/2;N[v].y=y+N[v].fh*.55;y+=N[v].fh*1.1});x+=w*1.25+60});
}
function packComponents(comps,N,aspect){
  if(comps.length<=1){const c=comps[0]||[];if(!c.length)return;
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;c.forEach(v=>{const n=N[v];x0=Math.min(x0,n.x-n.fw/2);x1=Math.max(x1,n.x+n.fw/2);y0=Math.min(y0,n.y-n.fh/2);y1=Math.max(y1,n.y+n.fh/2)});
    const cx=(x0+x1)/2,cy=(y0+y1)/2;c.forEach(v=>{N[v].x-=cx;N[v].y-=cy});return}
  const boxes=comps.map(c=>{let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;c.forEach(v=>{const n=N[v];x0=Math.min(x0,n.x-n.fw/2);x1=Math.max(x1,n.x+n.fw/2);y0=Math.min(y0,n.y-n.fh/2);y1=Math.max(y1,n.y+n.fh/2)});
    return{c,x0,y0,w:x1-x0,h:y1-y0}}).sort((a,b)=>b.w*b.h-a.w*a.h);
  const m=36,area=boxes.reduce((s,b)=>s+(b.w+m)*(b.h+m),0),W0=Math.max(boxes[0].w+m,Math.sqrt(area*aspect)*1.08);
  let x=0,y=0,rowH=0,maxX=0;
  boxes.forEach(b=>{if(x>0&&x+b.w>W0){x=0;y+=rowH+m;rowH=0}
    const dx=x-b.x0,dy=y-b.y0;b.c.forEach(v=>{N[v].x+=dx;N[v].y+=dy});x+=b.w+m;rowH=Math.max(rowH,b.h);maxX=Math.max(maxX,x)});
  const tot=y+rowH,cx=(maxX-m)/2,cy=tot/2;comps.forEach(c=>c.forEach(v=>{N[v].x-=cx;N[v].y-=cy}));
}

/* ---------- mount ---------- */
function mount(host,opt){
  opt=opt||{};
  if(!cssDone){const s=document.createElement('style');s.textContent=CSS;document.head.appendChild(s);cssDone=true}
  host.innerHTML='';
  const root=document.createElement('div');root.className='gx';
  root.innerHTML=`<div class="gx-bar">
    <select data-r="layout" title="Layout algorithm"><option value="auto">Layout: Optimized</option><option value="radial">Radial tree</option><option value="force">Force-directed</option><option value="circle">Circular</option><option value="layers">Layered</option></select>
    <select data-r="labels" title="Label display"><option value="smart">Labels: smart</option><option value="all">Labels: all</option><option value="none">Labels: off</option></select>
    <button data-r="in" title="Zoom in">＋</button><button data-r="out" title="Zoom out">－</button><button data-r="fit" title="Fit and centre the whole graph">⤢ Fit</button><button data-r="re" title="Recompute the layout">↻ Re-layout</button><button data-r="full" title="Fill the whole screen">⛶ Full screen</button>
    <input data-r="find" type="text" placeholder="Find node…" size="10"><span class="gx-sp"></span><span class="gx-stat" data-r="stat"></span>
    <button data-r="png" title="Download PNG">PNG</button><button data-r="svg" title="Download SVG">SVG</button></div>
    <div class="gx-st"><canvas></canvas><div class="gx-leg" style="display:none"></div><div class="gx-tip"></div><div class="gx-msg"></div></div>`;
  host.appendChild(root);
  const $=s=>root.querySelector(s),st=$('.gx-st'),cv=$('canvas'),ctx=cv.getContext('2d'),tip=$('.gx-tip'),msg=$('.gx-msg'),leg=$('.gx-leg');
  const S={nodes:[],E:[],UE:[],k:1,tx:0,ty:0,W:600,H:400,dpr:1,sel:-1,hov:-1,auto:true,labels:'smart',layout:opt.layout||'auto',fontPx:opt.fontPx||12,rMin:opt.rMin||6,rMax:opt.rMax||22,pad:opt.pad||10,seed:7,stats:{},lbl:[],dirty:true,opt};
  $('[data-r=layout]').value=S.layout;
  const set=(sel,txt)=>{const e=$(sel);if(e)e.textContent=txt};

  function prep(){
    ctx.font=S.fontPx+'px '+FONT;
    const N=S.nodes,idx=new Map();N.forEach((n,i)=>{n.i=i;idx.set(n.id,i);n.nb=[];n.deg=0;n.wdeg=0});
    const seen=new Map(),UE=[],E=[];
    (S.rawE||[]).forEach(e=>{const s=idx.get(e.s),t=idx.get(e.t);if(s==null||t==null||s===t)return;
      E.push({s,t,w:e.w||1,color:e.color,dash:e.dash,label:e.label,dir:e.dir});
      const k=s<t?s+'|'+t:t+'|'+s,u=seen.get(k);
      if(u)u[2]+=e.w||1;else{const r=[Math.min(s,t),Math.max(s,t),e.w||1];seen.set(k,r);UE.push(r);N[s].nb.push(t);N[t].nb.push(s)}
      N[s].deg++;N[t].deg++;N[s].wdeg+=e.w||1;N[t].wdeg+=e.w||1});
    S.E=E;S.UE=UE;
    const mx=Math.max(1e-9,...N.map(n=>+n.size||1)),md=Math.max(1,...N.map(n=>n.deg));
    N.forEach(n=>{n.text=String(n.label??n.id);if(n.text.length>(opt.maxChars||30))n.text=n.text.slice(0,(opt.maxChars||30)-1)+'…';
      n.r=S.rMin+(S.rMax-S.rMin)*Math.sqrt(Math.max(0,(+n.size||1))/mx);n.lw=ctx.measureText(n.text).width;
      n.fw=Math.max(2*n.r,Math.min(n.lw,130)*.78)+S.pad;n.fh=2*n.r+S.fontPx+S.pad;
      n.imp=(+n.size||1)/mx+.35*n.deg/md+(n.pri||0)});
  }
  function layout(){
    const t0=performance.now(),N=S.nodes,rand=rng(S.seed);if(!N.length)return;
    if(S.layout==='fixed'){S.stats={nodes:N.length,edges:S.E.length,crossings:0,overlaps:overlapCount(N,N.map((n,i)=>i)),ms:0,comps:1};return}
    const comps=components(N),gap=Math.max(70,...N.map(n=>n.fw*.9)),L=Math.max(60,gap*.9);
    const iters=Math.max(60,Math.min(320,Math.round(90000/Math.max(8,N.length))));
    comps.forEach(c=>{
      if(S.layout==='circle'){circleStage(c,N,S.UE,rand);return}
      if(S.layout==='layers'){layerStage(c,N,S.UE);removeOverlap(c,N,rand);return}
      if(S.layout==='force'){c.forEach((v,i)=>{const a=i/c.length*2*Math.PI,r=L*Math.sqrt(c.length);N[v].x=Math.cos(a)*r;N[v].y=Math.sin(a)*r});forceStage(c,N,S.UE,L,iters,rand)}
      else{radialInit(c,N,gap);if(S.layout==='auto')forceStage(c,N,S.UE,L,Math.round(iters*.6),rand)}
      removeOverlap(c,N,rand);
      if(S.layout!=='radial'||true)reduceCrossings(c,N,S.UE,rand,Math.min(450,120+c.length*4));
      removeOverlap(c,N,rand,120)});
    const singles=comps.filter(c=>c.length===1),multi=comps.filter(c=>c.length>1);
    if(singles.length>1){const cols=Math.max(2,Math.ceil(Math.sqrt(singles.length*1.8))),cw=Math.max(...singles.map(c=>N[c[0]].fw))*1.04,ch=Math.max(...singles.map(c=>N[c[0]].fh))*1.04;
      singles.forEach((c,i)=>{N[c[0]].x=(i%cols)*cw;N[c[0]].y=Math.floor(i/cols)*ch});multi.push(singles.flat());packComponents(multi,N,S.W/Math.max(1,S.H))}
    else packComponents(comps,N,S.W/Math.max(1,S.H));
    for(let p=0;p<3;p++)removeOverlap(N.map((n,i)=>i),N,rand,60);
    N.forEach(n=>{n.bx=n.x;n.by=n.y});S.sx=1;S.sy=1;stretch();
    S.lastAspect=S.W/Math.max(1,S.H);
    S.stats={nodes:N.length,edges:S.E.length,crossings:countCross(N,S.UE),overlaps:overlapCount(N,N.map((n,i)=>i)),ms:Math.round(performance.now()-t0),comps:comps.length};
  }
  /* affine stretch so the layout fills the available aspect ratio; crossings are invariant, overlaps can only shrink */
  function stretch(){
    const N=S.nodes;if(S.layout==='fixed'||N.length<3||!S.W||!S.H)return;
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;N.forEach(n=>{x0=Math.min(x0,n.bx-n.fw/2);x1=Math.max(x1,n.bx+n.fw/2);y0=Math.min(y0,n.by-n.fh/2);y1=Math.max(y1,n.by+n.fh/2)});
    const w=Math.max(1,x1-x0),h=Math.max(1,y1-y0),target=Math.max(.3,(S.W-60)/Math.max(100,S.H-60)),cur=w/h;
    let sx=1,sy=1;if(cur<target*.92)sx=Math.min(target/cur,2.6);else if(cur>target/.92)sy=Math.min(cur/target,2.6);
    S.sx=sx;S.sy=sy;N.forEach(n=>{n.x=n.bx*sx;n.y=n.by*sy});
  }
  function bbox(){
    const N=S.nodes;if(!N.length)return null;let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
    N.forEach(n=>{const hw=Math.max(n.r,Math.min(n.lw,130)/2/Math.max(.35,S.k)*.0+n.r),hh=n.r;x0=Math.min(x0,n.x-n.r);x1=Math.max(x1,n.x+n.r);y0=Math.min(y0,n.y-n.r);y1=Math.max(y1,n.y+n.r)});
    return{x0,x1,y0,y1};
  }
  function fit(anim){
    const b=bbox();if(!b)return;const padPx=Math.max(26,Math.min(60,Math.min(S.W,S.H)*.07)),lblPx=S.labels==='none'?0:Math.min(70,S.fontPx*5);
    const bw=Math.max(1,b.x1-b.x0),bh=Math.max(1,b.y1-b.y0);
    const k=Math.max(.01,Math.min((S.W-2*padPx-lblPx)/bw,(S.H-2*padPx-S.fontPx*2)/bh,opt.maxFit||2.2));
    const cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2,tx=S.W/2-cx*k,ty=S.H/2-cy*k;
    S.auto=true;
    if(anim&&!opt.noAnim){const a={k:S.k,tx:S.tx,ty:S.ty},t0=performance.now();const step=t=>{const p=Math.min(1,(t-t0)/260),e=p*(2-p);S.k=a.k+(k-a.k)*e;S.tx=a.tx+(tx-a.tx)*e;S.ty=a.ty+(ty-a.ty)*e;S.dirty=true;draw();if(p<1)requestAnimationFrame(step)};requestAnimationFrame(step)}
    else{S.k=k;S.tx=tx;S.ty=ty;S.dirty=true;draw()}
  }
  function resize(){
    const r=st.getBoundingClientRect();if(r.width<10||r.height<10)return;
    S.dpr=window.devicePixelRatio||1;S.W=Math.round(r.width);S.H=Math.round(r.height);
    cv.width=Math.round(S.W*S.dpr);cv.height=Math.round(S.H*S.dpr);
    if(S.auto){const a=S.W/S.H;if(S.nodes.length>2&&S.lastAspect&&Math.abs(a/S.lastAspect-1)>.1)stretch();S.lastAspect=a;fit(false)}else{S.dirty=true;draw()}
  }
  function placeLabels(){
    const N=S.nodes,k=S.k,tx=S.tx,ty=S.ty,W=S.W,H=S.H;
    ctx.font=S.fontPx+'px '+FONT;
    const out=new Array(N.length).fill(null);if(S.labels==='none')return out;
    const sc=N.map(n=>({x:n.x*k+tx,y:n.y*k+ty,r:Math.max(3.5,n.r*k)}));
    const boxes=[],h=S.fontPx+4;
    const order=N.map((n,i)=>i).sort((a,b)=>(N[b].imp+(b===S.sel||b===S.hov?9:0))-(N[a].imp+(a===S.sel||a===S.hov?9:0)));
    const hit=b=>{for(const o of boxes)if(b.x<o.x+o.w&&b.x+b.w>o.x&&b.y<o.y+o.h&&b.y+b.h>o.y)return true;return false};
    const hitN=(b,skip)=>{for(let j=0;j<sc.length;j++){if(j===skip)continue;const c=sc[j];if(c.x+c.r>b.x&&c.x-c.r<b.x+b.w&&c.y+c.r>b.y&&c.y-c.r<b.y+b.h)return true}return false};
    for(const i of order){const c=sc[i],n=N[i];if(c.x<-40||c.x>W+40||c.y<-20||c.y>H+20)continue;
      const w=n.lw+6,force=i===S.sel||i===S.hov||S.labels==='all';
      const cands=[[c.x-w/2,c.y+c.r+2],[c.x+c.r+3,c.y-h/2],[c.x-c.r-3-w,c.y-h/2],[c.x-w/2,c.y-c.r-2-h],[c.x+c.r*.7,c.y+c.r*.7],[c.x-c.r*.7-w,c.y+c.r*.7],[c.x+c.r*.7,c.y-c.r*.7-h],[c.x-c.r*.7-w,c.y-c.r*.7-h]];
      for(const [x,y] of cands){const b={x,y,w,h};if(x<2||y<2||x+w>W-2||y+h>H-2)continue;if(force||(!hit(b)&&!hitN(b,i))){out[i]=b;boxes.push(b);break}}
      if(!out[i]&&force){const b={x:Math.max(2,Math.min(W-w-2,c.x-w/2)),y:Math.max(2,Math.min(H-h-2,c.y+c.r+2)),w,h};out[i]=b;boxes.push(b)}}
    return out;
  }
  function draw(){
    if(!S.W)return;
    const N=S.nodes,k=S.k,tx=S.tx,ty=S.ty;
    ctx.setTransform(S.dpr,0,0,S.dpr,0,0);ctx.clearRect(0,0,S.W,S.H);
    if(opt.underlay){ctx.save();try{opt.underlay(ctx,S)}catch(e){}ctx.restore()}
    msg.style.display=N.length?'none':'flex';if(!N.length)return;
    const hov=S.hov>=0?S.hov:S.sel,nbs=hov>=0?new Set([hov,...N[hov].nb]):null;
    const dim=i=>nbs&&!nbs.has(i);
    const dense=S.E.length>350;
    S.E.forEach(e=>{const a=N[e.s],b=N[e.t],hl=nbs&&(e.s===hov||e.t===hov),dm=nbs&&!hl;
      ctx.globalAlpha=dm?.06:hl?.95:Math.min(.85,(dense?.18:(S.E.length<60?.62:.32))+Math.min(.4,e.w*.05));
      ctx.strokeStyle=hl?'#184e77':(e.color||'#8a9bb0');ctx.lineWidth=(hl?2:Math.min(3.2,.8+Math.log1p(e.w)*.45));
      ctx.setLineDash(e.dash?[5,4]:[]);
      const x1=a.x*k+tx,y1=a.y*k+ty,x2=b.x*k+tx,y2=b.y*k+ty;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
      if(e.dir){const dx=x2-x1,dy=y2-y1,d=Math.hypot(dx,dy)||1,r=Math.max(3.5,b.r*k)+2,px=x2-dx/d*r,py=y2-dy/d*r,ux=dx/d,uy=dy/d;ctx.setLineDash([]);ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px-ux*9+uy*4,py-uy*9-ux*4);ctx.lineTo(px-ux*9-uy*4,py-uy*9+ux*4);ctx.closePath();ctx.fill()}});
    ctx.setLineDash([]);
    N.forEach((n,i)=>{const x=n.x*k+tx,y=n.y*k+ty,r=Math.max(3.5,n.r*k);if(x<-r||x>S.W+r||y<-r||y>S.H+r)return;
      ctx.globalAlpha=dim(i)?.18:1;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fillStyle=n.color||'#184e77';ctx.fill();
      ctx.lineWidth=i===S.sel?3:1.2;ctx.strokeStyle=i===S.sel?'#f59e0b':'#fff';ctx.stroke();
      if(n.cen){ctx.beginPath();ctx.arc(x,y,r+4,0,7);ctx.lineWidth=2.5;ctx.strokeStyle='#f59e0b';ctx.stroke()}
      if(n.fx){ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y,2,0,7);ctx.fill()}});
    if(S.dirty||!S.lbl.length||S.lbl.length!==N.length){S.lbl=placeLabels();S.dirty=false}
    ctx.font=S.fontPx+'px '+FONT;ctx.textBaseline='middle';
    N.forEach((n,i)=>{const b=S.lbl[i];if(!b)return;ctx.globalAlpha=dim(i)?.25:1;
      ctx.lineWidth=3.4;ctx.strokeStyle='rgba(255,255,255,.94)';ctx.lineJoin='round';ctx.strokeText(n.text,b.x+3,b.y+b.h/2);
      ctx.fillStyle=i===S.sel?'#92400e':'#162033';ctx.fillText(n.text,b.x+3,b.y+b.h/2)});
    if(S.rawE&&S.E.some(e=>e.label)&&(opt.edgeLabels==='always'||(S.E.length<=40&&k>.5))){
      ctx.font=(S.fontPx-1)+'px '+FONT;ctx.textAlign='center';ctx.textBaseline='middle';
      const taken=[];S.lbl.forEach(bx=>{if(bx)taken.push(bx)});N.forEach(n=>{const r=Math.max(3.5,n.r*k);taken.push({x:n.x*k+tx-r,y:n.y*k+ty-r,w:2*r,h:2*r})});
      const area=b=>{let s=0;for(const o of taken){const w=Math.min(b.x+b.w,o.x+o.w)-Math.max(b.x,o.x),h=Math.min(b.y+b.h,o.y+o.h)-Math.max(b.y,o.y);if(w>0&&h>0)s+=w*h}return s},few=S.E.length<=14;
      S.E.forEach(e=>{if(!e.label)return;const a=N[e.s],c=N[e.t],w=ctx.measureText(e.label).width+6,h=S.fontPx+3;let best=null;
        for(const f of [.5,.4,.6,.32,.68,.24,.76,.16,.84]){const x=(a.x+(c.x-a.x)*f)*k+tx,y=(a.y+(c.y-a.y)*f)*k+ty,b={x:x-w/2,y:y-h/2,w,h},ar=area(b);if(!best||ar<best.ar){best={x,y,b,ar}}if(ar===0)break}
        if(!best||(best.ar>0&&!few))return;taken.push(best.b);ctx.globalAlpha=nbs&&!(e.s===hov||e.t===hov)?.2:1;
        ctx.lineWidth=3.4;ctx.strokeStyle='rgba(255,255,255,.95)';ctx.strokeText(e.label,best.x,best.y);ctx.fillStyle='#1f4e8c';ctx.fillText(e.label,best.x,best.y)});
      ctx.textAlign='start'}
    ctx.globalAlpha=1;
    set('[data-r=stat]',`${S.stats.nodes||0} nodes · ${S.stats.edges||0} edges · crossings ${S.stats.crossings??'–'} · overlaps ${S.stats.overlaps??'–'} · ${Math.round(S.k*100)}%`);
  }
  function hit(px,py){const N=S.nodes;let best=-1,bd=1e9;N.forEach((n,i)=>{const x=n.x*S.k+S.tx,y=n.y*S.k+S.ty,r=Math.max(3.5,n.r*S.k)+4,d=Math.hypot(px-x,py-y);if(d<r&&d<bd){bd=d;best=i}});return best}
  /* interaction */
  const ptrs=new Map();let drag=null,pinch=null,moved=false;
  const pos=e=>{const r=cv.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
  const zoomAt=(px,py,f)=>{const nk=Math.max(.02,Math.min(8,S.k*f)),r=nk/S.k;S.tx=px-(px-S.tx)*r;S.ty=py-(py-S.ty)*r;S.k=nk;S.auto=false;S.dirty=true;draw()};
  cv.addEventListener('wheel',e=>{e.preventDefault();const [px,py]=pos(e);zoomAt(px,py,e.deltaY<0?1.14:.877)},{passive:false});
  cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);const [px,py]=pos(e);ptrs.set(e.pointerId,[px,py]);moved=false;
    if(ptrs.size===2){const [a,b]=[...ptrs.values()];pinch={d:Math.hypot(a[0]-b[0],a[1]-b[1])};drag=null;return}
    const i=hit(px,py);drag=i>=0?{node:i,ox:px,oy:py}:{pan:true,x:px-S.tx,y:py-S.ty};cv.classList.add('drag')});
  cv.addEventListener('pointermove',e=>{const [px,py]=pos(e);
    if(ptrs.has(e.pointerId))ptrs.set(e.pointerId,[px,py]);
    if(pinch&&ptrs.size===2){const [a,b]=[...ptrs.values()],d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(pinch.d>0)zoomAt((a[0]+b[0])/2,(a[1]+b[1])/2,d/pinch.d);pinch.d=d;moved=true;return}
    if(drag){moved=true;
      if(drag.node!=null){const n=S.nodes[drag.node];n.x=(px-S.tx)/S.k;n.y=(py-S.ty)/S.k;n.bx=n.x/(S.sx||1);n.by=n.y/(S.sy||1);n.fx=true;S.auto=false}
      else{S.tx=px-drag.x;S.ty=py-drag.y;S.auto=false}
      S.dirty=true;draw();return}
    const i=hit(px,py);
    if(i!==S.hov){S.hov=i;S.dirty=true;draw()}
    if(i>=0){const n=S.nodes[i];tip.innerHTML=opt.tip?opt.tip(n):`<b>${esc(n.label)}</b>`;tip.style.display='block';tip.style.left=Math.min(S.W-200,px+14)+'px';tip.style.top=Math.min(S.H-40,py+12)+'px'}else tip.style.display='none'});
  const up=e=>{const [px,py]=pos(e);ptrs.delete(e.pointerId);if(ptrs.size<2)pinch=null;cv.classList.remove('drag');
    if(drag&&!moved){const i=hit(px,py);S.sel=i;S.dirty=true;draw();if(i>=0&&opt.onSelect)opt.onSelect(S.nodes[i]);else if(i<0&&opt.onSelect)opt.onSelect(null)}
    if(drag&&moved&&drag.node!=null){S.stats.crossings=countCross(S.nodes,S.UE);draw()}
    drag=null};
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('pointerleave',()=>{tip.style.display='none';if(S.hov>=0){S.hov=-1;S.dirty=true;draw()}});
  cv.addEventListener('dblclick',e=>{const [px,py]=pos(e),i=hit(px,py);if(i>=0&&opt.onOpen)opt.onOpen(S.nodes[i]);else fit(true)});
  /* toolbar */
  root.addEventListener('click',e=>{const b=e.target.closest('button[data-r]');if(!b)return;const a=b.dataset.r;
    if(a==='in')zoomAt(S.W/2,S.H/2,1.3);if(a==='out')zoomAt(S.W/2,S.H/2,1/1.3);if(a==='fit')fit(true);
    if(a==='re'){S.seed=(S.seed*31+11)%100000;relayout()}
    if(a==='full'){root.classList.toggle('gx-full');b.classList.toggle('on',root.classList.contains('gx-full'));b.textContent=root.classList.contains('gx-full')?'✕ Exit full screen':'⛶ Full screen';setTimeout(()=>{resize();fit(false)},60)}
    if(a==='png')cv.toBlob(bl=>{const u=URL.createObjectURL(bl),l=document.createElement('a');l.href=u;l.download=(opt.name||'graph')+'.png';l.click();setTimeout(()=>URL.revokeObjectURL(u),2000)});
    if(a==='svg')dl(toSVG(),(opt.name||'graph')+'.svg','image/svg+xml')});
  root.querySelector('[data-r=layout]').onchange=e=>{S.layout=e.target.value;relayout()};
  root.querySelector('[data-r=labels]').onchange=e=>{S.labels=e.target.value;S.dirty=true;draw()};
  root.querySelector('[data-r=find]').oninput=e=>{const q=e.target.value.trim().toLowerCase();if(!q){S.sel=-1;S.dirty=true;draw();return}const i=S.nodes.findIndex(n=>String(n.label).toLowerCase().includes(q));if(i<0)return;S.sel=i;const n=S.nodes[i];S.k=Math.max(S.k,Math.min(1.6,.9));S.tx=S.W/2-n.x*S.k;S.ty=S.H/2-n.y*S.k;S.auto=false;S.dirty=true;draw()};
  const dl=(t,name,type)=>{const bl=new Blob([t],{type}),u=URL.createObjectURL(bl),l=document.createElement('a');l.href=u;l.download=name;l.click();setTimeout(()=>URL.revokeObjectURL(u),2000)};
  function toSVG(){
    const N=S.nodes,b=bbox()||{x0:0,x1:10,y0:0,y1:10},m=60,w=b.x1-b.x0+2*m,h=b.y1-b.y0+2*m;
    const sv=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${b.x0-m} ${b.y0-m} ${w} ${h}" width="${Math.round(w)}" height="${Math.round(h)}" font-family="${FONT}"><rect x="${b.x0-m}" y="${b.y0-m}" width="${w}" height="${h}" fill="#fff"/>`];
    S.E.forEach(e=>{const a=N[e.s],c=N[e.t];sv.push(`<line x1="${a.x.toFixed(1)}" y1="${a.y.toFixed(1)}" x2="${c.x.toFixed(1)}" y2="${c.y.toFixed(1)}" stroke="${e.color||'#8a9bb0'}" stroke-opacity=".6" stroke-width="${Math.min(3,.8+Math.log1p(e.w)*.45).toFixed(2)}"/>`)});
    N.forEach(n=>sv.push(`<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${n.r.toFixed(1)}" fill="${n.color||'#184e77'}" stroke="#fff"/>`+(S.labels==='none'?'':`<text x="${n.x.toFixed(1)}" y="${(n.y+n.r+13).toFixed(1)}" font-size="12" text-anchor="middle" fill="#162033" stroke="#fff" stroke-width="3" paint-order="stroke">${esc(n.text)}</text>`)));
    return sv.join('')+'</svg>';
  }
  function relayout(){layout();fit(false);S.dirty=true;draw()}
  const ro=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{clearTimeout(S.rt);S.rt=setTimeout(resize,40)}):null;if(ro)ro.observe(st);else addEventListener('resize',resize);
  const api={
    setData(nodes,edges,o){S.nodes=(nodes||[]).map(n=>Object.assign({},n));S.rawE=edges||[];S.sel=-1;S.hov=-1;S.lbl=[];if(o&&o.layout){S.layout=o.layout;if(o.layout!=='fixed')root.querySelector('[data-r=layout]').value=o.layout}
      const fx=S.layout==='fixed';['[data-r=layout]','[data-r=re]'].forEach(q=>{const e=root.querySelector(q);if(e)e.style.display=fx?'none':''});
      msg.textContent=opt.empty||'Nothing to display for this selection.';
      const lg=(o&&o.legend)||opt.legend;if(lg&&lg.length){leg.style.display='block';leg.innerHTML=lg.map(x=>`<div><i style="background:${x.color}"></i>${esc(x.label)}</div>`).join('')}else leg.style.display='none';
      resize();prep();layout();S.auto=true;fit(false);S.dirty=true;draw();return api},
    fit,relayout,resize,select(id){const i=S.nodes.findIndex(n=>n.id===id);S.sel=i;S.dirty=true;draw()},
    stats:()=>Object.assign({k:S.k,tx:S.tx,ty:S.ty,W:S.W,H:S.H},S.stats),nodes:()=>S.nodes,state:S,toSVG,
    destroy(){if(ro)ro.disconnect();root.remove()}};
  return api;
}
window.GX={mount,_t:{countCross,overlapCount,segCross}};
})();

