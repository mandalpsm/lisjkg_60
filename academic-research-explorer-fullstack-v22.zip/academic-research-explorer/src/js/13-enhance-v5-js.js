
/* Knowledge graph results open on the whole page; every existing graph control is unchanged. */
(()=>{
  const modal=()=>document.getElementById('modal'),card=()=>document.getElementById('modalCard');
  const sync=()=>{const m=modal(),c=card();if(m&&c)m.classList.toggle('kg-full',c.classList.contains('graph-modal-card'))};
  const _show=window.showModal;
  window.showModal=function(){const r=_show.apply(this,arguments);sync();return r};
  const _close=window.closeModal;
  window.closeModal=function(){const m=modal();if(m)m.classList.remove('kg-full');return _close.apply(this,arguments)};
  let t=null;
  window.addEventListener('resize',()=>{clearTimeout(t);t=setTimeout(()=>{const m=modal();if(m&&m.classList.contains('kg-full')&&window.KG&&KG.canvas&&typeof kgResize==='function'){try{kgResize();if(typeof kgFit==='function')kgFit()}catch(e){}}},150)});
})();
