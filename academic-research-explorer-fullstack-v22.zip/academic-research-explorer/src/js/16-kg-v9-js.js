
/* ===== Knowledge graph v9: full-page toggle, double-click expansion, on-canvas hint ===== */
(()=>{const st=document.createElement('style');st.id='kg-v9-css';st.textContent='.kg-hint{position:absolute;left:12px;bottom:10px;z-index:4;background:rgba(255,255,255,.94);border:1px solid #cbd5e1;border-radius:8px;padding:6px 10px;font-size:12px;color:#334155;pointer-events:none;box-shadow:0 2px 8px rgba(15,23,42,.08)}.kg-stage{position:relative}#kgFull{font-weight:700}';if(!document.getElementById('kg-v9-css'))document.head.appendChild(st)})();
const KG_EXPAND_REL={author:['writes',true],journal:['published_in',false],keyword:['described_by',false],publisher:['published_by',false],place:['published_at',false],year:['appears_in',false],country:['associated country',false]};
function kgRecordsWith(type,label,limit=8){
  const key=norm(label),out=[];
  for(let i=0;i<R.length;i++){const r=R[i];let ok=false;
    if(type==='author')ok=splitAuthors(r[1]).some(a=>norm(a)===key||(window.X5&&X5.ok()&&X5.sameScholar(a,label)));
    else if(type==='keyword')ok=splitKeywords(r[11]).some(x=>norm(x)===key);
    else if(type==='journal')ok=norm(S[r[4]]||'')===key;
    else if(type==='publisher')ok=norm(PUB[r[5]]||'')===key;
    else if(type==='place')ok=norm(PLC[r[6]]||'')===key;
    else if(type==='country')ok=norm(CO[r[7]]||'')===key;
    else if(type==='year')ok=String(r[3])===label;
    if(ok)out.push(i)}
  return out.sort((a,b)=>R[b][0]-R[a][0]||a-b).slice(0,limit);
}
function kgExpand(n){
  if(!n||!KG.nodeMap)return;
  if(n.expanded){toast('Already expanded. Double-click another node.');return}
  n.expanded=true;
  const map=KG.nodeMap,before=new Set(KG.nodes),added=[];
  const add=spec=>{const key=spec.type==='paper'?('paper|'+spec.paperIndex):(spec.type+'|'+norm(spec.label));const had=map.has(key);const node=kgAddNode(map,spec);if(!had)added.push(node);return node};
  const link=(a,b,rel,detail)=>{if(!a||!b||a===b)return;const k=[a.id,b.id,rel].sort().join('§');if(KG.edges.some(e=>[e.a.id,e.b.id,e.relation].sort().join('§')===k))return;KG.edges.push({a,b,relation:rel,detail:detail||'',rev:'',hit:false})};
  const paperSpec=i=>{const o=recObj(i);return{type:'paper',label:o.title||'Untitled',paperIndex:i,cites:o.cites||0,year:o.year,source:o.source,url:safeUrl(o.url)||(doiOf(o.doi)?'https://doi.org/'+doiOf(o.doi):'')}};
  if(n.type==='paper'){
    const ps=relatedPapers(n.paperIndex,6);
    ps.forEach(x=>{const p=add(paperSpec(x.i));link(n,p,'related paper',x.reasons.join(', '))});
    if(!ps.length)toast('No related papers found for this record');
  }else if(KG_EXPAND_REL[n.type]){
    const recs=kgRecordsWith(n.type,n.label,8);
    const [rel,entityFirst]=KG_EXPAND_REL[n.type];
    recs.forEach(i=>{const p=add(paperSpec(i));if(entityFirst)link(n,p,rel,'Author → Title');else link(p,n,rel,'Title → '+n.type)});
    if(!recs.length)toast('No other records share this '+n.type);
  }else{toast('This node type cannot be expanded');n.expanded=false;return}
  // place new nodes on a ring around the node that was expanded
  const fresh=added.filter(x=>!before.has(x));
  fresh.forEach((x,k)=>{const a=-Math.PI/2+2*Math.PI*k/Math.max(1,fresh.length)+.2,r=kgRadius(n)+70+ (k%2)*22;x.x=n.x+r*Math.cos(a);x.y=n.y+r*Math.sin(a);x.vx=0;x.vy=0});
  KG.nodes=[...map.values()];
  // existing layout stays put; only new nodes settle
  const prev=new Map(KG.nodes.map(x=>[x,!!x.fixed]));
  KG.nodes.forEach(x=>{if(before.has(x))x.fixed=true});
  for(let s=0;s<220;s++)kgPhysicsStep();
  KG.nodes.forEach(x=>{x.fixed=prev.get(x)||false});
  kgSelect(n);
  if($('#kgStats'))$('#kgStats').innerHTML=kgStats();
  kgFit();
  toast(fresh.length?`Expanded: +${fresh.length} new node${fresh.length===1?'':'s'}`:'No new records are linked to this node');
}
function kgDblHandler(e){const c=KG.canvas,r=c.getBoundingClientRect(),n=kgHit(e.clientX-r.left,e.clientY-r.top);if(n)kgExpand(n)}
function kgToggleFull(){
  const m=document.getElementById('modal'),b=document.getElementById('kgFull');if(!m)return;
  const on=!m.classList.contains('kg-full');m.classList.toggle('kg-full',on);
  if(b)b.textContent=on?'⤢ Window view':'⛶ Full page';
  try{if(on&&document.documentElement.requestFullscreen&&!document.fullscreenElement)document.documentElement.requestFullscreen().catch(()=>{});
      if(!on&&document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen().catch(()=>{})}catch(err){}
  setTimeout(()=>{if(KG.canvas){kgResize();kgFit()}},120);
}
function kgEnhance(){
  const bar=document.querySelector('#modalBody .kg-toolbar');
  if(bar&&!document.getElementById('kgFull')){const b=document.createElement('button');b.className='ghost';b.id='kgFull';b.type='button';
    b.textContent=document.getElementById('modal').classList.contains('kg-full')?'⤢ Window view':'⛶ Full page';b.onclick=kgToggleFull;
    bar.insertBefore(b,document.getElementById('kgFit')||null)}
  const stage=document.querySelector('#modalBody .kg-stage');
  if(stage&&!stage.querySelector('.kg-hint')){const h=document.createElement('div');h.className='kg-hint';h.textContent='Double-click a node to expand it · drag to move · scroll to zoom';stage.appendChild(h)}
  if(KG.canvas)KG.canvas.ondblclick=kgDblHandler;
}
(()=>{const _open=window.kgOpen;window.kgOpen=function(){const r=_open.apply(this,arguments);try{kgEnhance()}catch(err){console.warn(err)}return r}})();
