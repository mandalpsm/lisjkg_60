

/* ===== Semantic Layer — linked browser (add-on): every class, entity and value is a link; entity knowledge graphs ===== */
(()=>{
'use strict';
const D=document,Q=s=>D.querySelector(s),QA=s=>[...D.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fm=n=>Number(n).toLocaleString(),enc=encodeURIComponent,dec=decodeURIComponent;
const short=(s,n=38)=>{s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s};
const okUrl=u=>/^https?:\/\//i.test(String(u||''))?u:'';
const TY={
 paper:{l:'Papers',s:'Paper',c:'#184e77'},
 author:{l:'Authors',s:'Author',c:'#7c3aed',rel:'dcterms:creator'},
 journal:{l:'Journals',s:'Journal',c:'#047857',rel:'schema:isPartOf'},
 concept:{l:'Concepts (keywords)',s:'Concept',c:'#c2410c',rel:'dcterms:subject'},
 year:{l:'Years',s:'Year',c:'#475569',rel:'dcterms:issued'},
 publisher:{l:'Publishers',s:'Publisher',c:'#b45309',rel:'dcterms:publisher'},
 country:{l:'Countries',s:'Country',c:'#be123c',rel:'schema:location'}};
const BYNAME=Object.fromEntries(Object.entries(TY).map(([k,v])=>[v.s.toLowerCase(),k]));
const ONT=[['paper','author','dcterms:creator'],['paper','journal','schema:isPartOf'],['paper','concept','dcterms:subject'],['paper','publisher','dcterms:publisher'],['paper','year','dcterms:issued'],['journal','publisher','schema:publisher'],['publisher','country','schema:location']];
const css=D.createElement('style');css.textContent=`
#slx{margin:6px 0 12px}
#slx .slx-bar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 8px}
#slx .slx-bar button,#slx .slx-act button,#slx .slx-pg button{border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:8px;padding:5px 10px;font-weight:600;color:var(--brand,#184e77);cursor:pointer;font-size:12.5px}
#slx .slx-bar button:disabled,#slx .slx-pg button:disabled{opacity:.4;cursor:default}
#slx .slx-bar button:hover:not(:disabled),#slx .slx-act button:hover,#slx .slx-pg button:hover:not(:disabled){background:#eaf0fb}
#slx .slx-crumb{font-size:13px;color:#51607a;display:flex;flex-wrap:wrap;gap:4px;align-items:center}
#slx a[data-go]{cursor:pointer;color:var(--brand,#184e77);text-decoration:none;border-bottom:1px dotted currentColor}#slx a[data-go]:hover{background:#eaf0fb}
.slx-link{cursor:pointer;color:var(--brand,#184e77)!important;text-decoration:none!important;border-bottom:1px dotted currentColor;font-weight:inherit}.slx-link:hover{background:#eaf0fb}
#slx .slx-chip{display:inline-flex;align-items:center;gap:5px;margin:2px 4px 2px 0;padding:3px 9px;border:1px solid var(--line,#dfe4ec);border-left:4px solid var(--c,#184e77);border-radius:999px;background:#fff;font-size:12.5px;border-bottom-width:1px;border-bottom-style:solid}
#slx .slx-chip small{color:#687386;font-size:11px}
#slx .slx-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(138px,1fr));gap:7px;margin:8px 0}
#slx .slx-cards a{display:block;padding:7px 10px;border:1px solid var(--line,#dfe4ec);border-left:5px solid var(--c);border-radius:10px;background:#fff;border-bottom:1px solid var(--line,#dfe4ec)}
#slx .slx-cards b{display:block;font-size:14px;color:#152033}#slx .slx-cards span{font-size:12px;color:#687386}#slx .slx-cards em{font-style:normal;color:var(--brand,#184e77);font-weight:700;font-size:12px}
#slx h3{margin:14px 0 4px;font-size:15px;color:var(--brand,#184e77);border-bottom:1px solid var(--line,#dfe4ec);padding-bottom:3px}
#slx .slx-k{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;margin:8px 0}
#slx .slx-k div{border:1px solid var(--line,#dfe4ec);border-radius:10px;padding:7px 10px;background:#fff}#slx .slx-k b{display:block;font-size:19px}#slx .slx-k span{font-size:11.5px;color:#687386}
#slx table{width:100%;border-collapse:collapse;font-size:13px}#slx th,#slx td{padding:5px 7px;border-bottom:1px solid #e8edf4;text-align:left;vertical-align:top}#slx th{background:#f3f7fb;font-size:12px}#slx .n{text-align:right;white-space:nowrap}
#slx .slx-sub{font-size:11.5px;color:#687386}
#slx .slx-ctl{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}#slx .slx-ctl input,#slx .slx-ctl select{border:1px solid var(--line,#dfe4ec);border-radius:8px;padding:6px 8px;font:inherit;font-size:13px}
#slx .slx-az{display:flex;flex-wrap:wrap;gap:2px;margin:4px 0}#slx .slx-az button{min-width:26px;padding:3px 4px;border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:6px;font-size:12px;cursor:pointer;color:var(--brand,#184e77)}#slx .slx-az button.on{background:var(--brand,#184e77);color:#fff}
#slx .slx-pg{display:flex;gap:6px;align-items:center;margin:8px 0;flex-wrap:wrap;font-size:12.5px}
#slx .slx-act{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
#slx .slx-badge{display:inline-block;padding:2px 9px;border-radius:999px;color:#fff;font-size:12px;font-weight:700}
#slx .slx-tl{display:flex;gap:6px;align-items:flex-end;height:80px;margin:6px 0}#slx .slx-tl a{flex:1;max-width:70px;background:var(--c,#184e77);color:#fff;border-radius:5px 5px 0 0;text-align:center;font-size:11px;display:flex;align-items:flex-end;justify-content:center;border-bottom:0!important;min-height:18px}
#slx .slx-abs{background:#f8fafc;border:1px solid var(--line,#dfe4ec);border-radius:10px;padding:9px 11px;line-height:1.55;font-size:13px}
#slx .slx-gh{width:100%;margin:6px 0}
@media(max-width:700px){#slx .slx-cards{grid-template-columns:1fr 1fr}}`;
D.head.appendChild(css);

/* ---------- data index (built once, on demand) ---------- */
let IXc=null;
function IX(){
  if(IXc&&IXc.R===R)return IXc;
  const Mp={author:new Map(),journal:new Map(),concept:new Map(),year:new Map(),publisher:new Map(),country:new Map()},n=R.length;
  const PA=new Array(n),PC=new Array(n),PJ=new Array(n),PP=new Array(n),PO=new Array(n);
  const add=(t,k,l,i)=>{if(!k)return;const m=Mp[t];let e=m.get(k);if(!e){e={k,l,p:[],t};m.set(k,e)}if(e.p[e.p.length-1]!==i)e.p.push(i)};
  for(let i=0;i<n;i++){const r=R[i],ak=[],ck=[];
    splitAuthors(r[1]).forEach(a=>{a=String(a).trim();const k=norm(a);if(k&&!ak.includes(k)){ak.push(k);add('author',k,a,i)}});
    splitKeywords(r[11]).forEach(w=>{w=String(w).trim();const k=norm(w);if(k&&!ck.includes(k)){ck.push(k);add('concept',k,w,i)}});
    PA[i]=ak;PC[i]=ck;
    const js=source(r),ps=publisher(r),cs=country(r),y=r[3];PJ[i]=js?norm(js):'';PP[i]=ps?norm(ps):'';PO[i]=cs?String(cs).trim():'';
    if(js)add('journal',PJ[i],js,i);if(ps)add('publisher',PP[i],ps,i);if(cs)add('country',PO[i],cs,i);if(y)add('year',String(y),String(y),i)}
  return IXc={R,M:Mp,PA,PC,PJ,PP,PO}}
const cites=i=>+R[i][0]||0;
function stat(e){if(e.c!=null)return e;const c=e.p.map(cites).sort((a,b)=>b-a);let h=0;while(h<c.length&&c[h]>=h+1)h++;let s=0;c.forEach(v=>s+=v);
  const ys=e.p.map(i=>+R[i][3]||0).filter(Boolean);e.c=s;e.h=h;e.y0=ys.length?Math.min(...ys):0;e.y1=ys.length?Math.max(...ys):0;return e}
const keysOf=(i,t)=>{const X=IX();return t==='author'?X.PA[i]:t==='concept'?X.PC[i]:t==='journal'?(X.PJ[i]?[X.PJ[i]]:[]):t==='publisher'?(X.PP[i]?[X.PP[i]]:[]):t==='country'?(X.PO[i]?[X.PO[i]]:[]):(R[i][3]?[String(R[i][3])]:[])};
function related(papers,t,N,skip){const X=IX(),cnt=new Map();papers.forEach(i=>keysOf(i,t).forEach(k=>{if(k!==skip)cnt.set(k,(cnt.get(k)||0)+1)}));
  return [...cnt].sort((a,b)=>b[1]-a[1]).slice(0,N).map(([k,n])=>({e:X.M[t].get(k),n})).filter(x=>x.e)}
const go_=(t,k)=>`data-go="ent|${t}|${enc(k)}"`;
const chip=(t,e,n)=>`<a href="#" class="slx-chip" style="--c:${TY[t].c}" ${go_(t,e.k)}>${esc(e.l)}${n!=null?`<small>${n}</small>`:''}</a>`;
const chips=(arr,t)=>arr.length?arr.map(x=>chip(t,x.e,x.n)).join(''):'<span class="slx-sub">—</span>';
const lnk=(t,e,txt)=>e?`<a href="#" ${go_(t,e.k)}>${esc(txt||e.l)}</a>`:esc(txt||'');
function paperLink(i){return `<a href="#" ${go_('paper',i)}>${esc(R[i][2]||'(untitled)')}</a>`}
function copyText(t){try{if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t)}catch(e){}const a=D.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';D.body.appendChild(a);a.select();try{D.execCommand('copy')}catch(e){}a.remove()}
const note=m=>{try{toast(m)}catch(e){}};
const csv=(name,head,rows)=>{const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"',t=[head.map(q).join(',')].concat(rows.map(r=>r.map(q).join(','))).join('\n');try{download(name,t,'text/csv')}catch(e){const b=new Blob([t],{type:'text/csv'}),u=URL.createObjectURL(b),a=D.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),2000)}};

/* ---------- navigation ---------- */
let root=null,G=null,NAV={h:[{t:'home'}],i:0},pending=null,COUNTS={};
function go(v,push=true){if(push){const cur=NAV.h[NAV.i];if(JSON.stringify(cur)===JSON.stringify(v))return;NAV.h=NAV.h.slice(0,NAV.i+1);NAV.h.push(v);NAV.i++}render()}
function hashOf(v){return v.t==='dir'?'#sl/dir/'+v.type:v.t==='ent'?'#sl/ent/'+v.type+'/'+enc(v.key):''}
function setHash(v){try{const h=hashOf(v);if(h)history.replaceState(null,'',h);else if(location.hash.startsWith('#sl/'))history.replaceState(null,'',location.pathname+location.search)}catch(e){}}
function parseHash(h){const m=String(h||'').match(/^#sl\/(dir|ent)\/([a-z]+)(?:\/(.+))?$/);if(!m||!TY[m[2]])return null;return m[1]==='dir'?{t:'dir',type:m[2]}:{t:'ent',type:m[2],key:dec(m[3]||'')}}
function crumbs(v){const a=[`<a href="#" data-go="home">Ontology</a>`];
  if(v.t==='dir')a.push(`<b>${TY[v.type].l}</b>`);
  if(v.t==='ent'){a.push(`<a href="#" data-go="dir|${v.type}">${TY[v.type].l}</a>`);a.push(`<b>${esc(short(entLabel(v.type,v.key),60))}</b>`)}
  return a.join(' <span>›</span> ')}
function entLabel(t,k){if(t==='paper')return R[+k]?R[+k][2]:'Paper';const e=IX().M[t].get(k);return e?e.l:k}

/* ---------- views ---------- */
function render(){
  if(!root||!root.isConnected)return;
  if(G){try{G.destroy()}catch(e){}G=null}
  const v=NAV.h[NAV.i];
  root.innerHTML=`<div class="slx-bar"><button data-nav="-1" ${NAV.i<1?'disabled':''}>‹ Back</button><button data-nav="1" ${NAV.i>=NAV.h.length-1?'disabled':''}>Forward ›</button><div class="slx-crumb">${crumbs(v)}</div></div><div id="slxb"></div>`;
  const b=root.querySelector('#slxb');
  ({home:viewHome,dir:viewDir,ent:viewEnt})[v.t](b,v);setHash(v);
  const top=root.getBoundingClientRect().top;if(v.t!=='home'&&top<0){const sc=root.closest('#modalCard')||D.scrollingElement;try{root.scrollIntoView({block:'start'})}catch(e){}}}

function graphHost(el,h){const d=D.createElement('div');d.className='slx-gh';d.style.height=h+'px';el.appendChild(d);return d}
const gh=host=>{const card=Q('#modalCard');if(!card||!host)return 460;const off=host.getBoundingClientRect().top-card.getBoundingClientRect().top+card.scrollTop;return Math.max(400,Math.min(720,card.clientHeight-off-28))};

function viewHome(b){
  const cl=Object.keys(TY);
  b.innerHTML=`<div class="slx-sub" style="margin-bottom:4px"><b>Every class is a link.</b> Click a node (or a card below) to browse <b>all</b> its records — each author, journal, publisher, country, year, concept and paper opens its own page with a knowledge graph, and everything on those pages links onward.</div>
  <div class="slx-cards">${cl.map(t=>`<a href="#" style="--c:${TY[t].c}" data-go="dir|${t}"><b>${TY[t].l}</b><span>${COUNTS[t]!=null?fm(COUNTS[t])+' records':'browse all'}</span><em style="display:block">Open all →</em></a>`).join('')}</div>
  <div class="slx-ctl"><label><input type="checkbox" id="slxti"> Show top entities in the graph</label><label>per class <select id="slxtn"><option>3</option><option selected>5</option><option>8</option></select></label></div>
  <div id="slxg"></div>`;
  const draw=()=>{if(G){G.destroy();G=null}const host=Q('#slxg');host.innerHTML='';
    const inst=Q('#slxti').checked,per=+Q('#slxtn').value,build=()=>{
      const nodes=cl.map(t=>({id:t,label:TY[t].s+' · '+(COUNTS[t]!=null?fm(COUNTS[t]):'…'),size:t==='paper'?800:Math.max(60,Math.sqrt(COUNTS[t]||50)*5),color:TY[t].c,cls:t,pri:2})),edges=ONT.map(([a,c,l])=>({s:a,t:c,label:l,dir:true,w:3,color:'#64748b'}));
      if(inst){const X=IX();['author','journal','concept','publisher','country','year'].forEach(t=>{[...X.M[t].values()].sort((a,c)=>c.p.length-a.p.length).slice(0,per).forEach(e=>{const id=t+':'+e.k;nodes.push({id,label:e.l,size:Math.max(4,Math.sqrt(e.p.length)*2),color:TY[t].c+'bb',t,k:e.k,n:e.p.length});edges.push({s:id,t,dash:true,w:1,color:TY[t].c})})})}
      const d=graphHost(host,gh(host));
      G=GX.mount(d,{name:'ontology',edgeLabels:'always',rMin:inst?5:20,rMax:inst?20:44,maxChars:32,fontPx:12,
        tip:n=>n.cls?`<b>${esc(TY[n.cls].l)}</b><br>Click to browse all`:`<b>${esc(n.label)}</b><br>${fm(n.n)} paper(s) · click to open`,
        onSelect:n=>{if(!n)return;if(n.cls)go({t:'dir',type:n.cls});else go({t:'ent',type:n.t,key:n.k})}});
      G.setData(nodes,edges,{legend:cl.map(t=>({color:TY[t].c,label:TY[t].s}))})};
    if(inst){host.innerHTML='<div class="slx-sub">Indexing records…</div>';setTimeout(build,30)}else build()};
  draw();Q('#slxti').onchange=draw;Q('#slxtn').onchange=draw}

/* directory of all records of a class */
const DIR={};
function dirRows(t){
  if(DIR[t]&&DIR[t].R===R)return DIR[t].rows;const X=IX();let rows;
  if(t==='paper'){rows=R.map((r,i)=>({k:String(i),l:String(r[2]||'(untitled)'),n:1,c:+r[0]||0,y0:+r[3]||0,y1:+r[3]||0,x1:source(r)||'',x2:String(r[1]||''),h:(String(r[2]||'')+' '+String(r[1]||'')).toLowerCase()}))}
  else{rows=[...X.M[t].values()].map(e=>{stat(e);const o={k:e.k,l:e.l,n:e.p.length,c:e.c,y0:e.y0,y1:e.y1,h:e.l.toLowerCase()};
    if(t==='journal'){const f=e.p[0];o.x1=publisher(R[f])||'';o.x1k=X.PP[f];o.x2=(R[f][10]||'')}
    if(t==='publisher'||t==='country'){const s=new Set();e.p.forEach(i=>X.PJ[i]&&s.add(X.PJ[i]));o.x1=s.size}
    return o})}
  DIR[t]={R,rows};return rows}
function viewDir(b,v){
  const t=v.type;b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> All ${TY[t].l.toLowerCase()}</h3><p class="slx-sub">Preparing the list…</p>`;
  setTimeout(()=>{const rows=dirRows(t);COUNTS[t]=rows.length;let miss=0,flt='',sort=t==='paper'?'c':'n',letter='',page=0;const PS=100,hasAZ=t!=='year';
    const sortOpts=t==='paper'?[['c','Citations (high → low)'],['y','Year (newest)'],['l','Title A–Z']]:[['n','Papers (most → fewest)'],['c','Citations (high → low)'],['l','Name A–Z'],['y','Latest year']];
    const cols=t==='paper'?['Title','Year','Journal','Cites']:t==='journal'?['Journal','Publisher','Papers','Citations','Active']:t==='publisher'||t==='country'?[TY[t].s,'Journals','Papers','Citations','Active']:t==='year'?['Year','Papers','Citations']:[TY[t].s,'Papers','Citations','Active'];
    b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> All ${TY[t].l.toLowerCase()} <span class="slx-sub" id="slxc"></span></h3>
    ${(t==='country'||t==='publisher'||t==='journal')&&(miss=R.reduce((n,r)=>n+((t==='country'?country(r):t==='publisher'?publisher(r):source(r))?0:1),0))>0?`<div class="slx-sub">${fm(miss)} record(s) have no ${TY[t].s.toLowerCase()} value and are not listed here.</div>`:''}
    ${t==='concept'?`<div class="slx-sub">Keyword strings normalised for case and punctuation. The <b>Concepts (SKOS)</b> tab merges synonyms further${COUNTS.skos?` (${fm(COUNTS.skos)} concepts)`:''}.</div>`:''}
    <div class="slx-ctl"><input type="search" id="slxf" placeholder="Filter ${TY[t].l.toLowerCase()}…" size="30"><label>Sort <select id="slxs">${sortOpts.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select></label><button class="ghost" id="slxe" style="border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:8px;padding:5px 10px;font-weight:600;color:var(--brand,#184e77);cursor:pointer">⬇ CSV (filtered)</button></div>
    ${hasAZ?`<div class="slx-az" id="slxa"></div>`:''}<div id="slxt"></div>`;
    let view=rows;const letterOf=l=>{const c=(l||'').trim().charAt(0).toUpperCase();return /[A-Z]/.test(c)?c:'#'};
    const draw=()=>{const f=flt.toLowerCase();view=rows.filter(r=>(!f||r.h.includes(f))&&(!letter||letterOf(r.l)===letter));
      view.sort((a,c)=>sort==='l'?a.l.localeCompare(c.l):sort==='y'?(c.y1-a.y1)||(c.c-a.c):sort==='c'?(c.c-a.c)||(c.n-a.n):(c.n-a.n)||(c.c-a.c));
      const pages=Math.max(1,Math.ceil(view.length/PS));page=Math.min(page,pages-1);const sl=view.slice(page*PS,page*PS+PS);
      Q('#slxc').textContent='· '+fm(view.length)+(view.length!==rows.length?' of '+fm(rows.length):'')+' shown';
      const row=r=>t==='paper'?`<tr><td><a href="#" ${go_('paper',r.k)}>${esc(r.l)}</a><div class="slx-sub">${esc(short(r.x2,90))}</div></td><td>${r.y0?`<a href="#" ${go_('year',String(r.y0))}>${r.y0}</a>`:''}</td><td>${esc(short(r.x1,40))}</td><td class="n">${fm(r.c)}</td></tr>`
        :t==='journal'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a><div class="slx-sub">${esc(r.x2?'ISSN '+r.x2:'')}</div></td><td>${r.x1k&&IX().M.publisher.get(r.x1k)?`<a href="#" ${go_('publisher',r.x1k)}>${esc(r.x1)}</a>`:esc(r.x1)}</td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+'–'+r.y1:''}</td></tr>`
        :t==='publisher'||t==='country'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.x1)}</td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+'–'+r.y1:''}</td></tr>`
        :t==='year'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td></tr>`
        :`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+(r.y1!==r.y0?'–'+r.y1:''):''}</td></tr>`;
      Q('#slxt').innerHTML=`<table><tr>${cols.map((c,i)=>`<th class="${i>0&&/Papers|Cites|Citations|Journals/.test(c)?'n':''}">${c}</th>`).join('')}</tr>${sl.map(row).join('')||`<tr><td colspan="${cols.length}" class="slx-sub">No matches.</td></tr>`}</table>
      <div class="slx-pg"><button data-p="0" ${page<1?'disabled':''}>« First</button><button data-p="${page-1}" ${page<1?'disabled':''}>‹ Prev</button><span>Page ${page+1} of ${fm(pages)}</span><button data-p="${page+1}" ${page>=pages-1?'disabled':''}>Next ›</button><button data-p="${pages-1}" ${page>=pages-1?'disabled':''}>Last »</button></div>`;
      if(hasAZ)Q('#slxa').innerHTML=['All',...'ABCDEFGHIJKLMNOPQRSTUVWXYZ#'].map(c=>`<button data-l="${c==='All'?'':c}" class="${(letter||'')===(c==='All'?'':c)?'on':''}">${c}</button>`).join('')};
    let tm;Q('#slxf').oninput=e=>{clearTimeout(tm);tm=setTimeout(()=>{flt=e.target.value.trim();page=0;draw()},160)};Q('#slxs').value=sort;Q('#slxs').onchange=e=>{sort=e.target.value;page=0;draw()};
    b.onclick=e=>{const p=e.target.closest('[data-p]'),l=e.target.closest('[data-l]');if(p&&!p.disabled){page=+p.dataset.p;draw()}if(l){letter=l.dataset.l;page=0;draw()}};
    Q('#slxe').onclick=()=>csv(t+'-directory.csv',t==='paper'?['title','authors','year','journal','citations']:['name','papers','citations','first_year','last_year'],view.map(r=>t==='paper'?[r.l,r.x2,r.y0,r.x1,r.c]:[r.l,r.n,r.c,r.y0,r.y1]));
    draw()},20)}

/* entity page (author, journal, publisher, country, year, concept, paper) */
function kgFor(t,key){
  const X=IX(),nodes=new Map(),edges=[],seenE=new Set();
  const addN=(ty,k,label,size,ex)=>{const id=ty+':'+k;if(!nodes.has(id))nodes.set(id,Object.assign({id,label,size,color:TY[ty].c,t:ty,k:String(k)},ex||{}));return id};
  const addE=(s,c,label,dash)=>{const id=s+'>'+c;if(seenE.has(id))return;seenE.add(id);edges.push({s,t:c,label,dir:true,w:2,dash,color:'#7b8aa0'})};
  const lab=(ty,k)=>{const e=X.M[ty].get(k);return e?e.l:k};
  let papers;
  if(t==='paper'){const i=+key;papers=[i];const pid=addN('paper',i,short(R[i][2],42),90,{pri:9,n:cites(i)});
    // related papers sharing keywords/authors
    const sc=new Map();[...X.PC[i]].forEach(k=>{const e=X.M.concept.get(k);if(e&&e.p.length<400)e.p.forEach(j=>{if(j!==i)sc.set(j,(sc.get(j)||0)+1)})});X.PA[i].forEach(k=>{const e=X.M.author.get(k);if(e&&e.p.length<200)e.p.forEach(j=>{if(j!==i)sc.set(j,(sc.get(j)||0)+2)})});
    [...sc].sort((a,b)=>b[1]-a[1]||cites(b[0])-cites(a[0])).slice(0,4).forEach(([j])=>{const q=addN('paper',j,short(R[j][2],36)+' ('+R[j][3]+')',25,{n:cites(j)});addE(pid,q,'related',true)})}
  else{const e=X.M[t].get(key);if(!e)return{nodes:[],edges:[],legend:[]};stat(e);papers=e.p.slice().sort((a,b)=>cites(b)-cites(a)).slice(0,8);addN(t,key,e.l,140,{pri:9,n:e.p.length,cen:1})}
  papers.forEach(i=>{const pid=addN('paper',i,short(R[i][2],34)+' ('+R[i][3]+')',22+Math.sqrt(cites(i))*2,{n:cites(i)});
    const want={author:t==='paper'?8:3,journal:1,concept:t==='paper'?6:2,publisher:(t==='paper'||t==='publisher'||t==='country')?1:0,year:(t==='paper'||t==='year')?1:0,country:0};
    ['author','journal','concept','publisher','year'].forEach(ty=>{let ks=keysOf(i,ty);if(ty===t&&t!=='paper')ks=[key];else ks=ks.slice(0,want[ty]);if(ty===t&&t==='paper')return;
      ks.forEach(k=>{const id=addN(ty,k,lab(ty,k),14,{n:(X.M[ty].get(k)||{p:[]}).p.length});addE(pid,id,TY[ty].rel)})});
    if(t==='country'||t==='paper'){const k=X.PP[i],c=X.PO[i];if(k&&c&&(t==='country'?c===key:true)){const pidn='publisher:'+k;if(nodes.has(pidn)&&c){const cid=addN('country',c,lab('country',c),16,{n:(X.M.country.get(c)||{p:[]}).p.length});addE(pidn,cid,'schema:location')}}}
    if(t==='journal'||t==='paper'){const jk=X.PJ[i],pk=X.PP[i];if(jk&&pk&&nodes.has('journal:'+jk)&&nodes.has('publisher:'+pk))addE('journal:'+jk,'publisher:'+pk,'schema:publisher')}});
  const deg=new Map();edges.forEach(e=>{deg.set(e.s,(deg.get(e.s)||0)+1);deg.set(e.t,(deg.get(e.t)||0)+1)});
  nodes.forEach(n=>{if(!n.cen&&n.t!=='paper'&&n.pri!==9)n.size=10+(deg.get(n.id)||1)*14});
  const present=[...new Set([...nodes.values()].map(n=>n.t))];
  return{nodes:[...nodes.values()],edges,legend:present.map(ty=>({color:TY[ty].c,label:TY[ty].s}))}}

function entityGraph(el,t,key){
  const d=kgFor(t,key);if(d.nodes.length<2){el.innerHTML='<div class="slx-sub">Not enough linked data to draw a graph.</div>';return}
  const host=graphHost(el,Math.max(420,Math.min(620,innerHeight-260)));
  G=GX.mount(host,{name:'knowledge-graph-'+t,edgeLabels:d.nodes.length<=34?'always':'auto',rMin:7,rMax:30,maxChars:30,fontPx:12,
    tip:n=>`<b>${esc(n.label)}</b><br>${TY[n.t].s}${n.t==='paper'?' · '+fm(n.n)+' citations':' · '+fm(n.n)+' paper(s)'}<br><i>click to open</i>`,
    onSelect:n=>{if(n&&n.t&&!n.cen&&!(n.t===t&&n.k===String(key)))go({t:'ent',type:n.t,key:n.k})}});
  G.setData(d.nodes,d.edges,{legend:d.legend})}

function paperTable(papers,id,lim){
  const X=IX(),sorted=papers.slice().sort((a,b)=>cites(b)-cites(a));let n=lim||15;
  const html=()=>`<table><tr><th>Paper</th><th>Year</th><th>Journal</th><th class="n">Cites</th></tr>${sorted.slice(0,n).map(i=>{const r=R[i],au=X.PA[i].slice(0,3).map(k=>{const e=X.M.author.get(k);return e?lnk('author',e):''}).join('; ');
    return `<tr><td>${paperLink(i)}<div class="slx-sub">${au}${X.PA[i].length>3?' et al.':''}</div></td><td>${r[3]?lnk('year',X.M.year.get(String(r[3])),String(r[3])):''}</td><td>${X.PJ[i]?lnk('journal',X.M.journal.get(X.PJ[i])):''}</td><td class="n">${fm(cites(i))}</td></tr>`}).join('')}</table>${sorted.length>n?`<div class="slx-pg"><button data-more="${id}">Show ${Math.min(25,sorted.length-n)} more (${fm(sorted.length-n)} left)</button></div>`:''}`;
  return{html,more(){n+=25}}}

function viewEnt(b,v){
  const t=v.type,key=v.key,X=IX();let e=null,papers,title,sub='';
  if(t==='paper'){const i=+key;if(!R[i]){b.innerHTML='<div class="note">Record not found.</div>';return}papers=[i];title=R[i][2]||'(untitled)'}
  else{e=X.M[t].get(key);if(!e){b.innerHTML=`<div class="note">“${esc(key)}” was not found in the current dataset.</div>`;return}stat(e);papers=e.p;title=e.l}
  const act=`<div class="slx-act"><button data-a="search">⌕ Search library for this</button><button data-a="kg">⌘ Open in app Knowledge Graph</button><button data-a="csv">⬇ Papers (CSV)</button><button data-a="copy">🔗 Copy link</button></div>`;
  let body='';
  if(t==='paper'){const o=recObj(+key),i=+key,doi=o.doi?'https://doi.org/'+o.doi:okUrl(o.url);
    const au=X.PA[i].map(k=>X.M.author.get(k)).filter(Boolean),ky=X.PC[i].map(k=>X.M.concept.get(k)).filter(Boolean);
    body=`<div class="slx-k"><div><b>${fm(cites(i))}</b><span>Citations</span></div><div><b>${r4(R[i][3])}</b><span>Year</span></div><div><b>${au.length}</b><span>Authors</span></div></div>
    <h3>Authors</h3>${au.map(a=>chip('author',a,a.p.length)).join('')||'—'}
    <h3>Published in</h3>${X.PJ[i]?chip('journal',X.M.journal.get(X.PJ[i]),X.M.journal.get(X.PJ[i]).p.length):''}${X.PP[i]?chip('publisher',X.M.publisher.get(X.PP[i])):''}${X.PO[i]?chip('country',X.M.country.get(X.PO[i])):''}${R[i][3]?chip('year',X.M.year.get(String(R[i][3]))):''}${o.issn?`<span class="slx-sub"> ISSN ${esc(o.issn)}</span>`:''}
    <h3>Concepts / keywords</h3>${ky.map(k=>chip('concept',k,k.p.length)).join('')||'—'}
    ${doi?`<h3>Identifiers</h3><div><a href="${esc(doi)}" target="_blank" rel="noopener noreferrer">${esc(doi)} ↗</a></div>`:''}
    ${o.abstract?`<h3>Abstract</h3><div class="slx-abs">${esc(o.abstract)}</div>`:''}`;
    sub=`${au.slice(0,3).map(a=>esc(a.l)).join('; ')}${au.length>3?' et al.':''} · ${R[i][3]||''}`}
  else{
    const k5=[['Papers',fm(e.p.length)],['Citations',fm(e.c)],['h-index',e.h],['Mean cites',(e.c/e.p.length).toFixed(1)],['Active',e.y0?e.y0+(e.y1!==e.y0?'–'+e.y1:''):'–']];
    const sec=(h,html)=>`<h3>${h}</h3>${html}`,yrs=(()=>{const c=new Map();e.p.forEach(i=>{const y=R[i][3];if(y)c.set(y,(c.get(y)||0)+1)});const a=[...c].sort((x,y)=>x[0]-y[0]),mx=Math.max(1,...a.map(x=>x[1]));return a.length>1&&t!=='year'?`<div class="slx-tl" style="--c:${TY[t].c}">${a.map(([y,n])=>`<a href="#" ${go_('year',String(y))} title="${y}: ${n} paper(s)" style="height:${Math.max(18,n/mx*76)}px">${y}</a>`).join('')}</div>`:''})();
    const R_=(ty,n)=>chips(related(e.p,ty,n,ty===t?key:null),ty);let rel='';
    if(t==='author')rel=sec('Co-authors',R_('author',30))+sec('Journals',R_('journal',14))+sec('Publishers',R_('publisher',8))+sec('Countries',R_('country',8))+sec('Concepts / keywords',R_('concept',30));
    if(t==='journal')rel=sec('Publisher &amp; country',R_('publisher',3)+R_('country',3))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='publisher')rel=sec('Journals',R_('journal',60))+sec('Countries',R_('country',5))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='country')rel=sec('Publishers',R_('publisher',20))+sec('Journals',R_('journal',30))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='year')rel=sec('Journals',R_('journal',30))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',40))+sec('Countries',R_('country',10));
    if(t==='concept')rel=sec('Related concepts',R_('concept',36))+sec('Authors',R_('author',30))+sec('Journals',R_('journal',16))+sec('Countries',R_('country',8));
    body=`<div class="slx-k">${k5.map(([l,v])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>${yrs}${rel}`;
    sub=`${fm(e.p.length)} papers · ${fm(e.c)} citations`}
  b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> ${esc(title)}</h3><div class="slx-sub">${esc(sub)}</div>${act}
  <h3>Knowledge graph</h3><div class="slx-sub">The centre is this ${TY[t].s.toLowerCase()}; papers connect it to related authors, journals, publishers and concepts. Click any node to open it. Edge labels are the ontology properties.</div><div id="slxeg"></div>
  <div id="slxbody">${body}</div>${t==='paper'?'':`<h3>Papers (${fm(papers.length)})</h3><div id="slxpt"></div>`}`;
  entityGraph(Q('#slxeg'),t,key);
  let PT=null;if(t!=='paper'){PT=paperTable(papers,'pt',15);const draw=()=>{Q('#slxpt').innerHTML=PT.html()};draw();Q('#slxpt').onclick=ev=>{if(ev.target.dataset.more){PT.more();draw()}}}
  else{const o=recObj(+key);Q('#slxbody').insertAdjacentHTML('beforeend',`<div class="slx-act"><button data-a="detail">Open full record</button></div>`)}
  b.querySelector('.slx-act').onclick=ev=>{const a=ev.target.dataset.a;if(!a)return;
    if(a==='search'){const q=t==='paper'?title:t==='year'?String(title):title;Q('#q').value=q;closeModal();Q('#searchForm').requestSubmit()}
    if(a==='kg'){try{const hits=papers.slice().sort((x,y)=>cites(y)-cites(x)).slice(0,80).map(i=>({i,score:1,why:[]}));closeModal();kgOpen(hits,'results')}catch(er){note('Knowledge graph is unavailable for this selection')}}
    if(a==='csv')csv(t+'-papers.csv',['title','authors','year','journal','citations','doi'],papers.map(i=>[R[i][2],R[i][1],R[i][3],source(R[i]),cites(i),R[i][9]||'']));
    if(a==='copy'){copyText(location.href.split('#')[0]+hashOf(v));note('Link copied')}};
  const dtl=b.querySelector('[data-a=detail]');if(dtl)dtl.onclick=()=>detail(+key)}
const r4=y=>y||'–';

function viewHomeCounts(){const X=IX();for(const t of Object.keys(X.M))COUNTS[t]=X.M[t].size;COUNTS.paper=R.length}

/* ---------- mount into the Ontology tab ---------- */
function parseCounts(svg){const txt=svg.textContent;[['paper','Paper'],['author','Author'],['journal','Journal'],['concept','Concept'],['year','Year'],['publisher','Publisher'],['country','Country']].forEach(([t,l])=>{const m=txt.match(new RegExp(l+'\\s*([\\d,]+)\\s*instances'));if(m)COUNTS[t]=+m[1].replace(/,/g,'')});COUNTS.skos=COUNTS.concept}
function mount(host,svg){
  if(svg.dataset.sl)return;parseCounts(svg);
  const r=D.createElement('div');r.id='slx';svg.dataset.sl='1';svg.replaceWith(r);root=r;
  r.addEventListener('click',ev=>{const nav=ev.target.closest('[data-nav]');if(nav&&!nav.disabled){NAV.i=Math.max(0,Math.min(NAV.h.length-1,NAV.i+ +nav.dataset.nav));render();return}
    const a=ev.target.closest('a[data-go]');if(!a)return;ev.preventDefault();const p=a.dataset.go.split('|');
    if(p[0]==='home')go({t:'home'});else if(p[0]==='dir')go({t:'dir',type:p[1]});else if(p[0]==='ent')go({t:'ent',type:p[1],key:dec(p[2])})});
  // class names in the existing tables become links
  host.querySelectorAll('table td').forEach(td=>{if(td.dataset.sl)return;const tx=td.textContent.trim().toLowerCase(),t=BYNAME[tx];if(t&&td.children.length<=1&&!td.querySelector('a')){td.dataset.sl='1';const lab=td.textContent.trim();td.innerHTML=`<a href="#" class="slx-link" data-slc="${t}">${esc(lab)}</a>`}});
  NAV={h:[{t:'home'}],i:0};
  if(pending){NAV.h.push(pending);NAV.i=1;pending=null}
  render();
  setTimeout(()=>{try{const X=IX();Object.keys(X.M).forEach(t=>COUNTS[t]=X.M[t].size);COUNTS.paper=R.length;if(root&&root.isConnected&&NAV.h[NAV.i].t==='home')render()}catch(e){}},80)}
D.addEventListener('click',ev=>{const a=ev.target.closest&&ev.target.closest('a.slx-link');if(!a)return;ev.preventDefault();ev.stopPropagation();
  const c=a.dataset.slc;if(c){if(root&&root.isConnected)go({t:'dir',type:c});else{pending={t:'dir',type:c};toOntology()}return}
  const v={t:'ent',type:a.dataset.slt,key:a.dataset.slk};if(root&&root.isConnected){go(v);try{root.scrollIntoView({block:'start'})}catch(e){}}else{pending=v;toOntology()}},true);
function toOntology(){const b=QA('#modalCard .tabs button').find(x=>/^\s*Ontology\s*$/.test(x.textContent));if(b)b.click()}

/* ---------- link values in the other Semantic Layer tabs (authors, journals, publishers, countries, keywords) ---------- */
function linkify(scope){
  if(!scope||!D.querySelector('#modal.open'))return;
  const X=IX(),order=['journal','publisher','country','author'];let nTouched=0;
  scope.querySelectorAll('td,li').forEach(el=>{if(nTouched>900||el.dataset.sl||el.closest('#slx'))return;if(el.querySelector('a,button,input,select,svg,table'))return;
    const tx=(el.textContent||'').trim();if(tx.length<2||tx.length>150||/^[\d\s.,%–\-+/:()]+$/.test(tx))return;const k=norm(tx);let hit=null;
    for(const ty of order){const e=X.M[ty].get(k);if(e){hit=[ty,e];break}}
    if(!hit){const col=colHeader(el);if(/keyword|concept|topic|term|subject/i.test(col)){const e=X.M.concept.get(k);if(e)hit=['concept',e]}}
    if(!hit)return;el.dataset.sl='1';nTouched++;const a=D.createElement('a');a.href='#';a.className='slx-link';a.dataset.slt=hit[0];a.dataset.slk=hit[1].k;a.title='Open '+TY[hit[0]].s+' page';a.textContent=el.textContent;el.textContent='';el.appendChild(a)})}
function colHeader(td){if(td.tagName!=='TD')return'';const tr=td.parentElement,tb=tr&&tr.closest('table');if(!tb)return'';const i=[...tr.children].indexOf(td),h=tb.querySelector('tr');return h&&h.children[i]?h.children[i].textContent:''}

/* ---------- observer ---------- */
let t0=0,busy=false;
function scan(){
  if(busy)return;const host=D.getElementById('x3b');if(!host||!D.querySelector('#modal.open'))return;
  const svg=host.querySelector(':scope > svg');
  busy=true;try{
    if(svg&&/dcterms:creator/.test(svg.textContent)&&!svg.dataset.sl){mount(host,svg)}
    else if(!host.querySelector('#slx')){const tab=(QA('#modalCard .tabs button.on')[0]||{}).textContent||'';if(/Productivity|Impact|Performance|Semantic search/i.test(tab))linkify(host)}
    else if(root&&root.isConnected){host.querySelectorAll('table td:not([data-sl])').forEach(td=>{const t=BYNAME[td.textContent.trim().toLowerCase()];if(t&&!td.closest('#slx')){td.dataset.sl='1';td.innerHTML=`<a href="#" class="slx-link" data-slc="${t}">${esc(td.textContent.trim())}</a>`}})}
  }catch(e){console.warn('semantic-links',e)}finally{busy=false;if(mo)mo.takeRecords()}}
let mo=null;
function start(){const tgt=D.getElementById('modalBody')||D.body;mo=new MutationObserver(()=>{clearTimeout(t0);t0=setTimeout(scan,120)});mo.observe(tgt,{childList:true,subtree:true})}
const _cm=window.closeModal;if(typeof _cm==='function')window.closeModal=function(){try{if(G){G.destroy();G=null}if(location.hash.startsWith('#sl/'))history.replaceState(null,'',location.pathname+location.search)}catch(e){}root=null;return _cm.apply(this,arguments)};
start();
/* deep links: …#sl/ent/author/<key> opens the Semantic Layer on that page */
function openFromHash(){const v=parseHash(location.hash);if(!v)return;const tryOpen=()=>{if(typeof R==='undefined'||!R||!R.length||typeof openSemanticLayer!=='function'){setTimeout(tryOpen,300);return}pending=v;openSemanticLayer()};tryOpen()}
addEventListener('hashchange',()=>{if(location.hash.startsWith('#sl/')&&!(root&&root.isConnected))openFromHash()});
if(location.hash.startsWith('#sl/'))openFromHash();
window.SemanticLinks={open:(t,k)=>{pending=k==null?{t:'dir',type:t}:{t:'ent',type:t,key:String(k)};if(root&&root.isConnected){go(pending);pending=null}else{if(!D.querySelector('#modal.open'))openSemanticLayer();else toOntology()}}};
})();

