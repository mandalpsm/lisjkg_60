
/* ===== Layout v6: sector placement, settled synchronously, collision-free, fitted with labels ===== */
const LAY6={rep:6000,soft:90,k:.012,damp:.86,grav:.01,spring:.006,collide:10,settle:400};
function kgTarget(e){return e.relation==='matched search'?145:(e.relation==='related paper'?115:88)}
function kgPhysicsStep(){
  const ns=KG.nodes,es=KG.edges,N=ns.length,P=LAY6;
  for(let i=0;i<N;i++){const a=ns[i];if(a.fixed)continue;let fx=0,fy=0;for(let j=0;j<N;j++){if(i===j)continue;const b=ns[j],dx=a.x-b.x,dy=a.y-b.y,d2=dx*dx+dy*dy+P.soft;const f=P.rep/d2;fx+=dx*f;fy+=dy*f}a.vx=(a.vx+fx*P.k)*P.damp;a.vy=(a.vy+fy*P.k)*P.damp}
  es.forEach(e=>{const a=e.a,b=e.b,dx=b.x-a.x,dy=b.y-a.y,d=Math.sqrt(dx*dx+dy*dy)||1;const f=(d-kgTarget(e))*P.spring,fx=dx/d*f,fy=dy/d*f;if(!a.fixed){a.vx+=fx;a.vy+=fy}if(!b.fixed){b.vx-=fx;b.vy-=fy}});
  for(let i=0;i<N;i++)for(let j=i+1;j<N;j++){const a=ns[i],b=ns[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,m=kgRadius(a)+kgRadius(b)+P.collide;if(d<m){const push=(m-d)/2*.5,ux=dx/d,uy=dy/d;if(!a.fixed){a.x-=ux*push;a.y-=uy*push}if(!b.fixed){b.x+=ux*push;b.y+=uy*push}}}
  ns.forEach(n=>{if(n.fixed)return;n.vx+=(0-n.x)*P.grav;n.vy+=(0-n.y)*P.grav;n.x+=n.vx;n.y+=n.vy});
  KG.steps=(KG.steps||0)+1;
}
function kgInitPositions(){
  const nodes=KG.nodes;if(!nodes.length)return;
  const idx=new Map();nodes.forEach((n,i)=>idx.set(n,i));
  const adj=nodes.map(()=>[]);
  KG.edges.forEach(e=>{const a=idx.get(e.a),b=idx.get(e.b);if(a!=null&&b!=null&&a!==b){adj[a].push(b);adj[b].push(a)}});
  const root=nodes.find(n=>n.type==='query'||n.root)||null;
  const papers=nodes.filter(n=>n.type==='paper');
  const ents=nodes.filter(n=>n.type!=='paper'&&n!==root);
  nodes.forEach(n=>{n.vx=0;n.vy=0});
  if(root){root.x=0;root.y=0;root.fixed=true}
  const P=Math.max(1,papers.length),r1=Math.max(120,P*17/(2*Math.PI)),R0=r1+110,gap=60;
  const byType=new Map();ents.forEach(n=>{if(!byType.has(n.type))byType.set(n.type,[]);byType.get(n.type).push(n)});
  const types=[...byType.keys()].sort(),total=Math.max(1,ents.length),rings=ents.length>90?3:ents.length>30?2:1;
  const placePapers=order=>order.forEach((n,k)=>{const a=-Math.PI/2+2*Math.PI*k/P;n.x=r1*Math.cos(a);n.y=r1*Math.sin(a);n.ang=a});
  const bary=n=>{const ps=adj[idx.get(n)].map(j=>nodes[j]).filter(m=>m.ang!==undefined);if(!ps.length)return 0;return Math.atan2(ps.reduce((s,m)=>s+Math.sin(m.ang),0),ps.reduce((s,m)=>s+Math.cos(m.ang),0))};
  const placeEnts=()=>{let start=-Math.PI/2;types.forEach(t=>{const list=byType.get(t),span=2*Math.PI*list.length/total;list.sort((a,b)=>bary(a)-bary(b));
    list.forEach((n,k)=>{const a=start+span*(k+.5)/list.length,ring=R0+gap*(k%rings);n.x=ring*Math.cos(a);n.y=ring*Math.sin(a);n.ang=a});start+=span})};
  placePapers(papers);placeEnts();
  const key=new Map(papers.map(p=>[p,bary(p)]));
  placePapers([...papers].sort((a,b)=>key.get(a)-key.get(b)));placeEnts();
  // settle synchronously so the result does not depend on frame rate
  for(let s=0;s<LAY6.settle;s++)kgPhysicsStep();
  nodes.forEach(n=>{n.vx=0;n.vy=0});
  KG.steps=LAY6.settle;KG.alpha=0;
}
function kgStep(){kgPhysicsStep()}
function kgAnimate(){
  if(KG.settledFor!==KG.nodes&&!KG.drag){kgInitPositions();KG.settledFor=KG.nodes}
  if(KG.drag){kgPhysicsStep();kgDraw();KG.anim=requestAnimationFrame(kgAnimate);return}
  KG.anim=0;kgDraw();kgFit();
}
/* Labels are drawn in screen space at a fixed pixel size; crowded labels are skipped so the rest stay readable */
function kgDrawLabels(){
  const L=KG.__lbl||[];if(!L.length||!KG.ctx||!KG.canvas)return;
  const ctx=KG.ctx,dpr=Math.min(2,window.devicePixelRatio||1);
  ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.textAlign='center';ctx.textBaseline='alphabetic';
  const boxes=[];
  L.slice().sort((a,b)=>a.pri-b.pri).forEach(o=>{
    const sx=o.x*KG.scale+KG.tx,sy=o.y*KG.scale+KG.ty+o.r*KG.scale+15;
    ctx.font=(o.pri===0?'600 12px':'11px')+' system-ui, sans-serif';
    const w=ctx.measureText(o.l).width+8,x0=sx-w/2,y0=sy-11,h=15;
    if(boxes.some(b=>x0<b.x1&&x0+w>b.x0&&y0<b.y1&&y0+h>b.y0))return;
    boxes.push({x0,x1:x0+w,y0,y1:y0+h});
    ctx.fillStyle='rgba(255,255,255,.92)';ctx.fillRect(x0,y0,w,h);
    ctx.fillStyle=o.col;ctx.fillText(o.l,sx,sy);
  });
  ctx.restore();
}
function kgFit(){
  if(!KG.nodes.length||!KG.canvas)return;const rect=KG.canvas.getBoundingClientRect();if(rect.width<10||rect.height<10)return;
  let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
  KG.nodes.forEach(n=>{const r=kgRadius(n)+3,lw=Math.min(34,String(n.label||'').length)*3;x0=Math.min(x0,n.x-Math.max(r,lw));x1=Math.max(x1,n.x+Math.max(r,lw));y0=Math.min(y0,n.y-r);y1=Math.max(y1,n.y+r+16)});
  const pad=36,s=Math.min((rect.width-2*pad)/Math.max(1,x1-x0),(rect.height-2*pad)/Math.max(1,y1-y0));
  KG.scale=Math.max(.08,Math.min(s,1.6));
  KG.tx=rect.width/2-((x0+x1)/2)*KG.scale;KG.ty=rect.height/2-((y0+y1)/2)*KG.scale;
  kgDraw();
}
