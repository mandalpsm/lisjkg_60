
/* ===== Literature Review generator: recent references + in-text citations from search results (additive; existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const ls=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
const cfg=Object.assign({style:'apa',n:40,yf:'',yt:'',minc:0,org:'themes',len:'standard',rec:3,topic:'',src:'results',sf:false,s:{intro:1,method:1,trends:1,themes:1,methods:1,venues:1,gaps:1,future:1,recent:1,concl:1}},ls('lrCfg',{}));
const NUM={ieee:1,vancouver:1};
const REC=new Map();let SEQ=0,LAST=null,UNDO='';
const ST={num:new Map(),suf:new Map()};
const dec=s=>{const t=document.createElement('textarea');t.innerHTML=s||'';return t.value};
const plain=h=>{const d=document.createElement('div');d.innerHTML=h;return d.textContent};
const ttl=s=>s.replace(/\b[a-z]/g,c=>c.toUpperCase());
const med=a=>{a=[...a].sort((x,y)=>x-y);return a.length?a[a.length>>1]:0};

/* ---------- records ---------- */
const PART=/^(van|von|de|del|da|di|bin|al|el|le|la|der|den|dos|du)$/i;
function pname(s){s=s.trim().replace(/\s+/g,' ');if(!s)return null;let f,g='';
 if(s.includes(',')){const i=s.indexOf(',');f=s.slice(0,i).trim();g=s.slice(i+1).trim()}
 else{const p=s.split(' ');if(p.length<2)f=s;else if(cfg.sf){f=p[0];g=p.slice(1).join(' ')}else{let k=p.length-1;while(k>1&&PART.test(p[k-1]))k--;f=p.slice(k).join(' ');g=p.slice(0,k).join(' ')}}
 return{f,g,ini:g.split(/[\s.\-]+/).filter(Boolean).map(x=>x[0].toUpperCase())}}
function rec(id){const k=String(id);if(REC.has(k))return REC.get(k);let o;try{o=recObj(/^\d+$/.test(k)?+k:k)}catch(e){return null}
 if(!o||!o.title)return null;
 const r={k,n:++SEQ,au:(o.authors||'').split(';').map(pname).filter(Boolean),yr:parseInt(o.year)||0,ti:dec(o.title).replace(/\s+/g,' ').trim(),so:dec(o.source),doi:(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,''),url:o.url||'',kw:(o.keywords||'').split(/[;|]/).map(x=>dec(x).trim().toLowerCase()).filter(x=>x.length>2&&x.length<60),ab:dec(o.abstract),c:+o.cites||0};
 REC.set(k,r);return r}
function pool(){const sv=()=>[...savedSet()];let ids;
 if(cfg.src==='saved')ids=sv();else if(cfg.src==='both')ids=[...new Set([...(currentResults||[]).map(h=>h.i),...sv()])];else ids=(currentResults||[]).map(h=>h.i);
 return ids.map(rec).filter(Boolean).filter(r=>(!cfg.yf||r.yr>=+cfg.yf)&&(!cfg.yt||r.yr<=+cfg.yt)&&r.c>=(+cfg.minc||0)).slice(0,+cfg.n||40)}

/* ---------- citation styles ---------- */
function inText(r,m,st){const a=r.au;const au=!a.length?r.ti.split(' ').slice(0,3).join(' ')+'…':a.length===1?a[0].f:a.length===2?a[0].f+(m==='p'&&st==='apa'?' & ':' and ')+a[1].f:a[0].f+' et al.';
 const y=(r.yr||'n.d.')+(ST.suf.get(r.k)||'');
 if(st==='mla')return au;if(m==='n')return au+' ('+y+')';return st==='apa'||st==='harvard'?au+', '+y:au+' '+y}
function citeStr(keys,m,st){const rs=keys.map(rec).filter(Boolean);if(!rs.length)return '(?)';
 if(NUM[st]){const ns=keys.map(k=>ST.num.get(k)||'?'),b=st==='ieee'?'['+ns.join(', ')+']':'('+ns.join(', ')+')';
  return m==='n'?rs.map(r=>r.au[0]?r.au[0].f+(r.au.length>1?' et al.':''):'Ref.').join(', ')+' '+b:b}
 if(m==='n'){const t=rs.map(r=>inText(r,'n',st));return t.length===2?t.join(' and '):t.join(', ')}
 rs.sort((a,b)=>(a.au[0]?a.au[0].f:a.ti).localeCompare(b.au[0]?b.au[0].f:b.ti)||a.yr-b.yr);
 return '('+rs.map(r=>inText(r,'p',st)).join('; ')+')'}
function authList(r,st){const a=r.au;if(!a.length)return '';const ini=(x,sp,dot)=>x.ini.map(i=>i+(dot?'.':'')).join(sp?' ':'');
 const nm={apa:x=>x.f+', '+ini(x,1,1),harvard:x=>x.f+', '+ini(x,0,1),vancouver:x=>x.f+' '+ini(x,0,0),ieee:x=>ini(x,1,1)+' '+x.f,
  mla:(x,i)=>i?(x.g+' '+x.f).trim():x.f+(x.g?', '+x.g:''),chicago:(x,i)=>i?(x.g+' '+x.f).trim():x.f+(x.g?', '+x.g:'')}[st];
 let L=a.slice(),et=false;const lim={apa:20,harvard:6,mla:2,chicago:10,ieee:6,vancouver:6}[st];
 if(L.length>lim){L=L.slice(0,{mla:1,chicago:7,ieee:1,harvard:3,vancouver:6,apa:19}[st]);et=true}
 const s=L.map((x,i)=>nm(x,i));
 if(st==='vancouver')return s.join(', ')+(et?', et al':'');
 if(et)return s.join(', ')+(st==='apa'?', . . . '+nm(a[a.length-1],0):', et al.');
 if(s.length===1)return s[0];
 const sep={apa:', & ',mla:', and ',chicago:', and ',ieee:s.length>2?', and ':' and ',harvard:' and '}[st];
 return s.slice(0,-1).join(', ')+sep+s[s.length-1]}
function refHTML(r,st){const au=esc(authList(r,st)),ti=esc(r.ti),so=r.so?'<i>'+esc(r.so)+'</i>':'',y=(r.yr||'n.d.')+(ST.suf.get(r.k)||'');
 const lk=r.doi?'https://doi.org/'+r.doi:safeUrl(r.url),L=lk?`<a href="${esc(lk)}" target="_blank" rel="noopener">${esc(lk)}</a>`:'';
 const dot=s=>!s||/[.?!]$/.test(s)?s:s+'.';
 switch(st){
  case 'harvard':return `${au} (${y}) ‘${ti}’, ${so}${so?'.':''}${L?' Available at: '+L+'.':''}`;
  case 'mla':return `${dot(au)} “${dot(ti)}” ${so}${so?', ':''}${y}${L?', '+L:''}.`;
  case 'chicago':return `${dot(au)} ${y}. “${dot(ti)}” ${so}${so?'. ':''}${L}`;
  case 'ieee':return `${au?au+', ':''}“${ti},” ${so}${so?', ':''}${y}${r.doi?', doi: '+esc(r.doi):''}.`;
  case 'vancouver':return `${au?dot(au)+' ':''}${dot(ti)} ${esc(r.so)}${r.so?'. ':''}${y}.${r.doi?' doi:'+esc(r.doi):''}`;
  default:return `${dot(au)} (${y}). ${dot(ti)} ${so}${so?'. ':''}${L}`}}
const cs=(keys,m)=>`<span class="lr-cite" contenteditable="false" data-ids="${keys.join(',')}" data-m="${m}">${esc(citeStr(keys,m,cfg.style))}</span>`;

/* ---------- text analysis ---------- */
const STOP=new Set('a an and are as at be been by for from has have in into is it its of on or that the their this to was were which with within using use used based study studies paper research analysis review article approach results new role among between during through toward via than also can may such these those our we more most other some many one two three how what why when who not but if only both each about'.split(' '));
const tk=s=>(norm(s).match(/[a-z][a-z0-9+#-]{2,}/g)||[]).filter(w=>!STOP.has(w));
const stm=w=>w.replace(/ies$/,'y').replace(/([^s])s$/,'$1');
function themes(P,k){const df=new Map(),add=(t,i)=>{if(!df.has(t))df.set(t,new Set());df.get(t).add(i)};
 P.forEach((r,i)=>{r.kw.forEach(x=>{const t=tk(x).map(stm).join(' ');if(t)add(t,i)});const w=tk(r.ti).map(stm);w.forEach(x=>x.length>3&&add(x,i));for(let j=0;j<w.length-1;j++)add(w[j]+' '+w[j+1],i)});
 const min=Math.max(2,Math.ceil(P.length*.04)),max=P.length*.6,cand=[...df].filter(([t,s])=>s.size>=min&&s.size<=max),out=[],cov=new Set();
 while(out.length<k){let best=null,bs=0;cand.forEach(([t,s])=>{const tw=t.split(' ');if(out.some(o=>o.t.split(' ').some(w=>tw.includes(w))))return;const nw=[...s].filter(i=>!cov.has(i)).length,sc=nw*(tw.length>1?1.3:1);if(nw>=2&&sc>bs){bs=sc;best=[t,s]}});
  if(!best)break;out.push({t:best[0],set:best[1],ids:[]});best[1].forEach(i=>cov.add(i))}
 P.forEach((r,i)=>{const o=out.find(o=>o.set.has(i));if(o)o.ids.push(i)});
 const g=out.map(o=>({label:o.t,recs:o.ids.map(i=>P[i])})),rest=P.filter((r,i)=>!out.some(o=>o.set.has(i)));
 if(rest.length)g.push({label:'other perspectives',recs:rest});return g}
const sents=a=>(a||'').replace(/\s+/g,' ').replace(/\b(e\.g|i\.e|et al|vs|etc|Fig|Dr|No)\./g,'$1\u2024').replace(/([.!?])\s+(?=[A-Z("“])/g,'$1\u0001').split('\u0001').map(s=>s.replace(/\u2024/g,'.').trim()).filter(s=>s.length>35);
const CUE=/\b(aim|purpose|objective|examin|investigat|explor|analy[sz]|found|finding|result|reveal|show|conclu|propos|develop|identif|assess|evaluat|demonstrat|highlight|suggest|indicat)/i,BAD=/(copyright|©|keywords?:|http|published by|all rights|received:|doi:)/i;
const cut=s=>{s=s.replace(/[.]+$/,'');return s.length>260?s.slice(0,s.lastIndexOf(' ',250))+'…':s};
function pick(r,terms,n){const S=sents(r.ab);if(!S.length)return[];
 return S.map((s,i)=>[(CUE.test(s)?2:0)+(i<2?1:0)+tk(s).filter(w=>terms.has(stm(w))).length*.5-(s.length>300?3:0)-(s.length<60?1:0)-(BAD.test(s)?6:0),i,s]).sort((a,b)=>b[0]-a[0]).slice(0,n).filter(x=>x[0]>-1).sort((a,b)=>a[1]-b[1]).map(x=>cut(x[2]))}
const VERB=/^(?:in\s+(?:this|the present|the current)\s+\w+,?\s+)?(?:this|the present|the current|the)\s+(?:study|paper|article|research|work|chapter|review|investigation|report|survey|analysis|case study)\s+(?:also\s+|further\s+)?([a-z]+)\s+(.*)$/i;
const SKIP=new Set('is was has are were have had will can may would could'.split(' ')),COM=new Set('the a an in on at as with for from by it its this these those there their they many most some several such despite although while when because since using through during given however due recent recently'.split(' '));
const conj=(v,pl)=>{v=v.toLowerCase();if(!pl||!/s$/.test(v)||/ss$/.test(v)||v.length<4)return v;if(/ies$/.test(v))return v.slice(0,-3)+'y';if(/(sses|shes|ches|xes|zzes)$/.test(v))return v.slice(0,-2);return v.slice(0,-1)};
const third=x=>/([sxz]|ch|sh)$/.test(x)?x+'es':/[^aeiou]y$/.test(x)?x.slice(0,-1)+'ies':x+'s';
const lc=s=>COM.has(s.split(/\s/)[0].toLowerCase())?s[0].toLowerCase()+s.slice(1):s;
let ALT=0;
function say(r,s){const pl=r.au.length>1,nar=cs([r.k],'n'),t=s.replace(/[.]+$/,''),v=t.match(VERB);
 if(v&&!SKIP.has(v[1].toLowerCase())&&/(s|ed)$/.test(v[1]))return `${nar} ${conj(v[1],pl)} ${esc(v[2])}.`;
 const w=t.match(/^we\s+(?:also\s+)?([a-z]+)\s+(.*)$/i);if(w&&!SKIP.has(w[1].toLowerCase())&&!/(s|ed)$/.test(w[1]))return `${nar} ${pl?w[1]:third(w[1])} ${esc(w[2])}.`;
 return ALT++%2?`${nar} ${pl?'note':'notes'} that ${esc(lc(t))}.`:`According to ${nar}, ${esc(lc(t))}.`}
const METH=[['bibliometric or scientometric analysis',/bibliometric|scientometric|citation analysis|vosviewer|biblioshiny/i],['systematic, scoping or literature reviews',/systematic (literature )?review|literature review|scoping review|meta-analysis|prisma/i],['surveys and questionnaires',/survey|questionnaire/i],['interviews and focus groups',/interview|focus group/i],['case studies',/case stud/i],['content or thematic analysis',/content analysis|thematic analysis|text analysis/i],['machine learning and AI techniques',/machine learning|deep learning|neural|natural language|\bnlp\b|large language|chatgpt|generative/i],['experimental designs',/experiment|quasi-experiment|randomi[sz]ed/i],['mixed-methods designs',/mixed[- ]method/i],['conceptual or framework-building work',/conceptual|framework/i]];
const GAPRE=/\b(limited|lack(?:s|ing)?|scarce|understudied|under-?explored|gap|little (?:is known|attention)|remains? (?:unclear|unexplored|limited)|not (?:yet )?(?:fully|well|adequately))\b/i,FUTRE=/\b(further (?:research|studies|investigation)|future (?:research|studies|work|directions)|should (?:be|focus)|needs? to be|recommend)/i;
const join=a=>a.length<2?a.join(''):a.slice(0,-1).join(', ')+' and '+a[a.length-1];
const top=(a,n)=>{const m=new Map();a.forEach(x=>m.set(x,(m.get(x)||0)+1));return[...m].sort((x,y)=>y[1]-x[1]).slice(0,n)};

/* ---------- generator ---------- */
function generate(){const P=pool();if(!P.length)return null;
 const per={concise:2,standard:4,detailed:7}[cfg.len]||4,spn=cfg.len==='detailed'?2:1,S=cfg.s,T=cfg.topic||(state&&state.query)||'the selected research area';
 const ys=P.map(r=>r.yr).filter(Boolean),y1=Math.min(...ys),y2=Math.max(...ys),byc=[...P].sort((a,b)=>b.c-a.c);
 const terms=new Set(tk(T).map(stm));let h=`<h1>Literature Review: ${esc(ttl(T))}</h1><p class="lr-meta">Compiled ${new Date().toLocaleDateString()} from ${P.length} records (${y1}–${y2}) · citation style: ${esc(cfg.style.toUpperCase())}</p>`;
 const kws=top(P.flatMap(r=>r.kw),8),srcs=top(P.map(r=>r.so).filter(Boolean),5),aus=top(P.flatMap(r=>r.au.map(a=>a.f+', '+a.ini.join(''))),6).filter(x=>x[1]>1);
 if(S.intro)h+=`<h2>1. Introduction</h2><p>This review synthesises ${P.length} publications on <b>${esc(T)}</b> published between ${y1} and ${y2} in ${new Set(P.map(r=>r.so)).size} journals or sources. Together they have been cited ${P.reduce((a,r)=>a+r.c,0).toLocaleString()} times in the dataset (median ${med(P.map(r=>r.c))} per paper).</p>`+
  (byc[0].c?`<p>The most cited contribution is ${cs([byc[0].k],'n')} (${byc[0].c} citations)${byc[1]&&byc[1].c?`, followed by ${cs([byc[1].k],'n')} (${byc[1].c} citations)`:''}. `:'<p>')+(kws.length?`The most frequent author keywords are ${esc(join(kws.map(k=>`${k[0]} (${k[1]})`)))}.`:'')+'</p>';
 if(S.method)h+=`<h2>2. Review method</h2><ul><li>Source: the bibliographic collection loaded in this application; query: ${state&&state.query?'“'+esc(state.query)+'”':'none (records chosen from '+(cfg.src==='saved'?'saved items':'the collection')+')'}.</li><li>Sample: top ${P.length} records${cfg.yf||cfg.yt?` published ${cfg.yf||'…'}–${cfg.yt||'…'}`:''}${+cfg.minc?` with at least ${cfg.minc} citations`:''}.</li><li>Synthesis: keyword-based thematic grouping and attributed abstract sentences. Statements are taken from titles, keywords and abstracts only, not full texts, and should be verified against the sources before submission.</li></ul>`;
 if(S.trends){const yc=top(P.map(r=>r.yr).filter(Boolean),99).sort((a,b)=>a[0]-b[0]),pk=[...yc].sort((a,b)=>b[1]-a[1])[0],old=[...P].filter(r=>r.yr).sort((a,b)=>a.yr-b.yr||b.c-a.c)[0],nw=[...P].filter(r=>r.yr).sort((a,b)=>b.yr-a.yr||b.c-a.c)[0];
  h+=`<h2>3. Publication trends</h2><p>Output peaks in ${pk[0]} with ${pk[1]} records. The earliest paper in the sample is ${cs([old.k],'n')} and the most recent is ${cs([nw.k],'n')}.</p><table><tr><th>Year</th><th>Records</th><th>Mean citations</th></tr>${yc.map(([y,c])=>`<tr><td>${y}</td><td>${c}</td><td>${(P.filter(r=>r.yr===y).reduce((a,r)=>a+r.c,0)/c).toFixed(1)}</td></tr>`).join('')}</table>`}
 if(S.themes){const chrono=cfg.org==='chrono';let G;
  if(chrono)G=[...new Set(P.map(r=>r.yr))].sort((a,b)=>a-b).map(y=>({label:String(y||'n.d.'),recs:P.filter(r=>r.yr===y)}));else G=themes(P,5);
  h+=`<h2>4. ${chrono?'Chronological':'Thematic'} synthesis</h2>`;
  G.forEach(g=>{const rs=[...g.recs].sort((a,b)=>b.c-a.c||b.yr-a.yr),main=rs.slice(0,per),rest=rs.slice(per),pc=Math.round(g.recs.length/P.length*100);
   h+=`<h3>${esc(ttl(g.label))}</h3><p>${chrono?`In ${esc(g.label)}, ${g.recs.length} of the ${P.length} studies (${pc}%) were published.`:`${g.recs.length} of the ${P.length} studies (${pc}%) ${g.label==='other perspectives'?'address other perspectives':'concern <b>'+esc(g.label)+'</b>'}.`}`;
   const gt=new Set([...terms,...g.label.split(' ')]);
   main.forEach(r=>{const p=pick(r,gt,spn);h+=' '+(p.length?p.map(s=>say(r,s)).join(' '):`${cs([r.k],'n')} address “${esc(r.ti)}”.`)});
   const co=top(g.recs.flatMap(r=>r.kw).filter(k=>!g.label.split(' ').some(w=>k.includes(w))),4);
   h+=(co.length&&!chrono?` Frequently co-occurring terms are ${esc(join(co.map(c=>c[0])))}.`:'')+'</p>';
   if(rest.length)h+=`<p>Further work in this group includes ${cs(rest.slice(0,6).map(r=>r.k),'p')}.</p>`})}
 if(S.methods){const mm=METH.map(([l,re])=>[l,P.filter(r=>re.test(r.ti+' '+r.ab))]).filter(x=>x[1].length).sort((a,b)=>b[1].length-a[1].length).slice(0,6);
  if(mm.length)h+=`<h2>5. Research methods and approaches</h2><ul>${mm.map(([l,a])=>`<li><b>${esc(ttl(l))}</b>: ${a.length} studies (e.g. ${cs(a.sort((x,y)=>y.c-x.c).slice(0,3).map(r=>r.k),'p')}).</li>`).join('')}</ul>`}
 if(S.venues)h+=`<h2>6. Key venues and contributors</h2><p>${srcs.length?`The sources contributing most records are ${esc(join(srcs.map(s=>`${s[0]} (${s[1]})`)))}. `:''}${aus.length?`The most frequently appearing authors are ${esc(join(aus.map(a=>`${a[0]} (${a[1]} papers)`)))}.`:'No author appears more than once in this sample.'}</p>`;
 if(S.gaps||S.future){const gp=[],fu=[];[...P].sort((a,b)=>b.yr-a.yr).forEach(r=>{const ss=sents(r.ab).filter(s=>!BAD.test(s));const g=ss.find(s=>GAPRE.test(s)),f=ss.find(s=>FUTRE.test(s));if(g&&gp.length<4)gp.push([r,cut(g)]);if(f&&fu.length<4)fu.push([r,cut(f)])});
  if(S.gaps){const T5=themes(P,5).filter(g=>g.label!=='other perspectives').map(g=>g.label),has=(r,l)=>{r._t=r._t||new Set(tk(r.ti+' '+r.kw.join(' ')+' '+r.ab).map(stm));return l.split(' ').every(w=>r._t.has(w))},pairs=[];
   for(let i=0;i<T5.length;i++)for(let j=i+1;j<T5.length;j++){const m=P.filter(r=>has(r,T5[i])&&has(r,T5[j]));if(m.length<2)pairs.push([T5[i],T5[j],m])}
   h+=`<h2>7. Critical discussion and research gaps</h2>`+(gp.length?`<p>Several authors state limitations or gaps explicitly. ${gp.map(([r,s])=>`${cs([r.k],'n')} ${r.au.length>1?'observe':'observes'} that ${esc(lc(s))}.`).join(' ')}</p>`:'')+
    (pairs.length?`<p>Conceptually, the sample shows thin coverage of combinations of themes: ${pairs.slice(0,3).map(([a,b,m])=>m.length?`only one study (${cs([m[0].k],'n')}) jointly addresses ${esc(a)} and ${esc(b)}`:`no study in this sample jointly addresses ${esc(a)} and ${esc(b)}`).join('; ')}.</p>`:'')+(gp.length||pairs.length?'':'<p>No explicit gap statements were detected in the abstracts of this sample.</p>')}
  if(S.future){const rc=P.filter(r=>r.yr>=y2-1),em=top(rc.flatMap(r=>r.kw),30).filter(([k,c])=>c>=2&&P.filter(r=>r.kw.includes(k)).every(r=>r.yr>=y2-1)).slice(0,4);
   h+=`<h2>8. Future research directions</h2>`+(fu.length?`<p>${fu.map(([r,s])=>`${cs([r.k],'n')} ${r.au.length>1?'suggest':'suggests'} that ${esc(lc(s))}.`).join(' ')}</p>`:'')+(em.length?`<p>Terms appearing only in the most recent two years, and therefore emerging, include ${esc(join(em.map(e=>e[0])))}.</p>`:'')+(fu.length||em.length?'':'<p>No explicit future-research statements were detected in this sample.</p>')}}
 if(S.recent){const from=y2-(+cfg.rec||3)+1,rc=P.filter(r=>r.yr>=from).sort((a,b)=>b.yr-a.yr||b.c-a.c).slice(0,{concise:5,standard:8,detailed:12}[cfg.len]||8);
  if(rc.length)h+=`<h2>9. Recent developments (${from}–${y2})</h2><p>${P.filter(r=>r.yr>=from).length} of the ${P.length} studies (${Math.round(P.filter(r=>r.yr>=from).length/P.length*100)}%) appeared in the last ${cfg.rec} years of the sample.</p><ul>${rc.map(r=>{const p=pick(r,terms,1);return `<li>${p.length?say(r,p[0]):`${cs([r.k],'n')} address “${esc(r.ti)}”.`}</li>`}).join('')}</ul>`}
 if(S.concl){const g=themes(P,3).filter(x=>x.label!=='other perspectives');h+=`<h2>10. Conclusion</h2><p>The ${P.length} reviewed studies show ${g.length?`concentration around ${esc(join(g.map(x=>x.label)))}`:'a diverse set of concerns'}, with ${y2-y1+1>1?`output spread across ${y1}–${y2}`:'all output in '+y1}. This draft is assembled from metadata and abstracts; check each claim against the full text, refine the synthesis in your own words and confirm the reference list before submission.</p>`}
 return h+`<h2>References</h2><div id="lr-refs" contenteditable="false"></div>`}

/* ---------- document, refresh, persistence ---------- */
const D=()=>Q('#lrDoc');
const skel='<h1>Literature review</h1><p><br></p><h2>References</h2><div id="lr-refs" contenteditable="false"></div>';
function refresh(){const d=D();if(!d)return;const sp=[...d.querySelectorAll('.lr-cite')],keys=[];
 sp.forEach(s=>s.dataset.ids.split(',').forEach(k=>{if(!keys.includes(k))keys.push(k)}));
 ST.num=new Map(keys.map((k,i)=>[k,i+1]));ST.suf=new Map();const g={};
 keys.forEach(k=>{const r=rec(k);if(r)(g[(r.au[0]?r.au[0].f:r.ti)+'|'+r.au.length+'|'+r.yr]=g[(r.au[0]?r.au[0].f:r.ti)+'|'+r.au.length+'|'+r.yr]||[]).push(r)});
 Object.values(g).forEach(a=>{if(a.length>1)a.sort((x,y)=>x.ti.localeCompare(y.ti)).forEach((r,i)=>ST.suf.set(r.k,String.fromCharCode(97+i)))});
 sp.forEach(s=>{const t=citeStr(s.dataset.ids.split(','),s.dataset.m,cfg.style);if(s.textContent!==t)s.textContent=t});
 const rs=keys.map(rec).filter(Boolean);if(!NUM[cfg.style])rs.sort((a,b)=>(a.au[0]?a.au[0].f:a.ti).localeCompare(b.au[0]?b.au[0].f:b.ti)||a.yr-b.yr||a.ti.localeCompare(b.ti));
 const RF=d.querySelector('#lr-refs');
 if(RF)RF.innerHTML=rs.map(r=>`<div class="lr-ref${NUM[cfg.style]?' num':''}" id="lr-ref-${r.n}">${NUM[cfg.style]?`<span class="lr-n">${cfg.style==='ieee'?'['+ST.num.get(r.k)+']':ST.num.get(r.k)+'.'}</span> `:''}${refHTML(r,cfg.style)}</div>`).join('')||'<p class="tiny">No citations yet. Use “Cite from results”.</p>';
 stats(keys,sp);save(keys)}
function stats(keys,sp){const e=Q('#lrStats');if(!e)return;const d=D(),c=d.cloneNode(true);c.querySelector('#lr-refs')?.remove();const w=(c.textContent.match(/\S+/g)||[]).length,P=pool();
 e.innerHTML=`<b>${w}</b> words · <b>${sp.length}</b> in-text citations · <b>${keys.length}</b> references · <b>${P.filter(r=>!keys.includes(r.k)).length}</b> of ${P.length} source records not yet cited`}
function save(keys){const d=D();if(!d)return;const recs={};keys.forEach(k=>{const r=REC.get(k);if(r)recs[k]={...r,ab:''}});try{localStorage.setItem('lrAuto',JSON.stringify({html:d.innerHTML,recs}));localStorage.setItem('lrCfg',JSON.stringify(cfg))}catch(e){}}
function load(){const a=ls('lrAuto',null);if(!a||!a.html)return skel;Object.entries(a.recs||{}).forEach(([k,r])=>{if(!REC.has(k))REC.set(k,{...r,n:++SEQ,ab:r.ab||''})});return a.html}
function ins(keys,m){const d=D();if(!d)return;const t=document.createElement('span');t.className='lr-cite';t.contentEditable='false';t.dataset.ids=keys.join(',');t.dataset.m=m;t.textContent='…';
 if(LAST&&d.contains(LAST.commonAncestorContainer)&&!LAST.commonAncestorContainer.parentElement?.closest('#lr-refs')){const r=LAST.cloneRange();r.collapse(false);r.insertNode(t);t.after(document.createTextNode(' '));LAST=null}
 else{const p=[...d.querySelectorAll('p')].filter(p=>!p.closest('#lr-refs')).pop();if(p){p.append(document.createTextNode(' '),t)}else d.insertBefore(t,d.querySelector('#lr-refs'))}
 refresh();toast('Citation inserted in the review')}
const copyRich=(html,text)=>{try{navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([html],{type:'text/html'}),'text/plain':new Blob([text],{type:'text/plain'})})]).then(()=>toast('Copied'),()=>navigator.clipboard.writeText(text).then(()=>toast('Copied text')))}catch(e){navigator.clipboard&&navigator.clipboard.writeText(text).then(()=>toast('Copied text'))}};
const outHTML=()=>{refresh();const c=D().cloneNode(true);c.querySelectorAll('[contenteditable]').forEach(e=>e.removeAttribute('contenteditable'));return c.innerHTML};
const wrap=b=>`<!doctype html><html><head><meta charset="utf-8"><title>Literature review</title><style>body{font:12pt/1.55 "Times New Roman",serif;max-width:780px;margin:2em auto;color:#111}h1{font-size:20pt}h2{font-size:15pt;margin-top:1.2em}h3{font-size:12.5pt}.lr-ref{margin:0 0 6pt 24pt;text-indent:-24pt}.lr-meta{color:#555;font-style:italic}table{border-collapse:collapse}td,th{border:1px solid #999;padding:3px 8px}</style></head><body>${b}</body></html>`;
function printDoc(){const f=document.createElement('iframe');f.style.cssText='position:fixed;width:0;height:0;border:0';document.body.appendChild(f);f.srcdoc=wrap(outHTML());f.onload=()=>{f.contentWindow.focus();f.contentWindow.print();setTimeout(()=>f.remove(),2000)}}

/* ---------- citation matching (tf-idf cosine) ---------- */
function index(P){const N=P.length,df=new Map(),V=P.map(r=>{const tf=new Map(),add=(s,w)=>tk(s).map(stm).forEach(t=>tf.set(t,(tf.get(t)||0)+w));add(r.ti,3);add(r.kw.join(' '),2);add(r.ab,1);tf.forEach((v,t)=>df.set(t,(df.get(t)||0)+1));return tf});
 const idf=t=>Math.log(1+N/(df.get(t)||N)),vec=tf=>{const v=new Map();let n=0;tf.forEach((c,t)=>{const w=(1+Math.log(c))*idf(t);v.set(t,w);n+=w*w});return{v,n:Math.sqrt(n)||1}},DV=V.map(vec);
 return{match(text,k){const q=new Map();tk(text).map(stm).forEach(t=>q.set(t,(q.get(t)||0)+1));const qv=vec(q);return DV.map((d,i)=>{let s=0;qv.v.forEach((w,t)=>{if(d.v.has(t))s+=w*d.v.get(t)});return[s/(qv.n*d.n),P[i]]}).sort((a,b)=>b[0]-a[0]).slice(0,k)}}}
const THR=()=>+(Q('#lrThr')?.value||.1);
function suggest(text){const P=pool(),ix=index(P);return sents(text.replace(/\n+/g,' ')).map(s=>({s,m:ix.match(s,3)}))}
function autoCite(){const d=D(),P=pool();if(!P.length)return toast('No source records in scope');UNDO=d.innerHTML;const ix=index(P);let n=0;
 d.querySelectorAll('p,li').forEach(p=>{if(p.closest('#lr-refs')||p.querySelector('.lr-cite')||p.classList.contains('lr-meta'))return;const t=p.textContent.trim();if(t.split(/\s+/).length<8)return;
  const m=ix.match(t,1)[0];if(m&&m[0]>=THR()){const sp=document.createElement('span');sp.className='lr-cite';sp.contentEditable='false';sp.dataset.ids=m[1].k;sp.dataset.m='p';sp.textContent='…';
   const last=[...p.childNodes].reverse().find(x=>x.nodeType===3&&x.textContent.trim());if(last&&/[.!?]\s*$/.test(last.textContent)){const i=last.textContent.search(/[.!?]\s*$/);last.splitText(i);last.after(document.createTextNode(' '),sp)}else p.append(' ',sp);n++}});
 refresh();toast(n?`Added ${n} citations (use Undo to revert)`:'No uncited paragraph reached the match threshold')}

/* ---------- UI ---------- */
const row=(r,extra)=>`<div class="lr-item"><input type="checkbox" data-k="${esc(r.k)}"><div><b>${esc(r.ti)}</b><div class="tiny">${esc(r.au.map(a=>a.f).slice(0,4).join(', '))}${r.au.length>4?' et al.':''} · ${r.yr||'n.d.'} · ${esc(r.so)} · ${r.c} citations</div>${extra||''}</div><div class="lr-acts"><button class="ghost" data-act="cp" data-k="${esc(r.k)}">( ) cite</button><button class="ghost" data-act="cn" data-k="${esc(r.k)}">Narrative</button></div></div>`;
const sel=()=>QA('#lrRoot [data-k]:checked').map(c=>c.dataset.k);
function recentList(){const P=pool(),y2=Math.max(0,...P.map(r=>r.yr)),w=+(Q('#lrRecW')?.value||cfg.rec),sort=Q('#lrRecS')?.value||'year',f=norm(Q('#lrRecQ')?.value||'');
 let a=P.filter(r=>!w||r.yr>y2-w).filter(r=>!f||norm(r.ti+' '+r.au.map(x=>x.f).join(' ')+' '+r.kw.join(' ')).includes(f));
 a.sort((x,y)=>sort==='cites'?y.c-x.c:sort==='title'?x.ti.localeCompare(y.ti):y.yr-x.yr||y.c-x.c);return a}
function drawRecent(){const a=recentList(),e=Q('#lrRecL');if(e)e.innerHTML=a.length?a.map(r=>row(r,`<div class="lr-ref-p">${refHTML(r,cfg.style)}</div>`)).join(''):'<p class="tiny">No records in this window. Run a search or widen the source filters.</p>';Q('#lrRecN').textContent=a.length+' recent records'}
function drawCite(){const f=norm(Q('#lrCQ')?.value||''),a=pool().filter(r=>!f||norm(r.ti+' '+r.au.map(x=>x.f).join(' ')+' '+r.kw.join(' ')).includes(f)).slice(0,60);Q('#lrCL').innerHTML=a.map(r=>row(r,`<div class="tiny">(${esc(inText(r,'p',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))}) · ${esc(inText(r,'n',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))}</div>`)).join('')||'<p class="tiny">No matching records in scope.</p>'}
function drawBib(){const m=Q('#lrBibM').value,P=pool(),y2=Math.max(0,...P.map(r=>r.yr));let a;
 if(m==='cited'){refresh();a=[...new Set(QA('#lrDoc .lr-cite').flatMap(s=>s.dataset.ids.split(',')))].map(rec).filter(Boolean)}else if(m==='recent')a=P.filter(r=>r.yr>y2-cfg.rec);else a=P;
 a=[...a].sort((x,y)=>(x.au[0]?x.au[0].f:x.ti).localeCompare(y.au[0]?y.au[0].f:y.ti)||x.yr-y.yr);Q('#lrBibL').innerHTML=a.map(r=>`<div class="lr-ref">${refHTML(r,cfg.style)}</div>`).join('')||'<p class="tiny">Nothing to list.</p>';Q('#lrBibL').dataset.k=a.map(r=>r.k).join('|~|')}
const bibRecs=()=>(Q('#lrBibL').dataset.k||'').split('|~|').filter(Boolean).map(k=>/^\d+$/.test(k)?+k:k);
function poolInfo(){const P=pool(),e=Q('#lrPool');if(!e)return;const ys=P.map(r=>r.yr).filter(Boolean);e.innerHTML=P.length?`<b>${P.length}</b> records in scope (${Math.min(...ys)}–${Math.max(...ys)})`:'<span class="bad">No records in scope — run a search (or type a topic and press “Search topic”).</span>'}

function open(){Q('#modalCard').classList.add('x2-wide');
 const o=(v,l,c)=>`<option value="${v}"${c==v?' selected':''}>${l}</option>`,S=cfg.s;
 showModal(`<div class="x3 lr" id="lrRoot"><h2>📚 Literature Review Generator</h2>
 <div class="row"><label>Topic <input type="text" id="lrTopic" size="30" placeholder="${esc((state&&state.query)||'research topic')}" value="${esc(cfg.topic)}"></label><button class="ghost" id="lrSearch">⌕ Search topic</button>
 <label>Source <select id="lrSrc">${o('results','Current search results',cfg.src)}${o('saved','Saved records',cfg.src)}${o('both','Results + saved',cfg.src)}</select></label>
 <label>Top <input type="number" id="lrN" min="5" max="300" value="${cfg.n}" style="width:70px"></label><label>Years <input type="number" id="lrYF" placeholder="from" value="${cfg.yf}" style="width:70px">–<input type="number" id="lrYT" placeholder="to" value="${cfg.yt}" style="width:70px"></label><label>Min citations <input type="number" id="lrMC" min="0" value="${cfg.minc}" style="width:60px"></label>
 <label>Style <select id="lrStyle">${[['apa','APA 7'],['harvard','Harvard'],['mla','MLA'],['chicago','Chicago (author-date)'],['ieee','IEEE (numeric)'],['vancouver','Vancouver (numeric)']].map(([v,l])=>o(v,l,cfg.style)).join('')}</select></label></div>
 <div class="tiny" id="lrPool"></div>
 <div class="tabs"><button data-p="gen">Generate &amp; edit</button><button data-p="rec">Recent references</button><button data-p="cite">In-text citations</button><button data-p="bib">Bibliography &amp; export</button></div>
 <section data-pane="gen"><div class="row"><label>Organise by <select id="lrOrg">${o('themes','Themes',cfg.org)}${o('chrono','Chronology',cfg.org)}</select></label><label>Length <select id="lrLen">${o('concise','Concise',cfg.len)}${o('standard','Standard',cfg.len)}${o('detailed','Detailed',cfg.len)}</select></label><label>Recent window <select id="lrRec">${[1,2,3,5].map(v=>o(v,'last '+v+' yr',cfg.rec)).join('')}</select></label>
 <details><summary>Sections</summary>${[['intro','Introduction'],['method','Review method'],['trends','Trends'],['themes','Synthesis'],['methods','Methods'],['venues','Venues &amp; authors'],['gaps','Gaps'],['future','Future work'],['recent','Recent developments'],['concl','Conclusion']].map(([k,l])=>`<label class="lr-chk"><input type="checkbox" data-sec="${k}"${S[k]?' checked':''}> ${l}</label>`).join('')}</details>
 <button class="primary" id="lrGen">✦ Generate review</button></div>
 <div class="row lr-tools"><button class="ghost" data-cmd="bold"><b>B</b></button><button class="ghost" data-cmd="italic"><i>I</i></button><button class="ghost" data-cmd="formatBlock" data-v="h2">H2</button><button class="ghost" data-cmd="formatBlock" data-v="p">¶</button><button class="ghost" data-cmd="undo">↶</button><button class="ghost" data-cmd="redo">↷</button><button class="ghost" id="lrRef">↻ Refresh citations</button><span class="lr-sp"></span>
 <button class="ghost" id="lrCopy">Copy</button><button class="ghost" id="lrDoc2">Word (.doc)</button><button class="ghost" id="lrHtml">HTML</button><button class="ghost" id="lrTxt">Text</button><button class="ghost" id="lrPrint">Print / PDF</button></div>
 <div id="lrStats" class="tiny"></div><div id="lrDoc" class="lr-doc" contenteditable="true" spellcheck="true"></div></section>
 <section data-pane="rec" hidden><div class="row"><label>Window <select id="lrRecW">${[[1,'last year'],[2,'last 2 years'],[3,'last 3 years'],[5,'last 5 years'],[0,'all years']].map(([v,l])=>o(v,l,cfg.rec)).join('')}</select></label><label>Sort <select id="lrRecS">${o('year','Newest first','year')}${o('cites','Most cited','')}${o('title','Title','')}</select></label><input type="text" id="lrRecQ" placeholder="filter by title, author, keyword" size="28"><span class="tiny" id="lrRecN"></span></div>
 <div class="row"><button class="ghost" id="lrRecAll">Select all</button><button class="primary" id="lrRecIns">Insert selected citation(s) in review</button><button class="ghost" id="lrRecPara">Add “Recent literature” paragraph</button><button class="ghost" id="lrRecCopy">Copy selected references</button></div><div id="lrRecL"></div></section>
 <section data-pane="cite" hidden><div class="row"><input type="text" id="lrCQ" placeholder="find a record to cite (title, author, keyword)" size="40"><button class="primary" id="lrCIns">Insert selected as one citation</button></div><div id="lrCL" class="lr-scroll"></div>
 <div class="card"><b>Suggest citations for text</b><div class="tiny">Paste a claim or paragraph; the best-matching records from the source scope are proposed for each sentence (tf-idf similarity on title, keywords and abstract).</div><textarea id="lrSugIn" rows="4" placeholder="Paste text here…"></textarea>
 <div class="row"><label>Match strictness <select id="lrThr"><option value=".06">Low</option><option value=".1" selected>Medium</option><option value=".18">High</option></select></label><button class="primary" id="lrSug">Suggest</button><button class="ghost" id="lrSugEd">Use review text</button><button class="primary" id="lrAuto">Auto-cite uncited paragraphs in review</button><button class="ghost" id="lrUndo">Undo auto-cite</button></div><div id="lrSugOut"></div></div></section>
 <section data-pane="bib" hidden><div class="row"><label>List <select id="lrBibM">${o('cited','Cited in review','cited')}${o('recent','Recent references (window above)','')}${o('all','All records in scope','')}</select></label><button class="ghost" id="lrBibCopy">Copy</button><button class="ghost" id="lrBibBib">BibTeX</button><button class="ghost" id="lrBibRis">RIS</button><button class="ghost" id="lrBibCsv">CSV</button></div><div id="lrBibL" class="lr-scroll"></div></section></div>`);
 const R=Q('#lrRoot'),d=D();d.innerHTML=load();
 const tab=p=>{QA('#lrRoot .tabs button').forEach(b=>b.classList.toggle('on',b.dataset.p===p));QA('#lrRoot [data-pane]').forEach(s=>s.hidden=s.dataset.pane!==p);if(p==='rec')drawRecent();if(p==='cite')drawCite();if(p==='bib')drawBib()};
 tab('gen');poolInfo();refresh();
 const gen=()=>{if(!pool().length)return toast('No records in scope — run a search first');if(d.textContent.length>400&&!/^Literature review\s*References/.test(d.textContent.replace(/\n/g,''))&&!confirm('Replace the current draft with a newly generated review?'))return;UNDO=d.innerHTML;d.innerHTML=generate();refresh();toast('Review generated — edit freely, then export')};
 const read=()=>{cfg.topic=Q('#lrTopic').value.trim();cfg.src=Q('#lrSrc').value;cfg.n=+Q('#lrN').value||40;cfg.yf=Q('#lrYF').value;cfg.yt=Q('#lrYT').value;cfg.minc=+Q('#lrMC').value||0;cfg.org=Q('#lrOrg').value;cfg.len=Q('#lrLen').value;cfg.rec=+Q('#lrRec').value;QA('[data-sec]').forEach(c=>cfg.s[c.dataset.sec]=c.checked?1:0);poolInfo()};
 R.onchange=e=>{const t=e.target;if(t.id==='lrStyle'){cfg.style=t.value;refresh();const p=QA('#lrRoot .tabs .on')[0]?.dataset.p;tab(p)}else if(t.id==='lrRec'||t.id==='lrRecW'){cfg.rec=+t.value||cfg.rec;if(t.id==='lrRecW')drawRecent()}else if(t.id==='lrRecS')drawRecent();else if(t.id==='lrBibM')drawBib();else if(t.closest('.row,details')){read();const p=QA('#lrRoot .tabs .on')[0]?.dataset.p;if(p==='rec')drawRecent();if(p==='cite')drawCite()}};
 R.oninput=e=>{if(e.target.id==='lrRecQ')drawRecent();else if(e.target.id==='lrCQ')drawCite();else if(e.target.id==='lrDoc'){clearTimeout(R._t);R._t=setTimeout(()=>{const k=[...new Set(QA('#lrDoc .lr-cite').flatMap(s=>s.dataset.ids.split(',')))];save(k)},600)}};
 d.addEventListener('focusout',()=>refresh());
 d.onclick=e=>{const c=e.target.closest('.lr-cite');if(!c)return;c.dataset.ids.split(',').forEach((k,i)=>{const r=REC.get(k),el=r&&d.querySelector('#lr-ref-'+r.n);if(el&&!i){el.scrollIntoView({behavior:'smooth',block:'center'})}if(el){el.classList.add('flash');setTimeout(()=>el.classList.remove('flash'),1800)}})};
 R.onclick=e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.k,id=b.id;
  if(b.dataset.p)return tab(b.dataset.p);
  if(b.dataset.cmd){d.focus();document.execCommand(b.dataset.cmd,false,b.dataset.v||null);return}
  if(b.dataset.act==='cp'||b.dataset.act==='cn'){ins([k],b.dataset.act==='cp'?'p':'n');return}
  if(b.dataset.ins!==undefined){const x=JSON.parse(b.dataset.ins);ins(x,'p');return}
  switch(id){
   case'lrSearch':{read();const t=cfg.topic||Q('#lrTopic').value.trim();if(!t)return toast('Type a topic first');Q('#q').value=t;Q('#searchForm').requestSubmit();setTimeout(()=>{cfg.src='results';Q('#lrSrc').value='results';poolInfo();toast('Search done — '+(currentResults||[]).length+' matches')},350);break}
   case'lrGen':read();gen();break;
   case'lrRef':refresh();break;
   case'lrCopy':{const h=outHTML();copyRich(h,plain(h));break}
   case'lrDoc2':download('literature_review.doc',wrap(outHTML()),'application/msword');break;
   case'lrHtml':download('literature_review.html',wrap(outHTML()),'text/html');break;
   case'lrTxt':{const h=outHTML().replace(/<\/(p|h\d|div|li|tr)>/g,'$&\n');download('literature_review.txt',plain(h),'text/plain');break}
   case'lrPrint':printDoc();break;
   case'lrRecAll':QA('#lrRecL [data-k]').forEach(c=>c.checked=true);break;
   case'lrRecIns':{const s=sel();if(!s.length)return toast('Tick one or more records');ins(s,'p');break}
   case'lrRecPara':{const s=sel().map(rec).filter(Boolean);if(!s.length)return toast('Tick one or more records');const T=new Set(tk(cfg.topic||state.query||'').map(stm)),p=document.createElement('p');p.innerHTML='Recent literature includes: '+s.map(r=>{const t=pick(r,T,1);return t.length?say(r,t[0]):`${cs([r.k],'n')} address “${esc(r.ti)}”.`}).join(' ');const rf=d.querySelector('#lr-refs'),h2=[...d.querySelectorAll('h2')].find(x=>/^References/.test(x.textContent));d.insertBefore(p,h2||rf);refresh();toast('Paragraph added before the references');break}
   case'lrRecCopy':{const s=sel().map(rec).filter(Boolean),h=s.map(r=>`<p>${refHTML(r,cfg.style)}</p>`).join('');if(!s.length)return toast('Tick one or more records');copyRich(h,plain(h.replace(/<\/p>/g,'\n')));break}
   case'lrCIns':{const s=sel();if(!s.length)return toast('Tick one or more records');ins(s,'p');break}
   case'lrSug':case'lrSugEd':{if(id==='lrSugEd'){const c=d.cloneNode(true);c.querySelector('#lr-refs')?.remove();c.querySelectorAll('.lr-cite').forEach(x=>x.remove());Q('#lrSugIn').value=c.textContent.replace(/\s+/g,' ').trim().slice(0,2500)}
    const out=suggest(Q('#lrSugIn').value),t=THR();Q('#lrSugOut').innerHTML=out.length?out.map((o,i)=>`<div class="card"><div>${esc(o.s)}</div>${o.m.filter(m=>m[0]>=t*.6).map(m=>`<div class="lr-item"><div><b>${esc(m[1].ti)}</b><div class="tiny">${esc(inText(m[1],'p',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))} · match ${(m[0]*100).toFixed(0)}%</div></div><div class="lr-acts"><button class="ghost" data-ins='${JSON.stringify([m[1].k])}'>Insert at cursor</button></div></div>`).join('')||'<div class="tiny">No record passes the match threshold.</div>'}</div>`).join(''):'<p class="tiny">Enter at least one full sentence.</p>';break}
   case'lrAuto':autoCite();break;
   case'lrUndo':if(UNDO){d.innerHTML=UNDO;refresh();toast('Reverted')}break;
   case'lrBibCopy':{const h=Q('#lrBibL').innerHTML;copyRich(h,plain(h.replace(/<\/div>/g,'\n')));break}
   case'lrBibBib':download('review_references.bib',bibRecs().map(i=>bib(recObj(i))).join('\n\n'),'application/x-bibtex');break;
   case'lrBibRis':download('review_references.ris',bibRecs().map(i=>ris(recObj(i))).join('\n\n'),'application/x-research-info-systems');break;
   case'lrBibCsv':download('review_references.csv',['Authors,Year,Title,Source,DOI'].concat(bibRecs().map(rec).filter(Boolean).map(r=>[r.au.map(a=>a.f+(a.ini.length?', '+a.ini.join(''):'')).join('; '),r.yr,r.ti,r.so,r.doi].map(csvCell).join(','))).join('\n'),'text/csv');break}};
 document.addEventListener('selectionchange',()=>{const s=getSelection(),dd=D();if(dd&&s.rangeCount&&dd.contains(s.anchorNode))LAST=s.getRangeAt(0).cloneRange()});
}

/* ---------- styles + entry points ---------- */
const st=document.createElement('style');st.textContent=`.lr .lr-doc{border:1px solid var(--line);border-radius:10px;background:#fff;padding:18px 26px;min-height:380px;max-height:62vh;overflow:auto;font:14.5px/1.65 Georgia,"Times New Roman",serif}
.lr .lr-doc h1{font-size:23px;margin:.2em 0}.lr .lr-doc h2{font-size:17px;margin:1.1em 0 .3em;color:var(--brand)}.lr .lr-doc h3{font-size:14.5px;margin:.9em 0 .2em}.lr .lr-meta{color:#64748b;font-style:italic}
.lr .lr-cite{color:#0b5cad;cursor:pointer;border-radius:4px;padding:0 1px}.lr .lr-cite:hover{background:#e8f1fb}
.lr .lr-ref{margin:0 0 7px 24px;text-indent:-24px;font-size:13.5px}.lr .lr-ref.num{margin-left:34px;text-indent:-34px}.lr .lr-n{display:inline-block;min-width:30px;font-weight:700}.lr .lr-ref.flash{background:#fff3bf}
.lr .lr-tools{border-top:1px solid var(--line);padding-top:8px}.lr .lr-sp{flex:1}.lr-item{display:grid;grid-template-columns:22px 1fr auto;gap:8px;padding:7px 4px;border-bottom:1px solid var(--line);align-items:start}.lr-acts{display:flex;gap:4px;flex-wrap:wrap}
.lr .lr-scroll{max-height:52vh;overflow:auto}.lr .lr-ref-p{font-size:12px;color:#475569;margin-top:3px}.lr .lr-chk{margin-right:12px;font-size:12.5px}.lr .lr-doc table{width:auto;margin:6px 0}
.sample-header .toolbar #lrBtn{background:#fff4e0!important;color:#8a4b00!important}`;document.head.appendChild(st);
window.openLiteratureReview=open;
const btn=document.createElement('button');btn.id='lrBtn';btn.type='button';btn.innerHTML='📚 <span>Literature Review</span>';btn.title='Generate a literature review with recent references and in-text citations from the search results';
const anc=Q('#dxBtn')||Q('#semBtn');if(anc){btn.className=anc.className;anc.insertAdjacentElement('afterend',btn)}else Q('.toolbar')?.appendChild(btn);btn.onclick=open;
const fg=Q('.feature-grid');if(fg){const c=document.createElement('button');c.className='feature-card';c.type='button';c.innerHTML='<span class="feature-icon gold">📚</span><div><b>Literature Review</b><small>Generate a cited review from your results</small></div>';c.onclick=open;fg.appendChild(c)}
const rb=Q('#resultRelated');if(rb){const b=document.createElement('button');b.className='ghost';b.type='button';b.id='resultLitReview';b.textContent='📚 Literature review';b.onclick=open;rb.insertAdjacentElement('afterend',b)}
})();
