
const EMBEDDED_DATA=document.getElementById('embeddedData').textContent;
const PAGE_SIZE=20;
let DATA=null,M=null,R=null,S=null,PUB=null,PLC=null,CO=null,INDEX=null;
let state={query:'',page:1,sort:'relevance',savedOnly:false,yearSet:new Set(),yearFrom:null,yearTo:null,source:'',publisher:'',country:'',subject:'',hasLink:false,minCites:0,advanced:[]};
let currentResults=[];
let SEARCH_SAVED=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function esc(s){return String(s??'').replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m]))}
function safeUrl(u){try{let x=new URL(String(u||''));return (x.protocol==='http:'||x.protocol==='https:')?x.href:''}catch{return ''}}
function norm(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'')}
function tokens(s){return norm(s).match(/[a-z0-9][a-z0-9.+#-]*/g)||[]}
function source(r){return S[r[4]]||''} function publisher(r){return PUB[r[5]]||''} function place(r){return PLC[r[6]]||''} function country(r){return CO[r[7]]||''}
function recObj(i){if(typeof i==='string'&&i.indexOf('online|')===0)return onlineRecObj(i);const r=R[i];return{index:i,cites:r[0],authors:r[1],title:r[2],year:r[3],source:source(r),publisher:publisher(r),place:place(r),country:country(r),url:r[8],doi:r[9],issn:r[10],keywords:r[11],abstract:r[12]}}
function savedSet(){try{return new Set(JSON.parse(localStorage.getItem('libSaved')||'[]'))}catch{return new Set()}}
function setSaved(s){localStorage.setItem('libSaved',JSON.stringify([...s]));updateSavedCount()}
function updateSavedCount(){ $('#savedCount').textContent=savedSet().size }
function toast(msg){let t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
async function unpack(){
  if(!EMBEDDED_DATA.startsWith('GZB64:')) return JSON.parse(EMBEDDED_DATA);
  if(typeof DecompressionStream==='undefined') throw new Error('This browser cannot decompress the embedded dataset. Use a current Chrome, Edge, Firefox or Safari.');
  const bin=Uint8Array.from(atob(EMBEDDED_DATA.slice(6)),c=>c.charCodeAt(0));
  const text=await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  return JSON.parse(text);
}
function buildIndex(){INDEX=R.map(r=>({t:norm(r[2]),a:norm(r[1]),k:norm(r[11]),s:norm(S[r[4]]||''),b:norm(r[12]),d:norm(r[9]),p:norm(PUB[r[5]]||''),c:norm(CO[r[7]]||'')}))}
function populateFacets(){
  const yc=$('#yearChecks'); M.yearCounts.sort((a,b)=>b[0]-a[0]).forEach(([y,c])=>yc.insertAdjacentHTML('beforeend',`<label class="check"><input type="checkbox" data-year="${y}"><span>${y}</span><span>${c.toLocaleString()}</span></label>`));
  const sf=$('#sourceFilter'); M.sourceCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${S[idx]} (${c.toLocaleString()})`;sf.appendChild(o)});
  const pf=$('#publisherFilter'); M.publisherCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${PUB[idx]} (${c.toLocaleString()})`;pf.appendChild(o)});
  const cf=$('#countryFilter'); M.countryCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${CO[idx]} (${c.toLocaleString()})`;cf.appendChild(o)});
  const sub=$('#subjectFilter'); M.topKeywords.forEach(([k,c])=>{let o=document.createElement('option');o.value=k;o.textContent=`${k} (${c.toLocaleString()})`;sub.appendChild(o)});
  $('#yearFrom').min=M.minYear;$('#yearFrom').max=M.maxYear;$('#yearTo').min=M.minYear;$('#yearTo').max=M.maxYear;
}
function exactPhrases(q){return [...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean)}
function matchText(field,op,val){let x=norm(field),v=norm(val).trim();if(!v)return true;if(op==='exact')return x===v;if(op==='starts')return x.startsWith(v);if(op==='not')return !wordsContain(field,val);return wordsContain(field,val)}
function advancedMatch(i){if(!state.advanced.length)return true;let result=null;const r=R[i], ix=INDEX[i];for(let row of state.advanced){let field='';switch(row.field){case'title':field=r[2];break;case'authors':field=r[1];break;case'keywords':field=r[11];break;case'source':field=S[r[4]];break;case'publisher':field=PUB[r[5]];break;case'country':field=CO[r[7]];break;case'abstract':field=r[12];break;case'doi':field=r[9];break;case'year':field=String(r[3]);break;}let m=matchText(field,row.op,row.value);if(result===null)result=m;else result=row.bool==='OR'?(result||m):(result&&m)}return result===null?true:result}
/* ===== Accurate search matching: whole words, every term required, stop words ignored ===== */
const SRCH_STOP=new Set('a an the and or of in on for to with by from at as is are was were be been being this that these those it its into than then not no do does did how what which who whom when where why can could about over under via vs versus within without per'.split(' '));
const SRCH_RX=new Map(),SRCH_PRX=new Map();
function srchEsc(t){return String(t).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
function srchTermRx(t){let r=SRCH_RX.get(t);if(!r){r=new RegExp('(^|[^a-z0-9])'+srchEsc(t)+'(s|es|ed|ing)?(?=$|[^a-z0-9])');SRCH_RX.set(t,r)}return r}
function srchPhraseRx(p){let r=SRCH_PRX.get(p);if(!r){r=new RegExp('(^|[^a-z0-9])'+srchEsc(p).replace(/\s+/g,'[^a-z0-9]+')+'(?=$|[^a-z0-9])');SRCH_PRX.set(p,r)}return r}
function srchTerms(q){
  const plain=norm(q).replace(/"[^"]*"/g,' ').replace(/^https?:\/\/(dx\.)?doi\.org\//,'');
  const all=plain.match(/[a-z0-9]+/g)||[];
  const kept=all.filter(w=>w.length>=2&&!SRCH_STOP.has(w));
  return [...new Set(kept.length?kept:all)];
}
function wordsContain(field,val){const v=norm(val).trim();if(!v)return true;return srchPhraseRx(v).test(norm(field))}
function relevance(i,q){
  const r=R[i],x=INDEX[i];
  const terms=srchTerms(q),phr=exactPhrases(q);
  if(!terms.length&&!phr.length)return Math.log1p(r[0])*.2;
  let sc=0;const why=[];const add=(label,n)=>{if(n>0){sc+=n;why.push([label,n])}};
  const nq=norm(q).replace(/^https?:\/\/(dx\.)?doi\.org\//,'').trim();
  if(nq&&x.d&&x.d===nq){add('exact DOI',140);sc+=Math.min(5,Math.log1p(r[0])*.7);return {score:sc,why}}
  for(const ph of phr){
    const hits=[['exact title phrase',x.t,55],['keyword phrase',x.k,34],['author phrase',x.a,28],['journal/source phrase',x.s,20],['abstract phrase',x.b,10]]
      .filter(([l,f])=>f&&srchPhraseRx(ph).test(f));
    if(!hits.length)return {score:0,why:[]};
    hits.forEach(([l,f,w])=>add(l,w));
  }
  for(const t of terms){
    const rx=srchTermRx(t);
    const hits=[['title',x.t,12],['keywords',x.k,8],['authors',x.a,6],['journal/source',x.s,5],['abstract',x.b,2],['DOI',x.d,18]]
      .filter(([l,f])=>f&&rx.test(f));
    if(!hits.length)return {score:0,why:[]};
    hits.forEach(([l,f,w])=>add(l,w));
  }
  if(terms.length&&x.t&&terms.every(t=>srchTermRx(t).test(x.t)))add('all terms in title',20);
  if(sc>0)sc+=Math.min(5,Math.log1p(r[0])*.7);
  return {score:sc,why};
}
function passesFacets(i){const r=R[i];if(state.savedOnly&&(!SEARCH_SAVED||!SEARCH_SAVED.has(i)))return false;if(state.yearSet.size&&!state.yearSet.has(r[3]))return false;if(state.yearFrom&&r[3]<state.yearFrom)return false;if(state.yearTo&&r[3]>state.yearTo)return false;if(state.source!==''&&r[4]!==Number(state.source))return false;if(state.publisher!==''&&r[5]!==Number(state.publisher))return false;if(state.country!==''&&r[7]!==Number(state.country))return false;if(state.subject&& !norm(r[11]).includes(norm(state.subject)))return false;if(state.hasLink&&!r[8])return false;if(r[0]<(state.minCites||0))return false;if(!advancedMatch(i))return false;return true}
function doSearch(saveHist=true){
  const q=state.query.trim();
  // Hide left filter panel while a text search is active
  document.body.classList.toggle('has-search', !!q);
let out=[];SEARCH_SAVED=state.savedOnly?savedSet():null;
  for(let i=0;i<R.length;i++){if(!passesFacets(i))continue;let rel=relevance(i,q);let score=typeof rel==='number'?rel:rel.score;if((q&&score<=0))continue;out.push({i,score,why:typeof rel==='number'?[]:rel.why})}
  if(state.sort==='cites')out.sort((a,b)=>R[b.i][0]-R[a.i][0]||b.score-a.score);else if(state.sort==='newest')out.sort((a,b)=>R[b.i][3]-R[a.i][3]||b.score-a.score);else if(state.sort==='oldest')out.sort((a,b)=>R[a.i][3]-R[b.i][3]||b.score-a.score);else if(state.sort==='title')out.sort((a,b)=>R[a.i][2].localeCompare(R[b.i][2]));else out.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);
  currentResults=out; state.page=Math.min(state.page,Math.max(1,Math.ceil(out.length/PAGE_SIZE)));render(); updateRelatedPanel();
  const facetsEl=document.getElementById('facets');
  if(facetsEl){if(q){document.body.classList.add('has-search');facetsEl.style.display='none';}else{document.body.classList.remove('has-search');facetsEl.style.display='';}}
  if(q){requestAnimationFrame(()=>{const el=document.getElementById('resultCount')||document.getElementById('results');if(el)el.scrollIntoView({behavior:'smooth',block:'start'});});}
}
function highlight(text,q){
  const ts=srchTerms(q),s=esc(text||'');if(!ts.length)return s;
  return s.replace(/[A-Za-z0-9]+/g,w=>{const lw=w.toLowerCase();return ts.some(t=>lw===t||lw===t+'s'||lw===t+'es'||lw===t+'ed'||lw===t+'ing')?'<mark class="match">'+w+'</mark>':w});
}
function render(){
 $('#resultCount').textContent=`${currentResults.length.toLocaleString()} result${currentResults.length===1?'':'s'}`+(state.savedOnly?' in Saved items':'')+(state.query.trim()&&srchTerms(state.query).length?' · every record contains: '+srchTerms(state.query).map(esc).join(', '):'');
 const list=$('#resultList');list.innerHTML='';let start=(state.page-1)*PAGE_SIZE,end=Math.min(start+PAGE_SIZE,currentResults.length);let saved=savedSet();
 if(!currentResults.length){list.innerHTML='<div class="panel empty"><b>No matching records</b><br>Search matches whole words and requires every term (stop words such as “the” are ignored). Check spelling, use fewer terms, or clear one or more filters.</div>'} else for(let pos=start;pos<end;pos++){let hit=currentResults[pos],o=recObj(hit.i);let card=document.createElement('article');card.className='result-card';card.innerHTML=`
   <span class="rank-badge">${pos+1}</span><h2 class="rtitle">${highlight(o.title,state.query)}</h2>
   <div class="meta">${highlight(o.authors,state.query)} · <b>${o.year||'Year n/a'}</b> · ${highlight(o.source,state.query)}</div>
   <div class="badges"><span class="badge cites">Cited ${Number(o.cites).toLocaleString()}×</span>${safeUrl(o.url)?'<span class="badge access">Article link</span>':''}${o.country?`<span class="badge">${esc(o.country)}</span>`:''}</div>
   <div class="abstract">${highlight(o.abstract||'No abstract supplied.',state.query)}</div>
   ${o.keywords?`<div class="tiny"><b>Keywords:</b> ${highlight(o.keywords,state.query)}</div>`:''}
   <div class="actions">${safeUrl(o.url)?`<a class="full" href="${esc(safeUrl(o.url))}" target="_blank" rel="noopener">Open article / DOI ↗</a>`:''}<button data-act="detail" data-id="${hit.i}">Details</button><button data-act="save" data-id="${hit.i}">${saved.has(hit.i)?'★ Saved':'☆ Save'}</button><button data-act="cite" data-id="${hit.i}">Cite</button><button data-act="export" data-id="${hit.i}">Export</button><button data-act="related" data-id="${hit.i}">Related</button><button data-act="graph" data-id="${hit.i}">Knowledge graph</button><button class="ri-ner" data-act="ner" data-id="${hit.i}">NER</button><button class="ri-hyp" data-act="hyp" data-id="${hit.i}">Hypothesis</button><button class="ri-gap" data-act="gap" data-id="${hit.i}">Research gaps</button><button data-act="why" data-id="${hit.i}">Why this result?</button></div>
   <div class="why" id="why-${hit.i}">${whyText(hit,o)}</div>`;list.appendChild(card)}
 renderPager();renderActiveFilters();updateSavedCount();
}
function whyText(hit,o){if(!state.query)return `No text query is active. This record is ordered using the selected sort; its citation count is ${o.cites}.`;if(!hit.why.length)return 'The record passed filters but has no positive text contribution.';let grouped={};hit.why.forEach(([k,v])=>grouped[k]=(grouped[k]||0)+v);return `<b>Ranking score: ${hit.score.toFixed(1)}</b><br>`+Object.entries(grouped).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${esc(k)} +${v}`).join(' · ')+`<br><span class="tiny">Citation count adds only a small tie-breaking boost to text relevance.</span>`}
function renderPager(){let p=$('#pager'),pages=Math.ceil(currentResults.length/PAGE_SIZE);if(pages<=1){p.innerHTML='';return}p.innerHTML=`<button class="ghost" id="prevPage" ${state.page<=1?'disabled':''}>← Previous</button><span class="tiny">Page ${state.page.toLocaleString()} of ${pages.toLocaleString()}</span><button class="ghost" id="nextPage" ${state.page>=pages?'disabled':''}>Next →</button>`;$('#prevPage').onclick=()=>{state.page--;render();scrollToResults()};$('#nextPage').onclick=()=>{state.page++;render();scrollToResults()}}
function scrollToResults(){window.scrollTo({top:Math.max(0,$('#resultCount').getBoundingClientRect().top+scrollY-150),behavior:'smooth'})}
function renderActiveFilters(){let arr=[];if(state.query)arr.push(`Query: ${state.query}`);if(state.savedOnly)arr.push('Saved only');if(state.yearSet.size)arr.push('Years: '+[...state.yearSet].sort().join(', '));if(state.yearFrom||state.yearTo)arr.push(`Year ${state.yearFrom||'…'}–${state.yearTo||'…'}`);if(state.source!=='')arr.push('Source: '+S[Number(state.source)]);if(state.publisher!=='')arr.push('Publisher: '+PUB[Number(state.publisher)]);if(state.country!=='')arr.push('Country: '+CO[Number(state.country)]);if(state.subject)arr.push('Subject: '+state.subject);if(state.hasLink)arr.push('Link available');if(state.minCites)arr.push(`Citations ≥ ${state.minCites}`);if(state.advanced.length)arr.push('Advanced fields active');$('#activeFilters').innerHTML=arr.map(x=>`<span class="filtertag">${esc(x)}</span>`).join('')}
function clearFilters(skipSearch){state.yearSet.clear();state.yearFrom=null;state.yearTo=null;state.source='';state.publisher='';state.country='';state.subject='';state.hasLink=false;state.minCites=0;$$('[data-year]').forEach(x=>x.checked=false);$('#yearFrom').value='';$('#yearTo').value='';$('#sourceFilter').value='';$('#publisherFilter').value='';$('#countryFilter').value='';$('#subjectFilter').value='';$('#hasLink').checked=false;$('#minCites').value=0;state.savedOnly=false;state.advanced=[];if($('#advRows')){$('#advRows').innerHTML='';if(typeof addAdvRow==='function')addAdvRow();}if(!skipSearch)doSearch(false)}
function apa(o){let doi=o.doi?` https://doi.org/${o.doi.replace(/^https?:\/\/(dx\.)?doi\.org\//i,'')}`:'';return `${o.authors} (${o.year||'n.d.'}). ${o.title}. ${o.source}.${doi}`.replace(/\s+/g,' ').trim()}
function ris(o){let au=(o.authors||'').split(';').map(x=>`AU  - ${x.trim()}`).join('\n');let kw=(o.keywords||'').split(';').filter(Boolean).map(x=>`KW  - ${x.trim()}`).join('\n');return `TY  - JOUR\n${au}\nTI  - ${o.title}\nJO  - ${o.source}\nPY  - ${o.year}\nSN  - ${o.issn}\nDO  - ${o.doi}\nUR  - ${o.url}\n${kw}\nAB  - ${o.abstract}\nER  - `}
function bib(o){let first=(o.authors||'unknown').split(';')[0].trim().split(/\s+/).pop().replace(/\W/g,'')||'record';let key=`${first}${o.year||''}${(o.title.match(/[A-Za-z0-9]+/)||['item'])[0]}`;let authors=(o.authors||'').split(';').map(x=>x.trim()).join(' and ');return `@article{${key},\n  author = {${authors}},\n  title = {${o.title}},\n  journal = {${o.source}},\n  year = {${o.year}},\n  doi = {${o.doi}},\n  issn = {${o.issn}},\n  url = {${o.url}},\n  keywords = {${o.keywords}}\n}`}
function download(name,text,type='text/plain'){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
function csvCell(v){v=String(v??'');return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}
function exportHits(format,hits){let objs=hits.map(h=>recObj(h.i??h));if(format==='ris')download('library_export.ris',objs.map(ris).join('\n\n'),'application/x-research-info-systems');else if(format==='bib')download('library_export.bib',objs.map(bib).join('\n\n'),'application/x-bibtex');else{let head=['Cites','Authors','Title','Year','Source','Publisher','Place','Country','ArticleURL','DOI','ISSN','Keywords','Abstract'];let rows=[head,...objs.map(o=>[o.cites,o.authors,o.title,o.year,o.source,o.publisher,o.place,o.country,o.url,o.doi,o.issn,o.keywords,o.abstract])];download('library_export.csv',rows.map(r=>r.map(csvCell).join(',')).join('\n'),'text/csv;charset=utf-8')}}
function exportModal(hits,title='Export'){showModal(`<h2>${title}</h2><p>Choose a format. RIS can be imported by Zotero, Mendeley, EndNote and many library tools.</p><div class="actions"><button class="primary" data-exp="ris">RIS (Zotero/Mendeley)</button><button data-exp="bib">BibTeX</button><button data-exp="csv">CSV</button></div><p class="tiny">Records to export: ${hits.length.toLocaleString()}</p>`);$$('[data-exp]').forEach(b=>b.onclick=()=>{exportHits(b.dataset.exp,hits);toast('Export created')})}
function showModal(body){$('#modalBody').innerHTML=body;$('#modal').classList.add('open');$('#modal').setAttribute('aria-hidden','false');$('#modalClose').focus()}
function closeModal(){$('#modal').classList.remove('open');$('#modal').setAttribute('aria-hidden','true');$('#modalCard').classList.remove('graph-modal-card');if(window.KG&&KG.anim)cancelAnimationFrame(KG.anim)}
function detail(i){let o=recObj(i);showModal(`<h2>${esc(o.title)}</h2><div class="meta">${esc(o.authors)} · ${o.year} · ${esc(o.source)}</div><div class="detail-grid"><div class="detail-block"><b>Publisher</b>${esc(o.publisher||'Not supplied')}</div><div class="detail-block"><b>Place / country</b>${esc([o.place,o.country].filter(Boolean).join(', ')||'Not supplied')}</div><div class="detail-block"><b>DOI</b>${esc(o.doi||'Not supplied')}</div><div class="detail-block"><b>ISSN</b>${esc(o.issn||'Not supplied')}</div><div class="detail-block"><b>Citation count</b>${o.cites.toLocaleString()}</div><div class="detail-block"><b>Access</b>${safeUrl(o.url)?`<a href="${esc(safeUrl(o.url))}" target="_blank" rel="noopener">Open supplied article/DOI link ↗</a>`:'No valid web URL supplied'}</div></div><h3>Keywords</h3><p>${esc(o.keywords||'Not supplied')}</p><h3>Abstract</h3><p>${esc(o.abstract||'Not supplied')}</p>`)}
function citeModal(i){let o=recObj(i),txt=apa(o);showModal(`<h2>Cite this record</h2><label for="citeText"><b>APA-style citation (generated, read-only)</b></label><textarea id="citeText" readonly aria-readonly="true" style="width:100%;height:130px;margin-top:8px;border:1px solid var(--line);border-radius:9px;padding:10px">${esc(txt)}</textarea><div class="actions"><button class="primary" id="copyCite">Copy citation</button><button id="downloadRis">Download RIS</button><button id="downloadBib">Download BibTeX</button></div><p class="tiny">Citation formatting is generated from the fields supplied in the dataset; verify local style requirements before submission.</p>`);$('#copyCite').onclick=async()=>{let v=$('#citeText').value;try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(v)}else{let ta=$('#citeText');ta.focus();ta.select();document.execCommand('copy')}toast('Citation copied')}catch{toast('Select the citation and copy it manually')}};$('#downloadRis').onclick=()=>exportHits('ris',[i]);$('#downloadBib').onclick=()=>exportHits('bib',[i])}
function related(i){let base=recObj(i),bk=new Set(tokens(base.keywords).filter(x=>x.length>2)),ba=new Set((base.authors||'').split(';').map(norm));let arr=[];for(let j=0;j<R.length;j++){if(j===i)continue;let o=recObj(j),score=0;if(o.source===base.source)score+=3;let oa=(o.authors||'').split(';').map(norm);for(let a of oa)if(ba.has(a)&&a)score+=8;let ok=new Set(tokens(o.keywords).filter(x=>x.length>2));let overlap=0;for(let k of bk)if(ok.has(k))overlap++;score+=overlap*2;if(score>2)arr.push({i:j,score})}arr.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);let top=arr.slice(0,12);showModal(`<h2>Related items</h2><p class="tiny">Ranked locally using shared authors, journal/source and keyword overlap.</p><div class="related-list">${top.map(x=>{let o=recObj(x.i);return `<button class="related-item" data-open-detail="${x.i}" style="text-align:left;background:#fff"><b>${esc(o.title)}</b><div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)} · similarity ${x.score}</div></button>`}).join('')||'<div class="note">No strong related items found.</div>'}</div>`);$$('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)))}
let KG={nodes:[],edges:[],nodeMap:new Map(),canvas:null,ctx:null,scale:1,tx:0,ty:0,hover:null,selected:null,drag:null,pan:null,anim:0,steps:0,showEdgeLabels:false,mode:'results',baseHits:[],focusIndex:null};
const KG_COLORS={query:'#6d28d9',paper:'#184e77',author:'#c2410c',journal:'#047857',keyword:'#7c3aed',publisher:'#b45309',country:'#be123c',year:'#475569',nerRoot:'#0ea5e9',entity:'#0284c7',organization:'#0f766e',location:'#be185d',identifier:'#475569',place:'#be185d',doi:'#64748b',url:'#0369a1',method:'#db2777',hypRoot:'#7c3aed',hypothesis:'#8b5cf6',gapRoot:'#b7791f',gap:'#e59a12',context:'#0891b2',evidence:'#64748b',concept:'#2563eb'};
const KG_NAMES={query:'Search query',paper:'Title',author:'Author / Person',journal:'Journal / source',keyword:'Keyword',publisher:'Publisher',country:'Country',place:'Place',doi:'DOI',url:'URL',year:'Year',nerRoot:'NER analysis',entity:'Named entity',organization:'Organization',location:'Location',identifier:'Identifier',method:'Method / technology',hypRoot:'Hypothesis analysis',hypothesis:'Alternative hypothesis',gapRoot:'Research-gap analysis',gap:'Gap signal',context:'Context',evidence:'Evidence',concept:'Research concept'};
function splitAuthors(v){return (v||'').split(';').map(x=>x.trim()).filter(Boolean)}
function splitKeywords(v){return (v||'').split(';').map(x=>x.trim()).filter(Boolean)}
function nodeUrlFor(type,label,o){const enc=s=>encodeURIComponent(String(s||'').trim());if(type==='doi'){let d=String(label||'').trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return d?'https://doi.org/'+d:''}if(type==='url')return safeUrl(label);if(type==='place')return 'https://www.google.com/maps/search/?api=1&query='+enc(label);if(type==='paper'&&o){let u=safeUrl(o.url);if(u)return u;let d=String(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').trim();if(d)return 'https://doi.org/'+d;return ''}if(type==='author')return 'https://scholar.google.com/scholar?q='+enc('author:"'+label+'"');if(type==='journal')return 'https://www.worldcat.org/search?q='+enc(label);if(type==='publisher')return 'https://www.google.com/search?q='+enc(label+' publisher');if(type==='country')return 'https://en.wikipedia.org/wiki/'+enc(label.replace(/ /g,'_'));if(type==='year')return '';if(type==='keyword'||type==='concept')return 'https://scholar.google.com/scholar?q='+enc('"'+label+'"');if(type==='organization')return 'https://www.google.com/search?q='+enc(label);if(type==='location')return 'https://www.google.com/search?q='+enc(label);if(type==='identifier'){let m=String(label).match(/DOI:\s*(.+)/i);if(m)return 'https://doi.org/'+m[1].trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return ''}if(type==='method')return 'https://scholar.google.com/scholar?q='+enc('"'+label+'"');if(type==='query')return '';return ''}
function kgNodeLinkHtml(n){let u=safeUrl(n&&n.url);if(!u)return '';return `<div class="tiny" style="margin:6px 0 4px"><b>URL:</b> <a href="${esc(u)}" target="_blank" rel="noopener" title="${esc(u)}">${esc(u.length>72?u.slice(0,70)+'…':u)}</a></div>`}
function kgAddNode(map,n){let key=n.type==='paper'?('paper|'+n.paperIndex):(n.type+'|'+norm(n.label));if(map.has(key)){let ex=map.get(key);ex.weight=(ex.weight||1)+1;if(n.paperIndex!==undefined&&ex.paperIndex===undefined)ex.paperIndex=n.paperIndex;if(!ex.url&&n.url)ex.url=n.url;if(n.cites!==undefined&&(ex.cites===undefined||n.cites>ex.cites))ex.cites=n.cites;return ex}n.id=key;n.weight=n.weight||1;n.x=n.x||0;n.y=n.y||0;n.vx=0;n.vy=0;n.fixed=false;if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';map.set(key,n);return n}

/* ── Connected-relationship schema (from Connected_Relationships_for_different_Nodes.xlsx) ── */
const KG_ENTITY_TYPE={Author:'author',Title:'paper',Journal:'journal',Publisher:'publisher',Place:'place',Keywords:'keyword',Year:'year',DOI:'doi',URL:'url'};
const KG_REL_SCHEMA=[
{a:'Author',rel:'writes',b:'Title',rev:'is_written_by'},
{a:'Author',rel:'contributes_to',b:'Journal',rev:'has_contributor'},
{a:'Author',rel:'publishes_with',b:'Publisher',rev:'publishes_work_of'},
{a:'Author',rel:'publishes_in_place',b:'Place',rev:'hosts_publications_of'},
{a:'Author',rel:'uses',b:'Keywords',rev:'associated_with'},
{a:'Author',rel:'publishes_in_year',b:'Year',rev:'has_publication_by'},
{a:'Author',rel:'linked_by',b:'DOI',rev:'linked_work_of'},
{a:'Author',rel:'accessible_via',b:'URL',rev:'links_to_work_of'},
{a:'Title',rel:'published_in',b:'Journal',rev:'contains'},
{a:'Title',rel:'published_by',b:'Publisher',rev:'publishes'},
{a:'Title',rel:'published_at',b:'Place',rev:'hosts_publication'},
{a:'Title',rel:'described_by',b:'Keywords',rev:'describes'},
{a:'Title',rel:'appears_in',b:'Year',rev:'includes_title'},
{a:'Title',rel:'identified_by',b:'DOI',rev:'represents'},
{a:'Title',rel:'available_at',b:'URL',rev:'links_to'},
{a:'Journal',rel:'issued_by',b:'Publisher',rev:'issues'},
{a:'Journal',rel:'published_at',b:'Place',rev:'hosts_journal'},
{a:'Journal',rel:'indexed_by',b:'Keywords',rev:'used_in'},
{a:'Journal',rel:'active_in',b:'Year',rev:'includes_journal'},
{a:'Journal',rel:'represented_by',b:'DOI',rev:'represents_journal'},
{a:'Journal',rel:'accessible_at',b:'URL',rev:'links_to_journal'},
{a:'Publisher',rel:'located_in',b:'Place',rev:'hosts_publisher'},
{a:'Publisher',rel:'connected_with',b:'Keywords',rev:'connected_by'},
{a:'Publisher',rel:'operates_in',b:'Year',rev:'has_published_by'},
{a:'Publisher',rel:'assigns',b:'DOI',rev:'assigned_by'},
{a:'Publisher',rel:'provides',b:'URL',rev:'from_publisher'},
{a:'Place',rel:'associated_with',b:'Keywords',rev:'linked_to_place'},
{a:'Place',rel:'active_in',b:'Year',rev:'includes_place'},
{a:'Keywords',rel:'relevant_in',b:'Year',rev:'has_keywords'}
];
/* Which schema rows each model draws. Title is the hub and is always present. */
const KG_MODEL_SCOPE={
  bibliographic:{},
  coauthorship:{focus:'Author'},
  concept:{focus:'Keywords'},
  ecosystem:{within:['Publisher','Journal','Place']},
  temporal:{focus:'Year'},
  ner:{within:['Author','Journal','Publisher','Place','Keywords','DOI']}
};
function kgModelRows(modelId){
  const sc=KG_MODEL_SCOPE[modelId]||{};
  return KG_REL_SCHEMA.filter(r=>{
    if(sc.focus) return r.a===sc.focus||r.b===sc.focus;
    if(sc.within) return [r.a,r.b].every(x=>x==='Title'||sc.within.includes(x));
    return true;
  });
}
function kgLegendFor(modelId){
  const lines=kgModelRows(modelId).map(r=>`<b>${esc(r.rel)}</b> — ${esc(r.a)} → ${esc(r.b)} <span style="color:var(--muted)">(reverse: ${esc(r.rev)})</span>`);
  return lines.join('<br>');
}

/* ── Multiple Knowledge-Graph construction models (views of the schema above) ── */
const KG_MODELS = {
  bibliographic: {
    id: 'bibliographic',
    label: 'Bibliographic Metadata Model',
    desc: 'Full connected-relationship schema: every relationship in the sheet is drawn between the Title, Author, Journal, Publisher, Place, Keywords, Year, DOI and URL nodes of each record.',
    relations: kgLegendFor('bibliographic')
  },
  coauthorship: {
    id: 'coauthorship',
    label: 'Co-Authorship / Collaboration Network',
    desc: 'Author-centred view: only relationships where Author is one end are drawn (writes, contributes_to, publishes_with, uses, and so on).',
    relations: kgLegendFor('coauthorship')
  },
  concept: {
    id: 'concept',
    label: 'Concept / Keyword Co-occurrence Model',
    desc: 'Keyword-centred view: only relationships that involve Keywords are drawn (described_by, uses, indexed_by, connected_with, associated_with, relevant_in).',
    relations: kgLegendFor('concept')
  },
  ecosystem: {
    id: 'ecosystem',
    label: 'Publishing Ecosystem Model',
    desc: 'Publisher, Journal and Place relationships only (issued_by, published_at, located_in, published_by, published_in, and their Title links).',
    relations: kgLegendFor('ecosystem')
  },
  temporal: {
    id: 'temporal',
    label: 'Temporal Impact Model',
    desc: 'Year-centred view: only relationships that involve Year are drawn (appears_in, publishes_in_year, active_in, operates_in, relevant_in).',
    relations: kgLegendFor('temporal')
  },
  ner: {
    id: 'ner',
    label: 'NER Entity-Relation Model',
    desc: 'Entities extracted from titles, abstracts and metadata are attached to their records with the same schema: persons as Author, organisations as Publisher, locations as Place, methods and concepts as Keywords, identifiers as DOI, journals as Journal.',
    relations: kgLegendFor('ner')
  }
};

/* Generic builder. items: [{key, rank, score, o:{title,year,source,publisher,place,doi,url,cites}, authors:[], keywords:[]}] */
function kgSchemaBuild(items, modelId='bibliographic', opts={}){
  const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
  const active = new Set(opts.types ? [...opts.types] : ['author','journal','publisher','place','keyword','year','doi','url']);
  const isOn = name => KG_ENTITY_TYPE[name]==='paper' || active.has(KG_ENTITY_TYPE[name]);
  const rows = kgModelRows(model.id).filter(r => isOn(r.a) && isOn(r.b));
  const used = new Set(rows.flatMap(r => [r.a, r.b]));
  const map = new Map(), edges = [], edgeSeen = new Set();
  const addEdge = (a, b, relation, detail='', rev='') => {
    if(!a || !b || a === b) return;
    const ek = [a.id, b.id, relation].sort().join('§');
    if(edgeSeen.has(ek)) return;
    edgeSeen.add(ek);
    edges.push({a, b, relation, detail, rev});
  };
  // Model views relate each record only to its own entities (no query hub, no "matched search" edges)
  const qn = null;

  const perPaper = [];
  items.forEach((it, rank) => {
    const o = it.o;
    const pn = kgAddNode(map, {type:'paper', label: o.title || 'Untitled', paperIndex: it.key, cites: o.cites || 0,
      year: o.year, source: o.source, rank: rank + 1, score: it.score || 0, weight: 1 + Math.log1p(o.cites || 0), url: o.url || ''});
    const ents = {Title: [pn]};
    const add = (name, node) => { if(node) (ents[name] = ents[name] || []).push(node); };
    if(used.has('Author')) it.authors.slice(0, 8).forEach(a => add('Author', kgAddNode(map, {type:'author', label:a})));
    if(used.has('Journal') && o.source) add('Journal', kgAddNode(map, {type:'journal', label:o.source}));
    if(used.has('Publisher') && o.publisher) add('Publisher', kgAddNode(map, {type:'publisher', label:o.publisher}));
    if(used.has('Place') && o.place) add('Place', kgAddNode(map, {type:'place', label:o.place}));
    if(used.has('Keywords')) it.keywords.slice(0, 8).forEach(k => add('Keywords', kgAddNode(map, {type:'keyword', label:k})));
    if(used.has('Year') && o.year) add('Year', kgAddNode(map, {type:'year', label:String(o.year)}));
    const doi = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    if(used.has('DOI') && doi) add('DOI', kgAddNode(map, {type:'doi', label:doi}));
    const pageUrl = safeUrl(o.url);
    if(used.has('URL') && pageUrl) add('URL', kgAddNode(map, {type:'url', label:pageUrl.replace(/^https?:\/\//, ''), url:pageUrl}));
    perPaper.push({key: pn.id, ents});
  });

  // NER-extracted entities are attached to the records they were found in, using the same schema names
  if(modelId === 'ner' && opts.nerHits && typeof riNER === 'function'){
    const ner = riNER(opts.nerHits);
    const catMap = {person:'Author', organization:'Publisher', location:'Place', method:'Keywords', concept:'Keywords', identifier:'DOI', journal:'Journal'};
    Object.keys(catMap).forEach(cat => {
      const name = catMap[cat];
      if(!used.has(name)) return;
      const m = ner[cat];
      if(!m) return;
      const entries = m instanceof Map ? [...m.values()] : [];
      entries.slice(0, 20).forEach(e => {
        const node = kgAddNode(map, {type: KG_ENTITY_TYPE[name], label: e.label, weight: e.count || 1});
        (e.papers || []).forEach(pi => {
          const pp = perPaper.find(p => p.key === 'paper|' + pi);
          if(pp) (pp.ents[name] = pp.ents[name] || []).push(node);
        });
      });
    });
  }

  // Every edge comes from the schema: A --rel--> B, with the reverse name shown from the B end
  perPaper.forEach(pp => {
    rows.forEach(r => {
      const A = pp.ents[r.a] || [];
      const B = pp.ents[r.b] || [];
      A.forEach(x => B.forEach(y => addEdge(x, y, r.rel, `${r.a} → ${r.b}`, r.rev)));
    });
  });

  return {nodes: [...map.values()], edges, model};
}

function kgBuildByModel(hits, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = hits.slice(0, limit);
  const items = chosen.map((h, rank) => {
    const idx = h.i ?? h, o = recObj(idx);
    const doiText = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    const url = safeUrl(o.url) || (doiText ? 'https://doi.org/' + doiText : '');
    return {
      key: idx, rank, score: h.score || 0,
      o: {title:o.title, year:o.year, source:o.source, publisher:o.publisher, place:o.place, doi:o.doi, url, cites:o.cites},
      authors: splitAuthors(o.authors),
      keywords: splitKeywords(o.keywords)
    };
  });
  const q = (state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Query: ${q}` : 'Current result set',
    nerHits: chosen.map(h => ({i: h.i ?? h}))
  });
}

function kgBuild(hits,opts={}){let limit=Number(opts.limit||20),types=opts.types||new Set(['author','journal','keyword','publisher','country','year']);let chosen=hits.slice(0,limit);let map=new Map(),edges=[],edgeSeen=new Set();let qn=null;if(opts.includeSearchRoot!==false){let queryLabel=state.query.trim()?`Query: ${state.query.trim()}`:'Current result set';qn=kgAddNode(map,{type:'query',label:queryLabel,weight:Math.max(1,chosen.length)})}
 const addEdge=(a,b,relation,detail='')=>{if(!a||!b)return;let ek=[a.id,b.id,relation].sort().join('§');if(edgeSeen.has(ek))return;edgeSeen.add(ek);edges.push({a,b,relation,detail})};
 chosen.forEach((h,rank)=>{let idx=h.i??h,o=recObj(idx);let pn=kgAddNode(map,{type:'paper',label:o.title,paperIndex:idx,cites:o.cites,year:o.year,source:o.source,rank:rank+1,score:h.score||0,weight:1,url:nodeUrlFor('paper',o.title,o)});if(qn)addEdge(qn,pn,'matched search',state.query?`rank ${rank+1}`:'current ordering');
   if(types.has('author'))splitAuthors(o.authors).slice(0,6).forEach(a=>addEdge(pn,kgAddNode(map,{type:'author',label:a,url:nodeUrlFor('author',a)}),'authored by'));
   if(types.has('journal')&&o.source)addEdge(pn,kgAddNode(map,{type:'journal',label:o.source,url:nodeUrlFor('journal',o.source)}),'published in');
   if(types.has('keyword'))splitKeywords(o.keywords).slice(0,7).forEach(k=>addEdge(pn,kgAddNode(map,{type:'keyword',label:k,url:nodeUrlFor('keyword',k)}),'has keyword'));
   if(types.has('publisher')&&o.publisher)addEdge(pn,kgAddNode(map,{type:'publisher',label:o.publisher,url:nodeUrlFor('publisher',o.publisher)}),'published by');
   if(types.has('country')&&o.country)addEdge(pn,kgAddNode(map,{type:'country',label:o.country,url:nodeUrlFor('country',o.country)}),'associated country');
   if(types.has('year')&&o.year)addEdge(pn,kgAddNode(map,{type:'year',label:String(o.year),url:nodeUrlFor('year',String(o.year))}),'published in year');
 });
 let nodes=[...map.values()];
 // Shared entity nodes already reveal paper-paper relationships. Add explicit paper links only for strong relationships.
 let papers=nodes.filter(n=>n.type==='paper');
 for(let a=0;a<papers.length;a++)for(let b=a+1;b<papers.length;b++){let oa=recObj(papers[a].paperIndex),ob=recObj(papers[b].paperIndex),rels=[];let aa=new Set(splitAuthors(oa.authors).map(norm)),ab=splitAuthors(ob.authors).map(norm);let sharedA=ab.filter(x=>aa.has(x)&&x);if(sharedA.length)rels.push('shared author');let ka=new Set(splitKeywords(oa.keywords).map(norm)),kb=splitKeywords(ob.keywords).map(norm);let sharedK=kb.filter(x=>ka.has(x)&&x);if(sharedK.length>=2)rels.push(`${sharedK.length} shared keywords`);if(oa.source&&oa.source===ob.source)rels.push('same journal');if(sharedA.length||sharedK.length>=3){addEdge(papers[a],papers[b],'related paper',rels.join(', '))}}
 return {nodes,edges,chosen};}
function kgInitPositions(){let W=1100,H=640,papers=KG.nodes.filter(n=>n.type==='paper'),root=KG.nodes.find(n=>n.type==='query'||n.root),entities=KG.nodes.filter(n=>n.type!=='paper'&&n!==root);if(root){root.x=W/2;root.y=H/2;root.fixed=true}papers.forEach((n,k)=>{let a=(Math.PI*2*k/Math.max(1,papers.length))-Math.PI/2,r=130+35*(k%3);n.x=W/2+r*Math.cos(a);n.y=H/2+r*Math.sin(a)});entities.forEach((n,k)=>{let a=(Math.PI*2*k/Math.max(1,entities.length))+0.37,r=285+55*(k%4);n.x=W/2+r*Math.cos(a);n.y=H/2+r*Math.sin(a)});KG.steps=0}
function kgRadius(n){if(n.type==='paper')return 8+Math.min(7,Math.log1p(n.cites||0)*1.15);if(n.type==='query'||n.root)return 18;if(n.type==='journal')return 11;if(n.type==='author')return 9;if(n.type==='keyword')return 7+Math.min(4,Math.log1p(n.weight||1));return 7+Math.min(3,Math.log1p(n.weight||1))}
function kgResize(){if(!KG.canvas)return;let rect=KG.canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);KG.canvas.width=Math.max(300,Math.floor(rect.width*dpr));KG.canvas.height=Math.max(300,Math.floor(rect.height*dpr));KG.ctx.setTransform(dpr,0,0,dpr,0,0);kgDraw()}
function kgStep(){let ns=KG.nodes,es=KG.edges,N=ns.length;let rep=N>180?4200:6000;for(let i=0;i<N;i++){let a=ns[i];if(a.fixed)continue;let fx=0,fy=0;for(let j=0;j<N;j++){if(i===j)continue;let b=ns[j],dx=a.x-b.x,dy=a.y-b.y,d2=dx*dx+dy*dy+90;let f=rep/d2;fx+=dx*f;fy+=dy*f}a.vx=(a.vx+fx*.012)*.86;a.vy=(a.vy+fy*.012)*.86}
 es.forEach(e=>{let a=e.a,b=e.b,dx=b.x-a.x,dy=b.y-a.y,d=Math.sqrt(dx*dx+dy*dy)||1;let target=e.relation==='matched search'?145:(e.relation==='related paper'?115:88);let f=(d-target)*.006,fx=dx/d*f,fy=dy/d*f;if(!a.fixed){a.vx+=fx;a.vy+=fy}if(!b.fixed){b.vx-=fx;b.vy-=fy}});
 ns.forEach(n=>{if(n.fixed)return;n.vx+=(550-n.x)*.00055;n.vy+=(320-n.y)*.00055;n.x+=n.vx;n.y+=n.vy});KG.steps++}
function kgWorldToScreen(x,y){return{x:x*KG.scale+KG.tx,y:y*KG.scale+KG.ty}}
function kgScreenToWorld(x,y){return{x:(x-KG.tx)/KG.scale,y:(y-KG.ty)/KG.scale}}
function kgDraw(){
 if(!KG.ctx||!KG.canvas)return;
 const ctx=KG.ctx,rect=KG.canvas.getBoundingClientRect();
 ctx.clearRect(0,0,rect.width,rect.height);
 // Subtle graph-paper background helps distinguish the canvas from an empty panel.
 ctx.save();
 ctx.fillStyle='#ffffff';ctx.fillRect(0,0,rect.width,rect.height);
 ctx.strokeStyle='rgba(148,163,184,.10)';ctx.lineWidth=1;
 const grid=32;
 for(let x=0;x<rect.width;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,rect.height);ctx.stroke()}
 for(let y=0;y<rect.height;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(rect.width,y);ctx.stroke()}
 ctx.restore();
 ctx.save();ctx.translate(KG.tx,KG.ty);ctx.scale(KG.scale,KG.scale);ctx.lineCap='round';
 // Edges first, so nodes remain above them. Use distinct relation colours and line widths.
 KG.edges.forEach(e=>{
   const rel=String(e.relation||'related');
   ctx.beginPath();ctx.moveTo(e.a.x,e.a.y);ctx.lineTo(e.b.x,e.b.y);
   ctx.strokeStyle=rel==='related paper'?'rgba(109,40,217,.62)':rel==='matched search'?'rgba(24,78,119,.48)':'rgba(15,118,110,.52)';
   ctx.lineWidth=(rel==='related paper'?2.2:1.5)/Math.max(.7,KG.scale);
   ctx.stroke();
   // Direction indicator makes subject–predicate–object flow easier to read.
   const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1;
   const rr=kgRadius(e.b)+2,ax=e.b.x-dx/d*rr,ay=e.b.y-dy/d*rr;
   const ang=Math.atan2(dy,dx),ah=5/Math.max(.7,KG.scale);
   ctx.beginPath();ctx.moveTo(ax,ay);
   ctx.lineTo(ax-ah*Math.cos(ang-.48),ay-ah*Math.sin(ang-.48));
   ctx.moveTo(ax,ay);ctx.lineTo(ax-ah*Math.cos(ang+.48),ay-ah*Math.sin(ang+.48));
   ctx.strokeStyle='rgba(71,85,105,.75)';ctx.lineWidth=1.25/Math.max(.7,KG.scale);ctx.stroke();
   if(KG.showEdgeLabels&&KG.scale>.42){
     const mx=(e.a.x+e.b.x)/2,my=(e.a.y+e.b.y)/2,txt=rel;
     ctx.font='600 10px system-ui';const w=ctx.measureText(txt).width;
     ctx.fillStyle='rgba(255,255,255,.96)';ctx.fillRect(mx-w/2-4,my-8,w+8,15);
     ctx.strokeStyle='rgba(203,213,225,.9)';ctx.lineWidth=.7;ctx.strokeRect(mx-w/2-4,my-8,w+8,15);
     ctx.fillStyle='#334155';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(txt,mx,my-.5);
   }
 });
 // Draw every entity as a substantial node and label every node by default.
 KG.nodes.forEach(n=>{
   const r=Math.max(8,kgRadius(n)+(n.type==='paper'?2:3));
   const col=KG_COLORS[n.type]||'#64748b';
   ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);
   ctx.fillStyle=col;ctx.fill();
   ctx.strokeStyle=KG.selected===n?'#111827':(KG.hover===n?'#ffffff':'rgba(255,255,255,.98)');
   ctx.lineWidth=(KG.selected===n?4:2.5)/Math.max(.65,KG.scale);ctx.stroke();
   if(KG.selected===n){ctx.beginPath();ctx.arc(n.x,n.y,r+5,0,Math.PI*2);ctx.strokeStyle='#f59e0b';ctx.lineWidth=2/Math.max(.65,KG.scale);ctx.stroke()}
   const raw=n.type==='paper'?((n.rank?n.rank+'. ':'')+n.label):n.label;
   const label=String(raw||KG_NAMES[n.type]||n.type);
   // Always label nodes at normal zoom; shorten only long titles to avoid obscuring the graph.
   if(KG.scale>.34){
     const maxChars=n.type==='paper'?30:24;
     const shown=label.length>maxChars?label.slice(0,maxChars-1)+'…':label;
     const fs=n.type==='query'||n.root?12:(n.type==='paper'?10.5:10.5);
     ctx.font=(n.type==='query'||n.root?'700 ':'600 ')+fs+'px system-ui';
     ctx.textAlign='center';ctx.textBaseline='top';
     const tw=ctx.measureText(shown).width,ly=n.y+r+4,pad=4;
     ctx.fillStyle='rgba(255,255,255,.97)';
     ctx.fillRect(n.x-tw/2-pad,ly-2,tw+pad*2,15);
     ctx.strokeStyle='rgba(203,213,225,.9)';ctx.lineWidth=.7;ctx.strokeRect(n.x-tw/2-pad,ly-2,tw+pad*2,15);
     ctx.fillStyle='#172b45';ctx.fillText(shown,n.x,ly);
   }
 });
 ctx.restore();
}
function kgAnimate(){kgStep();kgDraw();if(KG.steps<260||KG.drag)KG.anim=requestAnimationFrame(kgAnimate)}
function kgFit(){if(!KG.nodes.length)return;let xs=KG.nodes.map(n=>n.x),ys=KG.nodes.map(n=>n.y),minx=Math.min(...xs)-60,maxx=Math.max(...xs)+60,miny=Math.min(...ys)-60,maxy=Math.max(...ys)+60,rect=KG.canvas.getBoundingClientRect();let sc=Math.min(rect.width/(maxx-minx),rect.height/(maxy-miny),1.35);KG.scale=Math.max(.22,sc);KG.tx=(rect.width-(minx+maxx)*KG.scale)/2;KG.ty=(rect.height-(miny+maxy)*KG.scale)/2;kgDraw()}
function kgHit(sx,sy){let w=kgScreenToWorld(sx,sy),best=null,bd=1e9;for(let n of KG.nodes){let dx=w.x-n.x,dy=w.y-n.y,d=Math.sqrt(dx*dx+dy*dy);if(d<kgRadius(n)+8/KG.scale&&d<bd){best=n;bd=d}}return best}
function kgSelectionHtml(n){if(!n)return '<div class="tiny">Click a node to inspect its metadata relationships. Drag nodes to reposition them; drag empty space to pan; use the mouse wheel or trackpad to zoom.</div>';let links=KG.edges.filter(e=>e.a===n||e.b===n).slice(0,30);if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';let body=`<div class="kg-node-title">${esc(n.label)}</div><div class="badges"><span class="badge">${esc(KG_NAMES[n.type]||n.type)}</span>${n.type==='paper'?`<span class="badge cites">Cited ${Number(n.cites||0).toLocaleString()}×</span>`:''}${KG.edges.filter(e=>e.a===n||e.b===n).length>1?`<span class="badge">${KG.edges.filter(e=>e.a===n||e.b===n).length} links</span>`:''}${safeUrl(n.url)?'<span class="badge access">URL</span>':''}</div>`;
 body+=kgNodeLinkHtml(n);if(n.description)body+=`<div class="evidence-quote">${esc(n.description)}</div>`;if(n.type==='paper'){let o=recObj(n.paperIndex);body+=`<div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)}</div><div class="actions"><button class="primary" id="kgDetails">Record details</button><button id="kgSingle">Focus graph</button>${safeUrl(n.url)?`<a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a>`:''}</div>`}else if(['journal','publisher','place','year','keyword','author'].includes(n.type)){body+=`<div class="actions"><button class="ghost kg-search-node" id="kgSearchNode">Search / filter by this ${esc(KG_NAMES[n.type]||n.type).toLowerCase()}</button>${safeUrl(n.url)?`<a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a>`:''}</div>`}else if(safeUrl(n.url)){body+=`<div class="actions"><a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a></div>`}
 body+=`<h4>Relationships (${links.length}${KG.edges.filter(e=>e.a===n||e.b===n).length>30?'+':''})</h4><div class="kg-rel-list">`+links.map(e=>{let other=e.a===n?e.b:e.a;if(!other.url)other.url=nodeUrlFor(other.type,other.label,other.paperIndex!==undefined?recObj(other.paperIndex):null)||'';return `<div class="kg-rel"><b>${esc(e.rev&&e.b===n?e.rev:e.relation)}</b>${esc(other.label)}${e.detail?`<div class="tiny">${esc(e.detail)}</div>`:''}${safeUrl(other.url)?`<div class="tiny"><a href="${esc(safeUrl(other.url))}" target="_blank" rel="noopener">URL ↗</a></div>`:''}</div>`}).join('')+'</div>';return body}
function kgSelect(n){KG.selected=n;$('#kgSelection').innerHTML=kgSelectionHtml(n);if(n&&n.type==='paper'){$('#kgDetails').onclick=()=>detail(n.paperIndex);$('#kgSingle').onclick=()=>graph(n.paperIndex)}else if(n&&['journal','publisher','place','year','keyword','author'].includes(n.type)&&$('#kgSearchNode')){$('#kgSearchNode').onclick=()=>kgSearchByNode(n)}kgDraw()}
function kgSearchByNode(n){closeModal();state.savedOnly=false;state.advanced=[];$('#advRows').innerHTML='';addAdvRow();if(n.type==='journal'){let idx=S.findIndex(x=>norm(x)===norm(n.label));if(idx>=0){state.source=String(idx);$('#sourceFilter').value=state.source}}else if(n.type==='publisher'){let idx=PUB.findIndex(x=>norm(x)===norm(n.label));if(idx>=0){state.publisher=String(idx);$('#publisherFilter').value=state.publisher}}else if(n.type==='place'){state.query='"'+n.label+'"';$('#q').value=state.query}else if(n.type==='year'){state.yearSet=new Set([Number(n.label)]);$$('[data-year]').forEach(x=>x.checked=Number(x.dataset.year)===Number(n.label))}else if(n.type==='keyword'){state.query='"'+n.label+'"';$('#q').value=state.query}else if(n.type==='author'){state.query='"'+n.label+'"';$('#q').value=state.query}state.page=1;doSearch()}
function kgBindCanvas(){let c=KG.canvas,tip=$('#kgTooltip');const pos=e=>{let r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};c.onpointerdown=e=>{let p=pos(e),n=kgHit(p.x,p.y);c.setPointerCapture(e.pointerId);if(n){KG.drag={n,p};n.fixed=true;kgSelect(n)}else KG.pan={x:p.x,y:p.y,tx:KG.tx,ty:KG.ty};c.classList.add('dragging')};c.onpointermove=e=>{let p=pos(e);if(KG.drag){let w=kgScreenToWorld(p.x,p.y);KG.drag.n.x=w.x;KG.drag.n.y=w.y;KG.drag.n.vx=KG.drag.n.vy=0;kgDraw();return}if(KG.pan){KG.tx=KG.pan.tx+(p.x-KG.pan.x);KG.ty=KG.pan.ty+(p.y-KG.pan.y);kgDraw();return}let n=kgHit(p.x,p.y);KG.hover=n;if(n){tip.style.display='block';tip.style.left=Math.min(p.x+12,c.clientWidth-290)+'px';tip.style.top=Math.max(6,p.y-8)+'px';if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';tip.innerHTML=`<b>${esc(KG_NAMES[n.type]||n.type)}</b><br>${esc(n.label)}${n.type==='paper'?`<br>Cited ${Number(n.cites||0).toLocaleString()}×`:''}${safeUrl(n.url)?`<br><span style="opacity:.9">URL: ${esc(n.url.length>60?n.url.slice(0,58)+'…':n.url)}</span>`:''}`}else tip.style.display='none';kgDraw()};c.onpointerup=e=>{if(KG.drag){if(KG.drag.n.type!=='query')KG.drag.n.fixed=false;KG.drag=null}KG.pan=null;c.classList.remove('dragging');KG.steps=Math.min(KG.steps,220);if(KG.steps<260){cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate)}};c.onpointerleave=()=>{KG.hover=null;tip.style.display='none';kgDraw()};c.ondblclick=e=>{let p=pos(e),n=kgHit(p.x,p.y);if(n){kgSelect(n);if(n.type==='paper')detail(n.paperIndex)}};c.onwheel=e=>{e.preventDefault();let p=pos(e),before=kgScreenToWorld(p.x,p.y),factor=e.deltaY<0?1.12:.89;KG.scale=Math.max(.18,Math.min(3.2,KG.scale*factor));KG.tx=p.x-before.x*KG.scale;KG.ty=p.y-before.y*KG.scale;kgDraw()}}
function kgStats(){let counts={};KG.nodes.forEach(n=>counts[n.type]=(counts[n.type]||0)+1);return `<div class="kg-statgrid"><div class="kg-stat"><b>${KG.nodes.length}</b><span>nodes</span></div><div class="kg-stat"><b>${KG.edges.length}</b><span>relationships</span></div><div class="kg-stat"><b>${counts.paper||0}</b><span>papers</span></div><div class="kg-stat"><b>${KG.edges.filter(e=>e.relation==='related paper').length}</b><span>paper links</span></div></div>`}
function kgLegend(){return Object.entries(KG_NAMES).filter(([k])=>k!=='query').map(([k,v])=>`<div class="kg-leg"><span class="kg-dot" style="background:${KG_COLORS[k]}"></span>${esc(v)}</div>`).join('')}
function kgOpen(hits,mode='results',focusIndex=null){if(!hits.length){toast('No results available for graph');return}KG.mode=mode;KG.baseHits=hits;KG.focusIndex=focusIndex;let isSingle=mode==='single';let defaultLimit=isSingle?Math.min(12,hits.length):Math.min(20,hits.length);$('#modalCard').classList.add('graph-modal-card');showModal(`<h2>${isSingle?'Record knowledge graph':'Search Results Knowledge Graph'}</h2><p class="tiny">Select a <b>Knowledge Graph construction model</b> from the toolbar. Each model applies a different appropriate schema and edge rules (bibliographic metadata, co-authorship network, concept co-occurrence, publishing ecosystem, temporal impact, or NER entities). Citation-reference edges are not shown because individual reference lists are not present in the dataset.</p><div class="kg-toolbar"><label>KG Model <select id="kgModel">${Object.values(KG_MODELS).map(m=>`<option value="${m.id}">${m.label}</option>`).join('')}</select></label>${isSingle?'':`<label>Top results <select id="kgLimit"><option>10</option><option selected>20</option><option>30</option><option>40</option></select></label>`}<label><input type="checkbox" class="kgType" value="author" checked>Authors</label><label><input type="checkbox" class="kgType" value="journal" checked>Journals</label><label><input type="checkbox" class="kgType" value="keyword" checked>Keywords</label><label><input type="checkbox" class="kgType" value="publisher" checked>Publishers</label><label><input type="checkbox" class="kgType" value="place" checked>Places</label><label><input type="checkbox" class="kgType" value="year" checked>Years</label><label><input type="checkbox" class="kgType" value="doi" checked>DOIs</label><label><input type="checkbox" class="kgType" value="url" checked>URLs</label><label><input type="checkbox" id="kgEdgeLabels">Edge labels</label><span class="spacer"></span><button class="ghost" id="kgFit">Fit</button><button class="ghost" id="kgReset">Re-layout</button><button class="ghost" id="kgPng">Save PNG</button></div><div class="kg-layout"><div class="kg-stage"><canvas id="kgCanvas" aria-label="Interactive bibliographic knowledge graph"></canvas><div class="kg-tooltip" id="kgTooltip"></div></div><aside class="kg-side"><h3>Graph summary</h3><div id="kgStats"></div><h4>Selected node</h4><div id="kgSelection"></div><h4>Node types</h4><div class="kg-legend">${kgLegend()}</div><h4>Model description</h4><div class="kg-edge-key" id="kgModelDesc" style="font-size:12px;color:var(--muted);margin-bottom:8px"></div><h4>Relationship meanings</h4><div class="kg-edge-key" id="kgEdgeKey"><b>matched search</b> — paper is in the selected search result set<br><b>authored by</b> — author metadata<br><b>published in</b> — journal/source metadata<br><b>has keyword</b> — keyword metadata<br><b>published by</b> — publisher metadata<br><b>associated country</b> — country field<br><b>published in year</b> — year field<br><b>related paper</b> — strong overlap through shared author and/or multiple shared keywords</div><div class="kg-note">The graph does not claim that metadata proximity is a citation relationship.</div></aside></div>`);
 const rebuild=()=>{
  const modelId = ($('#kgModel')&&$('#kgModel').value) || 'bibliographic';
  const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
  let types = new Set($$('.kgType:checked').map(x=>x.value));
  const limit = isSingle ? hits.length : Number($('#kgLimit')?.value||defaultLimit);
  const g = kgBuildByModel(hits, modelId, {limit, types, includeSearchRoot:!isSingle});
  KG.nodes = g.nodes; KG.edges = g.edges;
  KG.nodeMap = new Map(KG.nodes.map(n=>[n.id,n]));
  KG.canvas = $('#kgCanvas'); KG.ctx = KG.canvas.getContext('2d');
  KG.scale=1; KG.tx=0; KG.ty=0; KG.selected=null;
  // Update dynamic help panels
  const keyEl = document.getElementById('kgEdgeKey');
  const descEl = document.getElementById('kgModelDesc');
  if(keyEl) keyEl.innerHTML = model.relations;
  if(descEl) descEl.textContent = model.desc;
  kgInitPositions(); kgResize();
  $('#kgStats').innerHTML = kgStats();
  $('#kgSelection').innerHTML = kgSelectionHtml(null);
  kgBindCanvas();
  cancelAnimationFrame(KG.anim);
  KG.anim = requestAnimationFrame(kgAnimate);
  setTimeout(()=>kgFit(),160);
};
 rebuild();
 $$('.kgType').forEach(x=>x.onchange=rebuild);
 if($('#kgLimit')) $('#kgLimit').onchange=rebuild;
 if($('#kgModel')) $('#kgModel').onchange=rebuild;
 $('#kgEdgeLabels').onchange=e=>{KG.showEdgeLabels=e.target.checked;kgDraw()};
 $('#kgFit').onclick=kgFit;
 $('#kgReset').onclick=()=>{kgInitPositions();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),200)};$('#kgPng').onclick=()=>{kgDraw();let a=document.createElement('a');a.download='library_knowledge_graph.png';a.href=KG.canvas.toDataURL('image/png');a.click()};window.onresize=()=>{if($('#modal').classList.contains('open')&&KG.canvas)kgResize()}}
function graphResults(){if(!currentResults.length){toast('Run a search first');return}kgOpen(currentResults,'results')}
function graph(i){let base=recObj(i),bk=new Set(splitKeywords(base.keywords).map(norm)),ba=new Set(splitAuthors(base.authors).map(norm));let rel=[{i,score:999}];for(let j=0;j<R.length;j++){if(j===i)continue;let o=recObj(j),score=0;if(o.source&&o.source===base.source)score+=2;let oa=splitAuthors(o.authors).map(norm);for(let a of oa)if(ba.has(a)&&a)score+=10;let ok=splitKeywords(o.keywords).map(norm),over=ok.filter(k=>bk.has(k)&&k).length;score+=over*3;if(score>=5)rel.push({i:j,score})}rel.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);kgOpen(rel.slice(0,15),'single',i)}

/* ===== Local Research Intelligence: NER, Hypotheses & Research Gaps ===== */
const RI_METHODS=[
 ['systematic review',/\bsystematic review\b/i],['literature review',/\bliterature review\b/i],['bibliometric analysis',/\bbibliometric|scientometric\b/i],['survey',/\bsurvey|questionnaire\b/i],['interview',/\binterviews?\b/i],['case study',/\bcase stud(?:y|ies)\b/i],['content analysis',/\bcontent analysis\b/i],['thematic analysis',/\bthematic analysis\b/i],['qualitative',/\bqualitative\b/i],['quantitative',/\bquantitative\b/i],['mixed methods',/\bmixed[- ]methods?\b/i],['experiment',/\bexperiment(?:al|s)?\b/i],['machine learning',/\bmachine learning\b/i],['deep learning',/\bdeep learning\b/i],['natural language processing',/\bnatural language processing|\bNLP\b/i],['network analysis',/\bnetwork analysis\b/i],['regression',/\bregression\b/i],['SEM',/\bstructural equation model(?:ing|ling)?|\bSEM\b/i],['focus group',/\bfocus groups?\b/i],['ethnography',/\bethnograph(?:y|ic)\b/i],['simulation',/\bsimulation\b/i]
];
const RI_GAP_CUES=[/\bresearch gap\b/i,/\black of\b/i,/\blacks?\b/i,/\blimited (?:research|evidence|knowledge|studies|understanding)\b/i,/\bfew studies\b/i,/\blittle (?:research|evidence|attention|is known)\b/i,/\bscarce\b/i,/\bunderexplor(?:ed|ation)\b/i,/\bunderstud(?:ied|y)\b/i,/\bremains? (?:unclear|unknown|unexplored|poorly understood)\b/i,/\bnot (?:yet )?been (?:examined|studied|investigated|explored)\b/i,/\bfuture research\b/i,/\bfurther research\b/i,/\bneed(?:s|ed)? for (?:more|further|additional|future) (?:research|study|studies|investigation)\b/i,/\binsufficient (?:research|evidence|attention|knowledge)\b/i,/\bpoorly understood\b/i,/\bhas received little attention\b/i];
const RI_HYP_CUES=[/\bhypothes(?:is|es|ize|ised|ized)\b/i,/\bwe (?:expect|predict|propose)\b/i,/\bit is (?:expected|hypothesized|hypothesised)\b/i,/\bwe test(?:ed)? whether\b/i];
const RI_ORG_CUES=/\b(?:university|institute|institution|department|centre|center|association|college|school|academy|ministry|council|laboratory|laboratories|agency|foundation|library|libraries|corporation|society)\b/i;
function riScopeHits(focusIndex=null){if(focusIndex!==null&&focusIndex!==undefined)return [{i:Number(focusIndex),score:999,why:[]}];let n=Number($('#riScope')?.value||20);return currentResults.slice(0,n)}
function riSentenceSplit(text){return String(text||'').replace(/\s+/g,' ').split(/(?<=[.!?])\s+(?=[A-Z0-9])/).map(x=>x.trim()).filter(x=>x.length>25)}
function riTopKeywords(hits,max=14){let m=new Map();for(let h of hits){let o=recObj(h.i);for(let k of splitKeywords(o.keywords)){let nk=norm(k);if(!nk||nk.length<3)continue;let e=m.get(nk)||{label:k,count:0,papers:new Set()};if(!e.papers.has(h.i)){e.count++;e.papers.add(h.i)}m.set(nk,e)}}return [...m.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label)).slice(0,max)}
function riMethodsFor(o){let text=(o.title+' '+o.abstract+' '+o.keywords);return RI_METHODS.filter(([,re])=>re.test(text)).map(([name])=>name)}
function riCapOrgCandidates(text){let out=[];for(let sent of riSentenceSplit(text)){if(!RI_ORG_CUES.test(sent))continue;let words=sent.replace(/[(),;:]/g,' ').split(/\s+/);for(let i=0;i<words.length;i++){if(!RI_ORG_CUES.test(words[i]))continue;let a=Math.max(0,i-5),b=Math.min(words.length,i+2),p=words.slice(a,b).join(' ').replace(/^[^A-Z]+/,'').trim();if(p.length>=5&&p.length<=100)out.push(p)}}return [...new Set(out)].slice(0,8)}
function riNER(hits){let cats={person:new Map(),organization:new Map(),location:new Map(),journal:new Map(),identifier:new Map(),concept:new Map(),method:new Map()};let add=(cat,label,pi,source='metadata')=>{label=String(label||'').trim();if(!label)return;let key=norm(label),m=cats[cat],e=m.get(key)||{label,count:0,papers:new Set(),source};e.count++;e.papers.add(pi);m.set(key,e)};
 for(let h of hits){let o=recObj(h.i);splitAuthors(o.authors).forEach(x=>add('person',x,h.i));if(o.publisher)add('organization',o.publisher,h.i);if(o.country)add('location',o.country,h.i);if(o.place)add('location',o.place,h.i);if(o.source)add('journal',o.source,h.i);if(o.doi)add('identifier','DOI: '+o.doi,h.i);if(o.issn)add('identifier','ISSN: '+o.issn,h.i);splitKeywords(o.keywords).slice(0,14).forEach(x=>add('concept',x,h.i));riMethodsFor(o).forEach(x=>add('method',x,h.i));riCapOrgCandidates((o.title||'')+' '+(o.abstract||'')).forEach(x=>add('organization',x,h.i,'heuristic text'))}
 let sorted={};for(let [k,m] of Object.entries(cats))sorted[k]=[...m.values()].sort((a,b)=>b.papers.size-a.papers.size||a.label.localeCompare(b.label));return sorted}
function riNERGraph(hits,ner){let root={id:'ner-root',type:'nerRoot',label:'Named Entity Recognition',root:true,weight:hits.length,description:'Entity graph derived from structured bibliographic metadata plus conservative local text patterns.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let addNode=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,relation,detail='')=>{let k=a.id+'|'+b.id+'|'+relation;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation,detail})};
 for(let h of hits){let o=recObj(h.i),p=addNode('paper|'+h.i,'paper',o.title,{paperIndex:h.i,cites:o.cites,year:o.year,source:o.source,rank:nodes.filter(x=>x.type==='paper').length+1,url:nodeUrlFor('paper',o.title,o)});edge(root,p,'analyzes paper');splitAuthors(o.authors).slice(0,5).forEach(v=>edge(p,addNode('author|'+norm(v),'author',v),'mentions person'));if(o.publisher)edge(p,addNode('org|'+norm(o.publisher),'organization',o.publisher),'published by');if(o.country)edge(p,addNode('loc|'+norm(o.country),'location',o.country),'associated location');if(o.source)edge(p,addNode('journal|'+norm(o.source),'journal',o.source),'published in');splitKeywords(o.keywords).slice(0,7).forEach(v=>edge(p,addNode('concept|'+norm(v),'concept',v),'mentions concept'));riMethodsFor(o).slice(0,4).forEach(v=>edge(p,addNode('method|'+norm(v),'method',v),'uses / mentions method'))}
 return {nodes,edges}}
function riPairs(hits,limitConcepts=12){let tops=riTopKeywords(hits,limitConcepts),allowed=new Map(tops.map(x=>[norm(x.label),x.label])),pairs=new Map();for(let h of hits){let ks=[...new Set(splitKeywords(recObj(h.i).keywords).map(norm).filter(k=>allowed.has(k)))];for(let a=0;a<ks.length;a++)for(let b=a+1;b<ks.length;b++){let x=ks[a]<ks[b]?ks[a]+'§'+ks[b]:ks[b]+'§'+ks[a],e=pairs.get(x)||{a:allowed.get(ks[a]),b:allowed.get(ks[b]),count:0,papers:[]};e.count++;e.papers.push(h.i);pairs.set(x,e)}}return {tops,pairs:[...pairs.values()].sort((a,b)=>b.count-a.count)}}
function riExplicitHypotheses(hits){let out=[];for(let h of hits){let o=recObj(h.i);for(let s of riSentenceSplit(o.abstract)){if(RI_HYP_CUES.some(re=>re.test(s)))out.push({paper:h.i,text:s})}}return out.slice(0,10)}
function riHypotheses(hits){let {tops,pairs}=riPairs(hits),explicit=riExplicitHypotheses(hits),hyps=[];if(hits.length===1){let ks=splitKeywords(recObj(hits[0].i).keywords).filter(Boolean).slice(0,5);for(let j=1;j<Math.min(ks.length,4);j++)hyps.push({type:'Single-record concept proposition',statement:`A future empirical study can test whether “${ks[0]}” is associated with “${ks[j]}” in a clearly defined population and context.`,null:`No statistically detectable association exists between “${ks[0]}” and “${ks[j]}” in the defined target context.`,concepts:[ks[0],ks[j]],papers:[hits[0].i],support:1,confidence:'low'});}else{for(let p of pairs.filter(x=>x.count>=2).slice(0,5)){hyps.push({type:'Association',statement:`There is a testable association between “${p.a}” and “${p.b}” in the research context represented by the selected literature.`,null:`There is no statistically detectable association between “${p.a}” and “${p.b}” in the target empirical context.`,concepts:[p.a,p.b],papers:p.papers.slice(0,6),support:p.count,confidence:p.count>=4?'high':'medium'})}if(tops.length){let k=tops[0];hyps.push({type:'Temporal / corpus pattern',statement:`The prominence of “${k.label}” differs across publication years within the selected bibliographic corpus.`,null:`The prominence of “${k.label}” does not differ meaningfully across publication years in the selected corpus.`,concepts:[k.label],papers:[...k.papers].slice(0,6),support:k.count,confidence:'medium'})}}return {hyps:hyps.slice(0,6),explicit,tops}}
function riHypGraph(hits,data){let root={id:'hyp-root',type:'hypRoot',label:'Hypothesis Generator',root:true,description:'Alternative hypotheses generated from keyword co-occurrence. They are proposals for testing, not findings.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};data.hyps.forEach((h,ix)=>{let hn=add('hyp|'+ix,'hypothesis','H'+(ix+1)+': '+h.statement,{description:h.null});edge(root,hn,'generates candidate');h.concepts.forEach(c=>edge(hn,add('concept|'+norm(c),'concept',c),'tests concept'));h.papers.forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(hn,p,'grounded in co-occurrence',h.support+' supporting records')})});return {nodes,edges}}
function riExplicitGaps(hits){let out=[];for(let h of hits){let o=recObj(h.i);for(let s of riSentenceSplit(o.abstract)){let cues=RI_GAP_CUES.filter(re=>re.test(s));if(cues.length)out.push({paper:h.i,text:s,score:cues.length+(s.length<260?1:0)})}}out.sort((a,b)=>b.score-a.score);let ded=[],seen=new Set();for(let x of out){let k=norm(x.text).slice(0,130);if(seen.has(k))continue;seen.add(k);ded.push(x);if(ded.length>=12)break}return ded}
function riGapAnalysis(hits){let explicit=riExplicitGaps(hits),{tops,pairs}=riPairs(hits,10),gaps=[];
 explicit.slice(0,6).forEach((e,ix)=>{let o=recObj(e.paper);gaps.push({type:'Explicit gap statement',statement:e.text,papers:[e.paper],concepts:splitKeywords(o.keywords).slice(0,3),confidence:'high',basis:'Gap-indicating language found directly in the source abstract.'})});
 // Underexplored intersections: individually visible concepts with rare co-occurrence
 let freq=new Map(tops.map(x=>[norm(x.label),x]));let co=new Map(pairs.map(p=>[[norm(p.a),norm(p.b)].sort().join('§'),p]));for(let a=0;a<tops.length;a++)for(let b=a+1;b<tops.length;b++){let A=tops[a],B=tops[b];if(A.count<3||B.count<3)continue;let p=co.get([norm(A.label),norm(B.label)].sort().join('§')),c=p?.count||0;if(c<=1)gaps.push({type:'Underexplored concept intersection',statement:`“${A.label}” and “${B.label}” are each visible in the selected corpus but rarely occur together (${c} co-occurring record${c===1?'':'s'}). This is a candidate intersection for targeted investigation.`,papers:[...(A.papers)].slice(0,2).concat([...(B.papers)].slice(0,2)),concepts:[A.label,B.label],confidence:'medium',basis:'Corpus co-occurrence signal; not proof of a global literature gap.'})}
 let methodCounts=new Map();for(let h of hits)for(let m of riMethodsFor(recObj(h.i)))methodCounts.set(m,(methodCounts.get(m)||0)+1);let methods=[...methodCounts].sort((a,b)=>b[1]-a[1]);if(hits.length>=8&&methods.length){let rare=methods.filter(x=>x[1]<=Math.max(1,Math.floor(hits.length*.08))).slice(0,2),dominant=methods[0];rare.forEach(([m,c])=>gaps.push({type:'Methodological opportunity',statement:`The selected corpus is led by “${dominant[0]}” mentions (${dominant[1]} records), while “${m}” appears in only ${c}. A study using or comparing this less-represented method could test whether conclusions are method-sensitive.`,papers:hits.filter(h=>riMethodsFor(recObj(h.i)).includes(m)).slice(0,4).map(h=>h.i),concepts:[m,dominant[0]],confidence:'medium',basis:'Method-term distribution in titles, abstracts and keywords.'}))}
 let countries=new Map();for(let h of hits){let c=recObj(h.i).country;if(c)countries.set(c,(countries.get(c)||0)+1)}let cs=[...countries].sort((a,b)=>b[1]-a[1]);if(hits.length>=10&&cs.length&&cs[0][1]/hits.length>=.55)gaps.push({type:'Geographic concentration signal',statement:`${cs[0][1]} of ${hits.length} analyzed records carry “${cs[0][0]}” in the dataset country field. Comparative work across less-represented geographic contexts may strengthen external validity.`,papers:hits.filter(h=>recObj(h.i).country===cs[0][0]).slice(0,4).map(h=>h.i),concepts:[cs[0][0]],confidence:'medium',basis:'Bibliographic country metadata; it may describe publication metadata rather than the empirical study location.'});
 let seen=new Set();gaps=gaps.filter(g=>{let k=norm(g.statement).slice(0,150);if(seen.has(k))return false;seen.add(k);return true});return {gaps:gaps.slice(0,10),explicit,tops,methods,countries:cs}}
function riGapGraph(hits,data){let root={id:'gap-root',type:'gapRoot',label:'Research Gap Finder',root:true,description:'Gap signals are grounded in abstract wording or corpus coverage patterns; they require researcher validation.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};data.gaps.forEach((g,ix)=>{let gn=add('gap|'+ix,'gap',(ix+1)+'. '+g.type,{description:g.statement});edge(root,gn,'identifies signal',g.confidence+' confidence');g.concepts.slice(0,4).forEach(c=>edge(gn,add('concept|'+norm(c),'concept',c),'concerns concept'));g.papers.slice(0,5).forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(gn,p,'evidenced by')})});return {nodes,edges}}
function riCombinedGraph(hits){let ner=riNER(hits),hyp=riHypotheses(hits),gap=riGapAnalysis(hits),root={id:'ri-root',type:'query',label:'Research Intelligence: '+(state.query||'Current Results'),root:true,description:'Combined exploratory graph: papers, bibliographic entities, generated hypotheses and corpus-supported gap signals.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};
 hits.slice(0,20).forEach((h,rank)=>{let o=recObj(h.i),p=add('paper|'+h.i,'paper',o.title,{paperIndex:h.i,cites:o.cites,year:o.year,source:o.source,rank:rank+1,url:nodeUrlFor('paper',o.title,o)});edge(root,p,'analyzes paper');splitAuthors(o.authors).slice(0,3).forEach(v=>edge(p,add('author|'+norm(v),'author',v),'authored by'));splitKeywords(o.keywords).slice(0,4).forEach(v=>edge(p,add('concept|'+norm(v),'concept',v),'has concept'));riMethodsFor(o).slice(0,2).forEach(v=>edge(p,add('method|'+norm(v),'method',v),'mentions method'))});
 hyp.hyps.slice(0,4).forEach((h,i)=>{let hn=add('hyp|'+i,'hypothesis','H'+(i+1)+': '+h.statement,{description:h.null});edge(root,hn,'generates hypothesis');h.concepts.forEach(c=>edge(hn,add('concept|'+norm(c),'concept',c),'tests concept'))});gap.gaps.slice(0,5).forEach((g,i)=>{let gn=add('gap|'+i,'gap','Gap '+(i+1)+': '+g.type,{description:g.statement});edge(root,gn,'identifies gap signal');g.concepts.slice(0,3).forEach(c=>edge(gn,add('concept|'+norm(c),'concept',c),'concerns concept'));g.papers.slice(0,3).forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(gn,p,'evidenced by')})});return {nodes,edges,ner,hyp,gap}}
function riGenericGraph(g,title,description,relations){if(!g.nodes?.length)return;$('#modalCard').classList.add('graph-modal-card');showModal(`<h2>${esc(title)}</h2><p class="tiny">${description}</p><div class="kg-toolbar"><label><input type="checkbox" id="kgEdgeLabels" checked> Relationship labels</label><span class="spacer"></span><button class="ghost" id="kgFit">Fit</button><button class="ghost" id="kgReset">Re-layout</button><button class="ghost" id="kgPng">Save PNG</button></div><div class="kg-layout"><div class="kg-stage"><canvas id="kgCanvas" aria-label="Interactive research intelligence knowledge graph"></canvas><div class="kg-tooltip" id="kgTooltip"></div></div><aside class="kg-side"><h3>Graph summary</h3><div id="kgStats"></div><h4>Selected node</h4><div id="kgSelection"></div><h4>Node types</h4><div class="kg-legend">${kgLegend()}</div><h4>Relationship meanings</h4><div class="kg-edge-key">${relations}</div><div class="kg-note">Automatic outputs are research-assistance signals. Validate hypotheses and gap interpretations against the cited papers and, where needed, a wider systematic literature search.</div></aside></div>`);KG.nodes=g.nodes;KG.edges=g.edges;KG.nodeMap=new Map(KG.nodes.map(n=>[n.id,n]));KG.canvas=$('#kgCanvas');KG.ctx=KG.canvas.getContext('2d');KG.scale=1;KG.tx=0;KG.ty=0;KG.selected=null;KG.showEdgeLabels=true;kgInitPositions();kgResize();$('#kgStats').innerHTML=kgStats();$('#kgSelection').innerHTML=kgSelectionHtml(null);kgBindCanvas();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),180);$('#kgEdgeLabels').onchange=e=>{KG.showEdgeLabels=e.target.checked;kgDraw()};$('#kgFit').onclick=kgFit;$('#kgReset').onclick=()=>{kgInitPositions();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),200)};$('#kgPng').onclick=()=>{kgDraw();let a=document.createElement('a');a.download='research_intelligence_graph.png';a.href=KG.canvas.toDataURL('image/png');a.click()};window.onresize=()=>{if($('#modal').classList.contains('open')&&KG.canvas)kgResize()}}
function riEntityCount(ner){return Object.values(ner).reduce((a,x)=>a+x.length,0)}
function riEntitySection(title,arr,max=18){if(!arr?.length)return '';return `<div class="ri-section"><h3>${esc(title)}</h3><div class="entity-grid">${arr.slice(0,max).map(e=>`<span class="entity-chip"><b>${esc(e.label)}</b> <span class="tiny">${e.papers.size} paper${e.papers.size===1?'':'s'}</span></span>`).join('')}</div></div>`}
function riNERModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let ner=riNER(hits),g=riNERGraph(hits,ner);if(graphOnly){riGenericGraph(g,'NER Knowledge Graph','Named entities are linked to the papers in which they occur. Structured bibliographic fields are treated as high-confidence entities; selected organization patterns from text are heuristic.','<b>analyzes paper</b> — record included in NER scope<br><b>mentions person / concept / method</b> — entity occurs in bibliographic text<br><b>published by / published in</b> — explicit metadata relationship<br><b>associated location</b> — dataset place/country metadata');return}showModal(`<div class="ri-modal-title"><h2>◈ Named Entity Recognition</h2><span class="ri-badge heuristic">Local bibliographic NER</span></div><div class="ri-warning"><b>Method note:</b> Authors, journal, publisher, place/country, DOI/ISSN and keywords come directly from structured dataset fields. Method/technology terms and selected organization phrases are extracted locally with conservative rules; they should be treated as candidate entities.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${riEntityCount(ner)}</b><span>unique entities</span></div><div class="ri-kpi"><b>${ner.person.length}</b><span>persons/authors</span></div><div class="ri-kpi"><b>${ner.concept.length}</b><span>concepts/keywords</span></div></div><div class="ri-actions"><button class="primary ner" id="nerGraphBtn">Open NER knowledge graph</button></div>${riEntitySection('Persons / Authors',ner.person)}${riEntitySection('Organizations / Publishers',ner.organization)}${riEntitySection('Locations',ner.location)}${riEntitySection('Journals / Sources',ner.journal)}${riEntitySection('Research concepts',ner.concept)}${riEntitySection('Methods / Technologies',ner.method)}${riEntitySection('Identifiers',ner.identifier,12)}`);$('#nerGraphBtn').onclick=()=>riNERModal(focusIndex,true)}
function riHypModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let d=riHypotheses(hits),g=riHypGraph(hits,d);if(graphOnly){riGenericGraph(g,'Hypothesis Knowledge Graph','Alternative hypotheses are linked to concepts and the records whose keyword co-occurrence generated them.','<b>generates candidate</b> — locally generated testable proposition<br><b>tests concept</b> — variable/concept used in the hypothesis<br><b>grounded in co-occurrence</b> — papers where the concepts co-occur');return}showModal(`<div class="ri-modal-title"><h2>H₁ Hypothesis Generator</h2><span class="ri-badge heuristic">Alternative hypotheses</span></div><div class="ri-warning"><b>Interpretation:</b> These are testable research propositions generated from patterns in the selected bibliographic records. Co-occurrence does not establish causality, effect direction, significance, or theoretical validity. Refine variables, population and measures before using a hypothesis in a study.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${d.hyps.length}</b><span>generated hypotheses</span></div><div class="ri-kpi"><b>${d.explicit.length}</b><span>explicit hypothesis cues</span></div><div class="ri-kpi"><b>${d.tops.length}</b><span>core concepts</span></div></div><div class="ri-actions"><button class="primary hyp" id="hypGraphBtn">Open hypothesis knowledge graph</button></div>${d.hyps.map((h,i)=>hypCardHtml(h,i))||'<div class="note">Not enough repeated keyword relationships were found to generate a useful hypothesis from this scope.</div>'}${d.explicit.length?`<div class="ri-section"><h3>Explicit hypothesis cues found in abstracts</h3>${d.explicit.slice(0,5).map(e=>`<div class="evidence-card"><b>${esc(recObj(e.paper).title)}</b><div class="evidence-quote">${esc(e.text)}</div><div class="actions"><button data-ri-detail="${e.paper}">Open record</button></div></div>`).join('')}</div>`:''}`);$('#hypGraphBtn').onclick=()=>riHypModal(focusIndex,true);$$('[data-ri-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.riDetail)))}
function riGapModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let d=riGapAnalysis(hits),g=riGapGraph(hits,d);if(graphOnly){riGenericGraph(g,'Research Gap Knowledge Graph','Gap nodes connect to concepts and evidence papers. High-confidence signals quote explicit gap language; medium-confidence signals are corpus-level opportunities.','<b>identifies signal</b> — automatic gap candidate<br><b>concerns concept</b> — topic/context associated with the gap<br><b>evidenced by</b> — record supporting the gap signal');return}showModal(`<div class="ri-modal-title"><h2>⌁ Research Gap Finder</h2><span class="ri-badge heuristic">Evidence-linked gap signals</span></div><div class="ri-warning"><b>Important:</b> A gap in this dataset is not automatically a gap in the entire scholarly literature. High-confidence items come from explicit gap wording in abstracts. Other items identify underrepresented combinations or methods within the current search corpus and should be validated with a systematic search.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${d.gaps.length}</b><span>gap signals</span></div><div class="ri-kpi"><b>${d.explicit.length}</b><span>explicit gap sentences</span></div><div class="ri-kpi"><b>${d.methods.length}</b><span>methods detected</span></div></div><div class="ri-actions"><button class="primary gap" id="gapGraphBtn">Open research-gap knowledge graph</button></div>${d.gaps.map((g,i)=>`<div class="gap-card"><div class="confidence ${g.confidence}">${esc(g.type)} · ${g.confidence} confidence</div><h3>Gap ${i+1}</h3><div>${esc(g.statement)}</div><div class="evidence-quote"><b>Basis:</b> ${esc(g.basis)}</div><div class="ri-tagrow">${g.concepts.map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}</div>${g.papers.length?`<div class="tiny" style="margin-top:6px">Evidence: ${g.papers.slice(0,3).map(pi=>esc(recObj(pi).title)).join(' • ')}</div>`:''}</div>`).join('')||'<div class="note">No defensible gap signal was detected in this analysis scope. Increase the scope or refine the search.</div>'}`);$('#gapGraphBtn').onclick=()=>riGapModal(focusIndex,true)}
function riAllGraph(){let hits=riScopeHits();if(!hits.length){toast('Run a search first');return}let g=riCombinedGraph(hits);riGenericGraph(g,'Integrated Research Intelligence Knowledge Graph','This combined graph links the current papers to extracted entities/concepts, generated alternative hypotheses and evidence-linked research-gap signals.','<b>analyzes paper</b> — paper in analysis scope<br><b>authored by / has concept / mentions method</b> — bibliographic entity relationship<br><b>generates hypothesis</b> — candidate testable proposition<br><b>identifies gap signal</b> — explicit or corpus-level gap indicator<br><b>evidenced by</b> — source paper supporting the signal')}
/* ── Online Web Resource Search (OpenAlex, Crossref, Wikipedia, DBpedia) ── */
const ONLINE_SOURCES = {
  openalex: { id:'openalex', label:'OpenAlex', desc:'Scholarly works, authors, concepts (open scholarly graph)' },
  crossref: { id:'crossref', label:'Crossref', desc:'DOI registry – bibliographic metadata for journal articles & books' },
  wikipedia: { id:'wikipedia', label:'Wikipedia', desc:'Encyclopedic articles & summaries' },
  dbpedia: { id:'dbpedia', label:'DBpedia', desc:'Structured knowledge base extracted from Wikipedia' }
};

async function onlineFetchJson(url, opts={}){
  const ctrl = new AbortController();
  const t = setTimeout(()=>ctrl.abort(), opts.timeout || 12000);
  try{
    const r = await fetch(url, { signal: ctrl.signal, headers: opts.headers || {} });
    clearTimeout(t);
    if(!r.ok) throw new Error(r.status + ' ' + r.statusText);
    return await r.json();
  }catch(e){
    clearTimeout(t);
    throw e;
  }
}

async function searchOpenAlex(q, limit=8){
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(q)}&per_page=${limit}&mailto=research-explorer@example.com`;
  const data = await onlineFetchJson(url);
  return (data.results || []).map(w=>{
    const authors = (w.authorships || []).slice(0,6).map(a=>a.author?.display_name).filter(Boolean).join('; ');
    const doi = (w.doi || '').replace('https://doi.org/','');
    const year = w.publication_year || '';
    const cites = w.cited_by_count || 0;
    const abstract = w.abstract_inverted_index ? invertOpenAlexAbstract(w.abstract_inverted_index) : '';
    const concepts = (w.concepts || []).slice(0,5).map(c=>c.display_name).join('; ');
    return {
      source:'OpenAlex', sourceId:'openalex',
      title: w.title || w.display_name || 'Untitled',
      authors, year, doi, cites,
      url: w.primary_location?.landing_page_url || w.id || (doi ? 'https://doi.org/'+doi : ''),
      abstract: abstract.slice(0,400),
      keywords: concepts,
      type: w.type || 'work',
      openAccess: !!(w.open_access && w.open_access.is_oa)
    };
  });
}

function invertOpenAlexAbstract(inv){
  if(!inv || typeof inv !== 'object') return '';
  const words = [];
  for(const [word, positions] of Object.entries(inv)){
    for(const p of positions) words[p] = word;
  }
  return words.filter(Boolean).join(' ');
}

async function searchCrossref(q, limit=8){
  const url = `https://api.crossref.org/works?query=${encodeURIComponent(q)}&rows=${limit}`;
  const data = await onlineFetchJson(url);
  return (data.message?.items || []).map(w=>{
    const authors = (w.author || []).slice(0,6).map(a=>[a.given,a.family].filter(Boolean).join(' ')).filter(Boolean).join('; ');
    const year = (w.published?.['date-parts']?.[0]?.[0]) || (w.created?.['date-parts']?.[0]?.[0]) || '';
    const doi = w.DOI || '';
    const title = Array.isArray(w.title) ? w.title[0] : (w.title || 'Untitled');
    const abstract = (w.abstract || '').replace(/<[^>]+>/g,' ').slice(0,400);
    return {
      source:'Crossref', sourceId:'crossref',
      title, authors, year, doi, cites: w['is-referenced-by-count'] || 0,
      url: doi ? 'https://doi.org/'+doi : (w.URL || ''),
      abstract,
      keywords: (w.subject || []).slice(0,5).join('; '),
      type: w.type || 'journal-article',
      openAccess: false
    };
  });
}

async function searchWikipedia(q, limit=5){
  const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=${limit}&format=json&origin=*`;
  const data = await onlineFetchJson(searchUrl);
  const hits = data.query?.search || [];
  if(!hits.length) return [];
  const titles = hits.map(h=>h.title).join('|');
  const extractUrl = `https://en.wikipedia.org/w/api.php?action=query&prop=extracts|info&exintro=1&explaintext=1&inprop=url&titles=${encodeURIComponent(titles)}&format=json&origin=*`;
  let extracts = {};
  try{
    const exData = await onlineFetchJson(extractUrl);
    const pages = exData.query?.pages || {};
    for(const p of Object.values(pages)){
      extracts[p.title] = { extract: (p.extract||'').slice(0,450), url: p.fullurl || `https://en.wikipedia.org/wiki/${encodeURIComponent(p.title.replace(/ /g,'_'))}` };
    }
  }catch(e){}
  return hits.map(h=>{
    const ex = extracts[h.title] || {};
    return {
      source:'Wikipedia', sourceId:'wikipedia',
      title: h.title,
      authors: '', year: '', doi: '', cites: 0,
      url: ex.url || `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title.replace(/ /g,'_'))}`,
      abstract: ex.extract || (h.snippet||'').replace(/<[^>]+>/g,'') || '',
      keywords: '',
      type: 'encyclopedia-article',
      openAccess: true
    };
  });
}

async function searchDBpedia(q, limit=5){
  const url = `https://lookup.dbpedia.org/api/search?query=${encodeURIComponent(q)}&maxResults=${limit}&format=json`;
  try{
    const data = await onlineFetchJson(url, { timeout: 10000 });
    const docs = data.docs || data.results || (Array.isArray(data) ? data : []);
    return docs.slice(0,limit).map(d=>{
      const label = d.label || (d.label && d.label[0]) || d.refLabel || 'Untitled';
      const comment = (d.comment || (d.comment && d.comment[0]) || d.description || '').toString().slice(0,400);
      const resource = (d.resource && d.resource[0]) || d.uri || d.ref || '';
      return {
        source:'DBpedia', sourceId:'dbpedia',
        title: Array.isArray(label) ? label[0] : label,
        authors: '', year: '', doi: '', cites: 0,
        url: resource || `https://dbpedia.org/page/${encodeURIComponent(String(label).replace(/ /g,'_'))}`,
        abstract: Array.isArray(comment) ? comment[0] : comment,
        keywords: (d.categories || d.type || []).slice ? (d.categories || d.type || []).slice(0,4).join('; ') : '',
        type: 'structured-entity',
        openAccess: true
      };
    });
  }catch(e){
    throw new Error('DBpedia lookup unavailable or blocked by CORS. Try Wikipedia or OpenAlex.');
  }
}

function onlineResultCard(r, idx){
  const badges = [];
  badges.push(`<span class="badge">${esc(r.source)}</span>`);
  if(r.openAccess) badges.push(`<span class="badge access">Open Access</span>`);
  if(r.cites) badges.push(`<span class="badge cites">${Number(r.cites).toLocaleString()} cites</span>`);
  if(r.year) badges.push(`<span class="badge">${r.year}</span>`);
  if(r.type) badges.push(`<span class="badge">${esc(r.type)}</span>`);
  const meta = [r.authors, r.year].filter(Boolean).join(' · ');
  const link = safeUrl(r.url);
  return `<article class="result-card online-card" data-online="${idx}">
    <h3 class="rtitle">${link ? `<a href="${esc(link)}" target="_blank" rel="noopener">${esc(r.title)}</a>` : esc(r.title)}</h3>
    <div class="meta">${esc(meta)}</div>
    <div class="badges">${badges.join('')}</div>
    ${r.abstract ? `<div class="abstract">${esc(r.abstract)}${r.abstract.length>=400?'…':''}</div>` : ''}
    ${r.keywords ? `<div class="tiny" style="margin-top:6px"><b>Concepts:</b> ${esc(r.keywords)}</div>` : ''}
    <div class="actions">
      ${link ? `<a class="ghost" href="${esc(link)}" target="_blank" rel="noopener">Open resource ↗</a>` : ''}
      ${r.doi ? `<a class="ghost" href="https://doi.org/${esc(r.doi)}" target="_blank" rel="noopener">DOI</a>` : ''}
    </div>
  </article>`;
}

async function runOnlineSearch(query, selectedSources){
  const q = (query || '').trim();
  if(!q){ toast('Enter a search query first'); return; }
  if(!selectedSources.length){ toast('Select at least one online source'); return; }
  const status = $('#onlineStatus');
  const list = $('#onlineResults');
  if(status) status.innerHTML = '<span class="spinner" style="width:14px;height:14px;display:inline-block;border-width:2px"></span> Searching online sources…';
  if(list) list.innerHTML = '';
  const tasks = [];
  if(selectedSources.includes('openalex')) tasks.push(searchOpenAlex(q).then(r=>({src:'openalex',r})).catch(e=>({src:'openalex',err:e.message})));
  if(selectedSources.includes('crossref')) tasks.push(searchCrossref(q).then(r=>({src:'crossref',r})).catch(e=>({src:'crossref',err:e.message})));
  if(selectedSources.includes('wikipedia')) tasks.push(searchWikipedia(q).then(r=>({src:'wikipedia',r})).catch(e=>({src:'wikipedia',err:e.message})));
  if(selectedSources.includes('dbpedia')) tasks.push(searchDBpedia(q).then(r=>({src:'dbpedia',r})).catch(e=>({src:'dbpedia',err:e.message})));

  const settled = await Promise.all(tasks);
  let all = [], errors = [];
  settled.forEach(s=>{
    if(s.err) errors.push(`${(ONLINE_SOURCES[s.src]&&ONLINE_SOURCES[s.src].label)||s.src}: ${s.err}`);
    else if(Array.isArray(s.r)) all = all.concat(s.r);
  });
  if(status){
    status.innerHTML = all.length
      ? `<b>${all.length}</b> web resource${all.length===1?'':'s'} found` + (errors.length ? ` · <span style="color:var(--warn)">${errors.length} source error(s)</span>` : '')
      : (errors.length ? `<span style="color:var(--warn)">${errors.join(' · ')}</span>` : 'No results from selected sources');
  }
  if(list){
    if(!all.length){
      list.innerHTML = `<div class="note">${errors.length ? errors.map(e=>esc(e)).join('<br>') : 'No matching web resources. Try different keywords or other sources.'}</div>`;
    } else {
      list.innerHTML = all.map((r,i)=>onlineResultCard(r,i)).join('');
    }
  }
  window.__lastOnlineResults = all;
  // Enable Build Knowledge Graph button
  const kgBtn = document.getElementById('buildOnlineKgBtn');
  if(kgBtn){
    kgBtn.disabled = !all.length;
    kgBtn.style.opacity = all.length ? '1' : '0.5';
    kgBtn.onclick = () => {
      if(!all.length){ toast('No online results to graph'); return; }
      const q = ($('#onlineQuery') && $('#onlineQuery').value) || state.query || '';
      kgOpenOnline(all, q);
    };
  }
}

/* ── Knowledge Graph construction from Online Web Search results ── */
function onlineToPseudoHits(results){
  // Convert online result objects into a lightweight hit list the graph layer can use.
  // We do not inject them into the local DATA array; we only build graphs from them.
  return (results || []).map((r, i) => ({ i: 'online|' + i, online: r, score: 1 }));
}

function onlineRecObj(key){
  // key is 'online|N'
  const idx = Number(String(key).replace(/^online\|/, ''));
  const r = (window.__lastOnlineResults || [])[idx];
  if(!r) return { index: key, cites: 0, authors: '', title: '', year: '', source: '', publisher: '', place: '', country: '', url: '', doi: '', issn: '', keywords: '', abstract: '' };
  return {
    index: key,
    cites: r.cites || 0,
    authors: r.authors || '',
    title: r.title || '',
    year: r.year || '',
    source: r.source || '',
    publisher: r.publisher || '',
    place: r.place || '',
    country: r.country || '',
    url: r.url || '',
    doi: r.doi || '',
    issn: '',
    keywords: r.keywords || '',
    abstract: r.abstract || '',
    _online: true,
    _provider: r.sourceId || r.source
  };
}

function kgBuildFromOnline(results, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = (results || []).slice(0, limit);
  const items = chosen.map((r, rank) => {
    const url = safeUrl(r.url) || (r.doi ? 'https://doi.org/' + r.doi : '');
    return {
      key: 'online|' + rank, rank, score: 1,
      o: {title: r.title || 'Untitled', year: r.year || '', source: r.source || '', publisher: '', place: '', doi: r.doi || '', url, cites: r.cites || 0},
      authors: String(r.authors || '').split(/;| and |,/).map(x => x.trim()).filter(Boolean),
      keywords: String(r.keywords || '').split(/;|,/).map(x => x.trim()).filter(x => x.length > 2)
    };
  });
  const q = (opts.query || state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Online query: ${q}` : 'Online web results'
  });
}

function kgOpenOnline(results, query){
  if(!results || !results.length){
    toast('No online results available for graph');
    return;
  }
  // Close the search modal first so the graph modal can take over cleanly
  if(typeof closeModal === 'function') closeModal();

  const isSingle = false;
  const defaultLimit = Math.min(20, results.length);
  const modelOptions = Object.values(KG_MODELS).map(m => `<option value="${m.id}">${m.label}</option>`).join('');

  $('#modalCard').classList.add('graph-modal-card');
  showModal(`<h2>Online Web Results Knowledge Graph</h2>
    <p class="tiny">Graph built from <b>live online results</b> (OpenAlex, Crossref, Wikipedia, DBpedia). Choose a construction model. Nodes link to the original web resources when available.</p>
    <div class="kg-toolbar">
      <label>KG Model <select id="kgModel">${modelOptions}</select></label>
      <label>Top results <select id="kgLimit"><option>10</option><option selected>20</option><option>30</option><option>40</option></select></label>
      <label><input type="checkbox" id="kgEdgeLabels">Edge labels</label>
      <span class="spacer"></span>
      <button class="ghost" id="kgFit">Fit</button>
      <button class="ghost" id="kgReset">Re-layout</button>
      <button class="ghost" id="kgPng">Save PNG</button>
    </div>
    <div class="kg-layout">
      <div class="kg-stage">
        <canvas id="kgCanvas" aria-label="Knowledge graph from online web results"></canvas>
        <div class="kg-tooltip" id="kgTooltip"></div>
      </div>
      <aside class="kg-side">
        <h3>Graph summary</h3>
        <div id="kgStats"></div>
        <h4>Selected node</h4>
        <div id="kgSelection"></div>
        <h4>Node types</h4>
        <div class="kg-legend">${typeof kgLegend === 'function' ? kgLegend() : ''}</div>
        <h4>Model description</h4>
        <div class="kg-edge-key" id="kgModelDesc" style="font-size:12px;color:var(--muted);margin-bottom:8px"></div>
        <h4>Relationship meanings</h4>
        <div class="kg-edge-key" id="kgEdgeKey">Select a model to see relationship definitions.</div>
        <div class="kg-note" style="margin-top:10px;font-size:12px;color:var(--muted)">Online graphs use metadata returned by the selected web sources. Citation networks require full reference lists, which these APIs do not always provide.</div>
      </aside>
    </div>`);

  const rebuild = () => {
    const modelId = ($('#kgModel') && $('#kgModel').value) || 'bibliographic';
    const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
    const limit = Number($('#kgLimit')?.value || defaultLimit);
    const g = kgBuildFromOnline(results, modelId, { limit, includeSearchRoot: true, query: query || state.query });
    KG.nodes = g.nodes;
    KG.edges = g.edges;
    KG.nodeMap = new Map(KG.nodes.map(n => [n.id, n]));
    KG.canvas = $('#kgCanvas');
    KG.ctx = KG.canvas.getContext('2d');
    KG.scale = 1; KG.tx = 0; KG.ty = 0; KG.selected = null;
    const keyEl = document.getElementById('kgEdgeKey');
    const descEl = document.getElementById('kgModelDesc');
    if(keyEl) keyEl.innerHTML = model.relations;
    if(descEl) descEl.textContent = model.desc + ' (built from online web results)';
    kgInitPositions();
    kgResize();
    $('#kgStats').innerHTML = kgStats();
    $('#kgSelection').innerHTML = kgSelectionHtml(null);
    kgBindCanvas();
    cancelAnimationFrame(KG.anim);
    KG.anim = requestAnimationFrame(kgAnimate);
    setTimeout(() => kgFit(), 160);
  };

  rebuild();
  if($('#kgLimit')) $('#kgLimit').onchange = rebuild;
  if($('#kgModel')) $('#kgModel').onchange = rebuild;
  $('#kgEdgeLabels').onchange = e => { KG.showEdgeLabels = e.target.checked; kgDraw(); };
  $('#kgFit').onclick = kgFit;
  $('#kgReset').onclick = () => { kgInitPositions(); cancelAnimationFrame(KG.anim); KG.anim = requestAnimationFrame(kgAnimate); };
  if($('#kgPng')) $('#kgPng').onclick = () => {
    try {
      const a = document.createElement('a');
      a.download = 'online-knowledge-graph.png';
      a.href = KG.canvas.toDataURL('image/png');
      a.click();
    } catch(e) { toast('Could not export PNG'); }
  };
}


function onlineSearchModal(){
  const q = ($('#q') && $('#q').value) || state.query || '';
  showModal(`<h2>🌐 Online Web Resource Search</h2>
    <p class="tiny">Search live scholarly and knowledge bases when you are connected to the internet. Results open on the original sites. Local library search remains available offline.</p>
    <div class="db-form" style="margin:12px 0">
      <label>Query <input id="onlineQuery" value="${esc(q)}" placeholder="e.g. knowledge graphs in digital libraries"></label>
      <div style="margin-top:10px"><b>Sources</b></div>
      <div class="checklist" style="margin-top:6px;max-height:none">
        ${Object.values(ONLINE_SOURCES).map(s=>`
          <label class="check"><input type="checkbox" class="onlineSrc" value="${s.id}" ${s.id!=='dbpedia'?'checked':''}>
            <span><b>${esc(s.label)}</b> — ${esc(s.desc)}</span>
          </label>`).join('')}
      </div>
    </div>
    <div class="actions" style="margin:12px 0">
      <button class="primary" id="runOnlineSearchBtn">Search selected sources</button>
      <button class="ghost" id="buildOnlineKgBtn" disabled style="opacity:0.5" title="Build a knowledge graph from the online results">⌘ Build Knowledge Graph</button>
      <button class="ghost" id="closeOnlineModal">Close</button>
    </div>
    <div id="onlineStatus" class="tiny" style="margin-bottom:8px;color:var(--muted)"></div>
    <div id="onlineResults" class="result-list" style="max-height:55vh;overflow:auto"></div>
    <p class="note" style="margin-top:12px">OpenAlex &amp; Crossref return scholarly metadata (DOI, citations, abstracts). Wikipedia &amp; DBpedia return encyclopedic / structured knowledge. DBpedia lookup may be blocked by some browsers (CORS); Wikipedia is a reliable alternative. No API keys required for basic use. Please respect the providers’ rate limits.</p>`);
  $('#runOnlineSearchBtn').onclick = ()=>{
    const query = $('#onlineQuery').value.trim();
    const selected = $$('.onlineSrc:checked').map(c=>c.value);
    runOnlineSearch(query, selected);
  };
  $('#closeOnlineModal').onclick = closeModal;
  if(q.trim()){
    setTimeout(()=>$('#runOnlineSearchBtn').click(), 200);
  }
}


function dataInfo(){showModal(`<h2>Dataset information</h2><div class="detail-grid"><div class="detail-block"><b>Records</b>${M.recordCount.toLocaleString()}</div><div class="detail-block"><b>Years</b>${M.minYear}–${M.maxYear}</div><div class="detail-block"><b>Journals/sources</b>${M.sourceCounts.length}</div><div class="detail-block"><b>Publishers</b>${M.publisherCounts.length}</div><div class="detail-block"><b>Missing abstracts</b>${(M.missing.Abstract||0).toLocaleString()}</div><div class="detail-block"><b>Missing DOI</b>${(M.missing.DOI||0).toLocaleString()}</div></div><h3>Available fields</h3><p>Cites, Authors, Title, Year, Source, Publisher, Place, Country, ArticleURL, DOI, ISSN, Keywords, Abstract.</p><h3>Not present in this workbook</h3><p>Verified Open Access status, document type, individual references/cited-by links, library holdings/account identifiers.</p><h3>Research intelligence</h3><p>NER, hypothesis and research-gap modules operate locally over bibliographic metadata, keywords and abstracts. Their inferred outputs are explicitly marked as candidates/signals rather than source-verified facts.</p><h3>Online / offline</h3><p><b>Works offline:</b> search, filters, ranking, knowledge graphs, Research Intelligence, export, saved items all run from this single HTML file with embedded data—no server required. <b>Optional online:</b> opening DOI/article links, Neo4j/GraphDB live queries, and external scholar links need internet when you use them.</p>`)}
function addAdvRow(data={bool:'AND',field:'title',op:'contains',value:''}){let div=document.createElement('div');div.className='advrow';div.innerHTML=`<select class="bool" aria-label="Boolean operator"><option>AND</option><option>OR</option></select><select class="field" aria-label="Search field"><option value="title">Title</option><option value="authors">Author</option><option value="keywords">Keyword</option><option value="source">Journal/source</option><option value="publisher">Publisher</option><option value="country">Country</option><option value="abstract">Abstract</option><option value="doi">DOI</option><option value="year">Year</option></select><select class="op" aria-label="Match operator"><option value="contains">contains</option><option value="exact">is exactly</option><option value="starts">starts with</option><option value="not">does not contain</option></select><input class="value" aria-label="Search value" placeholder="Enter value"><button class="ghost remove" aria-label="Remove field">×</button>`;div.querySelector('.bool').value=data.bool;div.querySelector('.field').value=data.field;div.querySelector('.op').value=data.op;div.querySelector('.value').value=data.value;div.querySelector('.remove').onclick=()=>div.remove();$('#advRows').appendChild(div)}
function collectAdvanced(){state.advanced=$$('#advRows .advrow').map((r,k)=>({bool:k===0?'AND':r.querySelector('.bool').value,field:r.querySelector('.field').value,op:r.querySelector('.op').value,value:r.querySelector('.value').value.trim()})).filter(x=>x.value)}
function fillStats(){const f=n=>Number(n).toLocaleString();const v={records:f(M.recordCount||R.length),sources:f((S||[]).length),countries:f((CO||[]).length),maxcites:f(M.maxCites||0),years:(M.minYear&&M.maxYear)?M.minYear+'\u2013'+M.maxYear:''};document.querySelectorAll('[data-stat]').forEach(e=>{if(v[e.dataset.stat]!==undefined)e.textContent=v[e.dataset.stat]})}
function bind(){
 $('#searchForm').onsubmit=e=>{e.preventDefault();const qv=$('#q').value;if(typeof clearFilters==='function')clearFilters(true);state.query=qv;$('#q').value=qv;state.savedOnly=false;state.page=1;if(qv&&qv.trim())document.body.classList.add('has-search');else document.body.classList.remove('has-search');doSearch()};
 $('#sort').onchange=e=>{state.sort=e.target.value;state.page=1;doSearch(false)};
 $$('[data-year]').forEach(c=>c.onchange=e=>{let y=Number(e.target.dataset.year);e.target.checked?state.yearSet.add(y):state.yearSet.delete(y);state.page=1;doSearch(false)});
 ['yearFrom','yearTo','minCites'].forEach(id=>$('#'+id).onchange=e=>{state[id==='minCites'?'minCites':id]=e.target.value?Number(e.target.value):null;state.page=1;doSearch(false)});
 $('#sourceFilter').onchange=e=>{state.source=e.target.value;state.page=1;doSearch(false)};$('#publisherFilter').onchange=e=>{state.publisher=e.target.value;state.page=1;doSearch(false)};$('#countryFilter').onchange=e=>{state.country=e.target.value;state.page=1;doSearch(false)};$('#subjectFilter').onchange=e=>{state.subject=e.target.value;state.page=1;doSearch(false)};$('#hasLink').onchange=e=>{state.hasLink=e.target.checked;state.page=1;doSearch(false)};
 $('#clearFilters').onclick=clearFilters;$('#advancedBtn').onclick=()=>$('#advanced').classList.toggle('open');$('#addAdvRow').onclick=()=>addAdvRow();$('#runAdvanced').onclick=()=>{collectAdvanced();state.page=1;doSearch()};$('#clearAdvanced').onclick=()=>{state.advanced=[];$('#advRows').innerHTML='';addAdvRow();doSearch(false)};
 $('#resultList').onclick=e=>{let b=e.target.closest('[data-act]');if(!b)return;let i=Number(b.dataset.id),act=b.dataset.act;if(act==='detail')detail(i);if(act==='save'){let s=savedSet();s.has(i)?s.delete(i):s.add(i);setSaved(s);render()}if(act==='cite')citeModal(i);if(act==='export')exportModal([i],'Export record');if(act==='related')related(i);if(act==='graph')graph(i);if(act==='ner')riNERModal(i);if(act==='hyp')riHypModal(i);if(act==='gap')riGapModal(i);if(act==='why')$('#why-'+i).classList.toggle('open')};
 $('#savedBtn').onclick=()=>{state.savedOnly=!state.savedOnly;state.page=1;doSearch(false)};$('#exportResultsBtn').onclick=()=>exportModal(currentResults,'Export current results');$('#graphResultsBtn').onclick=graphResults;$('#onlineSearchBtn').onclick=onlineSearchModal;$('#dbIntegrationBtn').onclick=dbIntegrationModal;$('#dataInfoBtn').onclick=dataInfo;
 $('#modalClose').onclick=closeModal;$('#modal').onclick=e=>{if(e.target===$('#modal'))closeModal()};document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();$('#facets').classList.remove('mobile-open')}});
 $('#riNER').onclick=()=>riNERModal();$('#riHyp').onclick=()=>riHypModal();$('#riGap').onclick=()=>riGapModal();$('#riAll').onclick=()=>riAllGraph();
 $('#mobileFilterBtn').onclick=()=>$('#facets').classList.add('mobile-open');$('#closeFilters').onclick=()=>$('#facets').classList.remove('mobile-open');
}
(async()=>{try{DATA=await unpack();M=DATA.m;R=DATA.r;S=M.sources;PUB=M.publishers;PLC=M.places;CO=M.countries;buildIndex();populateFacets();addAdvRow();updateSavedCount();bind();if(typeof bindDatasetUpload==='function')bindDatasetUpload();doSearch(false);fillStats();$('#loading').remove()}catch(err){$('#loading').innerHTML=`<div><h2>Could not load the local dataset</h2><p>${esc(err.message)}</p></div>`;console.error(err)}})();



/* ===== Dataset upload tab (all features preserved) ===== */
function datasetFieldMap(headers){
  const map={};
  headers.forEach((h,i)=>{
    const k=norm(h).replace(/[^a-z0-9]+/g,'');
    if(['cites','citations','citationcount','citedby','timescited'].includes(k)) map.cites=i;
    else if(['authors','author','creator','creators'].includes(k)) map.authors=i;
    else if(['title','articletitle','name'].includes(k)) map.title=i;
    else if(['year','publicationyear','pubyear','date'].includes(k)) map.year=i;
    else if(['source','journal','journalsource','publication','venue'].includes(k)) map.source=i;
    else if(['publisher','pub'].includes(k)) map.publisher=i;
    else if(['place','city','location'].includes(k)) map.place=i;
    else if(['country','nation'].includes(k)) map.country=i;
    else if(['articleurl','url','link','fulltexturl'].includes(k)) map.url=i;
    else if(['doi'].includes(k)) map.doi=i;
    else if(['issn'].includes(k)) map.issn=i;
    else if(['keywords','keyword','subjects','subject','tags'].includes(k)) map.keywords=i;
    else if(['abstract','summary','description'].includes(k)) map.abstract=i;
  });
  return map;
}
function parseCSVText(text){
  const rows=[]; let row=[], cell='', inQ=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i], nx=text[i+1];
    if(inQ){
      if(ch==='"'&&nx==='"'){cell+='"';i++;}
      else if(ch==='"') inQ=false;
      else cell+=ch;
    }else{
      if(ch==='"') inQ=true;
      else if(ch===','){row.push(cell);cell='';}
      else if(ch==='\n'||(ch==='\r'&&nx==='\n')){if(ch==='\r')i++;row.push(cell);rows.push(row);row=[];cell='';}
      else if(ch==='\r'){row.push(cell);rows.push(row);row=[];cell='';}
      else cell+=ch;
    }
  }
  if(cell.length||row.length){row.push(cell);rows.push(row)}
  return rows.filter(r=>r.some(c=>String(c||'').trim()!==''));
}
function uniqIndex(list, value){
  value=String(value||'').trim();
  if(!value) return 0;
  let i=list.indexOf(value);
  if(i>=0) return i;
  list.push(value); return list.length-1;
}
function buildMetaFromRecords(rawRows, opts={}){
  const sources=[''], publishers=[''], places=[''], countries=[''];
  const yearCounts=new Map(), sourceCounts=new Map(), publisherCounts=new Map(), countryCounts=new Map(), keywordCounts=new Map();
  let missing={DOI:0,Keywords:0,Abstract:0,ArticleURL:0}, minYear=null, maxYear=null, maxCites=0;
  const r=[];
  for(const item of rawRows){
    let cites,authors,title,year,source,publisher,place,country,url,doi,issn,keywords,abstract;
    if(Array.isArray(item) && item.length>=13 && typeof item[4]==='number'){
      cites=+item[0]||0; authors=item[1]||''; title=item[2]||''; year=+item[3]||0;
      const si=item[4], pi=item[5], pli=item[6], ci=item[7];
      source=(opts.sources&&opts.sources[si])||''; publisher=(opts.publishers&&opts.publishers[pi])||'';
      place=(opts.places&&opts.places[pli])||''; country=(opts.countries&&opts.countries[ci])||'';
      url=item[8]||''; doi=item[9]||''; issn=item[10]||''; keywords=item[11]||''; abstract=item[12]||'';
    }else if(Array.isArray(item)){
      cites=+item[0]||0; authors=item[1]||''; title=item[2]||''; year=+item[3]||0;
      source=item[4]||''; publisher=item[5]||''; place=item[6]||''; country=item[7]||'';
      url=item[8]||''; doi=item[9]||''; issn=item[10]||''; keywords=item[11]||''; abstract=item[12]||'';
    }else{
      const o=item||{};
      cites=+(o.cites??o.citations??o.citation_count??0)||0;
      authors=o.authors||o.author||'';
      title=o.title||'';
      year=+(o.year||String(o.date||'').slice(0,4)||0)||0;
      source=o.source||o.journal||'';
      publisher=o.publisher||'';
      place=o.place||o.city||'';
      country=o.country||'';
      url=o.url||o.articleUrl||o.ArticleURL||'';
      doi=o.doi||o.DOI||'';
      issn=o.issn||o.ISSN||'';
      keywords=o.keywords||o.keyword||o.subjects||'';
      abstract=o.abstract||o.summary||'';
    }
    if(Array.isArray(authors)) authors=authors.join('; ');
    if(Array.isArray(keywords)) keywords=keywords.join('; ');
    const sIdx=uniqIndex(sources, source);
    const pIdx=uniqIndex(publishers, publisher);
    const plIdx=uniqIndex(places, place);
    const cIdx=uniqIndex(countries, country);
    r.push([cites, String(authors||''), String(title||''), year, sIdx, pIdx, plIdx, cIdx, String(url||''), String(doi||''), String(issn||''), String(keywords||''), String(abstract||'')]);
    if(year){yearCounts.set(year,(yearCounts.get(year)||0)+1); minYear=minYear==null?year:Math.min(minYear,year); maxYear=maxYear==null?year:Math.max(maxYear,year)}
    if(source) sourceCounts.set(sIdx,(sourceCounts.get(sIdx)||0)+1);
    if(publisher) publisherCounts.set(pIdx,(publisherCounts.get(pIdx)||0)+1);
    if(country) countryCounts.set(cIdx,(countryCounts.get(cIdx)||0)+1);
    maxCites=Math.max(maxCites,cites);
    if(!doi) missing.DOI++;
    if(!keywords) missing.Keywords++;
    if(!abstract) missing.Abstract++;
    if(!url) missing.ArticleURL++;
    String(keywords||'').split(/[;,|]/).map(x=>x.trim()).filter(x=>x.length>1).forEach(k=>{
      const key=k.toLowerCase();
      let e=keywordCounts.get(key)||{label:k,c:0}; e.c++; keywordCounts.set(key,e);
    });
  }
  const topKeywords=[...keywordCounts.values()].sort((a,b)=>b.c-a.c).slice(0,200).map(x=>[x.label,x.c]);
  const m={
    sources, publishers, places, countries,
    yearCounts:[...yearCounts.entries()].sort((a,b)=>b[0]-a[0]),
    sourceCounts:[...sourceCounts.entries()].sort((a,b)=>b[1]-a[1]),
    publisherCounts:[...publisherCounts.entries()].sort((a,b)=>b[1]-a[1]),
    countryCounts:[...countryCounts.entries()].sort((a,b)=>b[1]-a[1]),
    topKeywords, recordCount:r.length, missing,
    minYear:minYear??2020, maxYear:maxYear??2025, maxCites
  };
  return {m,r};
}
function normalizeUploadedPayload(raw){
  if(!raw||typeof raw!=='object') throw new Error('JSON must be an object or array of records');
  if(Array.isArray(raw.r) && raw.m && Array.isArray(raw.m.sources)){
    const m=Object.assign({
      yearCounts:[], sourceCounts:[], publisherCounts:[], countryCounts:[], topKeywords:[],
      recordCount:raw.r.length, missing:{DOI:0,Keywords:0,Abstract:0,ArticleURL:0},
      minYear:2020, maxYear:2025, maxCites:0
    }, raw.m);
    if(!m.recordCount) m.recordCount=raw.r.length;
    return {m, r:raw.r};
  }
  let rows=null;
  if(Array.isArray(raw)) rows=raw;
  else if(Array.isArray(raw.records)) rows=raw.records;
  else if(Array.isArray(raw.data)) rows=raw.data;
  else if(Array.isArray(raw.r)){
    return buildMetaFromRecords(raw.r, {
      sources:raw.m?.sources, publishers:raw.m?.publishers, places:raw.m?.places, countries:raw.m?.countries
    });
  }
  if(!rows||!rows.length) throw new Error('No records found. Use {m,r}, {records:[...]}, or CSV with headers.');
  return buildMetaFromRecords(rows);
}
function updateCollectionMetrics(){
  try{
    const cards=document.querySelectorAll('.metric-grid .metric-card b');
    if(cards[0]) cards[0].textContent=(M.recordCount||R.length).toLocaleString();
    if(cards[1]) cards[1].textContent=String((M.sourceCounts||[]).length || (S||[]).filter(Boolean).length);
    if(cards[2]) cards[2].textContent=String((M.countryCounts||[]).length || (CO||[]).filter(Boolean).length);
    if(cards[3]){
      const a=M.minYear, b=M.maxYear;
      cards[3].textContent=(a&&b)?(a===b?String(a):`${a}–${b}`):'—';
    }
    const insightStats=document.querySelectorAll('.insights .stat b');
    if(insightStats[0]) insightStats[0].textContent=(M.recordCount||R.length).toLocaleString();
    if(insightStats[1]) insightStats[1].textContent=String((M.sourceCounts||[]).length || (S||[]).filter(Boolean).length);
    if(insightStats[2]) insightStats[2].textContent=String((M.countryCounts||[]).length || (CO||[]).filter(Boolean).length);
    if(insightStats[3]) insightStats[3].textContent=Number(M.maxCites||0).toLocaleString();
  }catch(e){console.warn(e)}
}
function resetFacetsUI(){
  const yc=$('#yearChecks'); if(yc) yc.innerHTML='';
  const keepFirst=sel=>{if(!sel)return; const first=sel.querySelector('option'); sel.innerHTML=''; if(first) sel.appendChild(first);};
  keepFirst($('#sourceFilter')); keepFirst($('#publisherFilter')); keepFirst($('#countryFilter')); keepFirst($('#subjectFilter'));
}
function applyDataset(payload, label='Uploaded dataset'){
  DATA=payload; M=payload.m; R=payload.r; try{setTimeout(fillStats,0)}catch(e){}
  S=M.sources||['']; PUB=M.publishers||['']; PLC=M.places||['']; CO=M.countries||[''];
  try{ localStorage.removeItem('libSaved'); }catch(e){}
  state={query:'',page:1,sort:'relevance',savedOnly:false,yearSet:new Set(),yearFrom:null,yearTo:null,source:'',publisher:'',country:'',subject:'',hasLink:false,minCites:0,advanced:[]};
  currentResults=[]; SEARCH_SAVED=null;
  document.body.classList.remove('has-search');
  const qe=$('#q'); if(qe) qe.value='';
  if($('#sort')) $('#sort').value='relevance';
  if($('#yearFrom')) $('#yearFrom').value='';
  if($('#yearTo')) $('#yearTo').value='';
  if($('#minCites')) $('#minCites').value=0;
  if($('#hasLink')) $('#hasLink').checked=false;
  if($('#advRows')){ $('#advRows').innerHTML=''; if(typeof addAdvRow==='function') addAdvRow(); }
  resetFacetsUI();
  buildIndex();
  populateFacets();
  updateCollectionMetrics();
  updateSavedCount();
  doSearch(false);
  toast(`${label}: ${R.length.toLocaleString()} records loaded`);
  const loadEl=$('#loading'); if(loadEl) loadEl.remove();
}
async function handleDatasetFile(file){
  if(!file) return;
  const name=(file.name||'').toLowerCase();
  const text=await file.text();
  let payload;
  if(name.endsWith('.csv') || (file.type||'').includes('csv')){
    const rows=parseCSVText(text);
    if(rows.length<2) throw new Error('CSV needs a header row and at least one data row');
    const headers=rows[0];
    const fmap=datasetFieldMap(headers);
    if(fmap.title===undefined) throw new Error('CSV must include a Title column (or equivalent)');
    const objects=rows.slice(1).map(cols=>{
      const get=k=>fmap[k]!==undefined?cols[fmap[k]]:'';
      let year=String(get('year')||'').trim();
      const ym=year.match(/(20\d{2}|19\d{2})/);
      year=ym?Number(ym[1]):0;
      return {
        cites:get('cites'), authors:get('authors'), title:get('title'), year,
        source:get('source'), publisher:get('publisher'), place:get('place'), country:get('country'),
        url:get('url'), doi:get('doi'), issn:get('issn'), keywords:get('keywords'), abstract:get('abstract')
      };
    }).filter(o=>String(o.title||'').trim());
    payload=buildMetaFromRecords(objects);
  }else{
    let raw;
    try{ raw=JSON.parse(text); }catch(e){ throw new Error('Invalid JSON: '+e.message); }
    payload=normalizeUploadedPayload(raw);
  }
  if(!payload.r?.length) throw new Error('Dataset contains zero records');
  applyDataset(payload, file.name||'Uploaded dataset');
}
function uploadDatasetModal(){
  showModal(`<div class="db-modal-title"><span class="db-mark">⇧</span><h2>Upload Dataset</h2><span class="badge">JSON / CSV</span></div>
  <div class="db-banner"><b>Replace the library data</b> while keeping every feature: search, filters, knowledge graph, Research Intelligence, export, Neo4j &amp; GraphDB.</div>
  <div class="detail-grid">
    <div class="detail-block"><b>JSON formats</b>App format <code>{m, r}</code>, <code>{records:[...]}</code>, or an array of paper objects.</div>
    <div class="detail-block"><b>CSV columns</b>Title (required), Authors, Year, Source/Journal, Publisher, Place, Country, URL, DOI, ISSN, Keywords, Abstract, Cites.</div>
  </div>
  <div class="note" style="margin:12px 0">Saved items are cleared when a new dataset is loaded (record indexes change). Everything runs in your browser — no server upload.</div>
  <div class="actions">
    <button class="primary" id="pickDatasetFile" style="background:#0b9f6e;border-color:#0b9f6e">Choose JSON or CSV file…</button>
    <button class="ghost" id="reloadEmbeddedDataset">Reload original embedded library</button>
  </div>
  <p class="tiny" id="uploadDatasetStatus" style="margin-top:10px">Current library: ${(M&&M.recordCount)|| (R&&R.length) || 0} records</p>`);
  $('#pickDatasetFile').onclick=()=>$('#datasetFileInput').click();
  $('#reloadEmbeddedDataset').onclick=async()=>{
    try{
      const st=$('#uploadDatasetStatus'); if(st) st.textContent='Reloading embedded library…';
      const payload=JSON.parse(EMBEDDED_DATA);
      applyDataset(payload, 'Original embedded library');
      closeModal();
    }catch(e){ toast('Could not reload embedded data: '+e.message); }
  };
}
function bindDatasetUpload(){
  const btn=$('#uploadDatasetBtn');
  const input=$('#datasetFileInput');
  if(btn) btn.onclick=uploadDatasetModal;
  if(!input) return;
  input.onchange=async e=>{
    const file=e.target.files&&e.target.files[0];
    input.value='';
    if(!file) return;
    try{
      closeModal();
      let ov=document.createElement('div'); ov.id='uploadOverlay'; ov.className='loading'; ov.style.zIndex=250;
      ov.innerHTML='<div><div class="spinner"></div><strong>Loading dataset…</strong><div class="tiny" style="margin-top:6px">'+esc(file.name)+'</div></div>';
      document.body.appendChild(ov);
      await new Promise(r=>setTimeout(r,30));
      await handleDatasetFile(file);
    }catch(err){
      console.error(err);
      toast(err.message||'Upload failed');
      showModal(`<h2>Upload failed</h2><p>${esc(err.message||String(err))}</p><div class="actions"><button class="primary" id="uploadRetryBtn">Try again</button></div>`);
      const rb=$('#uploadRetryBtn'); if(rb) rb.onclick=uploadDatasetModal;
    }finally{
      const ov=document.getElementById('uploadOverlay'); if(ov) ov.remove();
    }
  };
}

/* ===== Neo4j + GraphDB live integration ===== */
Object.assign(KG_COLORS,{dbPaper:'#0f4c81',dbAuthor:'#ea580c',dbJournal:'#059669',dbConcept:'#7c3aed',dbNode:'#2563eb',dbLiteral:'#64748b',dbClass:'#be185d'});
Object.assign(KG_NAMES,{dbPaper:'Database paper',dbAuthor:'Database author',dbJournal:'Database journal',dbConcept:'Database concept',dbNode:'RDF / graph node',dbLiteral:'Literal value',dbClass:'RDF class'});
const DB_DEFAULTS={neoBase:'http://localhost:7474',neoDb:'neo4j',neoUser:'neo4j',graphRepo:'http://localhost:7200/repositories/library'};
let DB_LAST_NEO=null,DB_LAST_RDF=null;
function dbAuth(user,pass){if(!user)return{};try{return{'Authorization':'Basic '+btoa(user+':'+pass)}}catch{return{}}}
function dbShort(v){v=String(v||'');if(v.length<=58)return v;let h=v.replace(/[#\/]$/,'').split(/[#\/]/).pop();return h&&h.length<45?h:v.slice(0,25)+'…'+v.slice(-22)}
function dbJsonCell(v){if(v===null||v===undefined)return'';if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')return String(v);try{return JSON.stringify(v)}catch{return String(v)}}
function dbSetStatus(id,kind,msg){let el=$('#'+id);if(!el)return;el.className='db-status '+kind;el.innerHTML='<i></i><span>'+esc(msg)+'</span>'}
function dbCfg(){return{
 mode:$('#dbMode')?.value||'direct',
 neoBase:($('#neoBase')?.value||DB_DEFAULTS.neoBase).trim().replace(/\/$/,''),neoDb:($('#neoDb')?.value||'neo4j').trim(),neoUser:($('#neoUser')?.value||'').trim(),neoPass:$('#neoPass')?.value||'',neoProxy:($('#neoProxy')?.value||'http://localhost:8000/api/neo4j/query').trim(),
 graphRepo:($('#graphRepo')?.value||DB_DEFAULTS.graphRepo).trim().replace(/\/$/,''),graphUser:($('#graphUser')?.value||'').trim(),graphPass:$('#graphPass')?.value||'',graphProxy:($('#graphProxy')?.value||'http://localhost:8000/api/graphdb/query').trim()
}}
async function dbNeoFetch(statement){let c=dbCfg();if(c.mode==='proxy'){let r=await fetch(c.neoProxy,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({query:statement,parameters:{}})});let t=await r.text();if(!r.ok)throw new Error('Proxy '+r.status+': '+t.slice(0,250));return JSON.parse(t)}let url=c.neoBase+'/db/'+encodeURIComponent(c.neoDb)+'/query/v2';let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json',...dbAuth(c.neoUser,c.neoPass)},body:JSON.stringify({statement,parameters:{}})});let t=await r.text();if(!r.ok)throw new Error('Neo4j '+r.status+': '+t.slice(0,300));return JSON.parse(t)}
async function dbGraphFetch(query){let c=dbCfg();if(c.mode==='proxy'){let r=await fetch(c.graphProxy,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({query})});let t=await r.text();if(!r.ok)throw new Error('Proxy '+r.status+': '+t.slice(0,250));return JSON.parse(t)}let body=new URLSearchParams({query});let r=await fetch(c.graphRepo,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','Accept':'application/sparql-results+json',...dbAuth(c.graphUser,c.graphPass)},body});let t=await r.text();if(!r.ok)throw new Error('GraphDB '+r.status+': '+t.slice(0,300));return JSON.parse(t)}
function dbNeoRows(json){if(json?.data?.fields&&Array.isArray(json.data.values))return{fields:json.data.fields,values:json.data.values};if(Array.isArray(json?.records)){let keys=json.records.length?Object.keys(json.records[0]):[];return{fields:keys,values:json.records.map(r=>keys.map(k=>r[k]))}}return{fields:[],values:[]}}
function dbNeoTable(json){let x=dbNeoRows(json);if(!x.fields.length)return'<div class="note">Query completed, but no tabular rows were returned.</div>';return `<div class="db-tablewrap"><table class="db-table"><thead><tr>${x.fields.map(f=>`<th>${esc(f)}</th>`).join('')}</tr></thead><tbody>${x.values.slice(0,300).map(row=>`<tr>${row.map(v=>`<td>${esc(dbJsonCell(v))}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="db-mini">Showing up to 300 returned rows.</div>`}
function dbRdfTable(json){let vars=json?.head?.vars||[],rows=json?.results?.bindings||[];if(!vars.length)return'<div class="note">No SPARQL SELECT bindings were returned.</div>';return `<div class="db-tablewrap"><table class="db-table"><thead><tr>${vars.map(f=>`<th>${esc(f)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,300).map(row=>`<tr>${vars.map(v=>`<td>${esc(row[v]?.value||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="db-mini">Showing up to 300 returned bindings.</div>`}
function dbNeoType(labels=[]){let x=labels.map(norm).join(' ');if(/paper|publication|article/.test(x))return'dbPaper';if(/author|person|researcher/.test(x))return'dbAuthor';if(/journal|source/.test(x))return'dbJournal';if(/keyword|concept|subject|topic/.test(x))return'dbConcept';return'dbNode'}
function dbNeoGraph(json){let x=dbNeoRows(json),nodes=[],edges=[],map=new Map(),rels=[];let addNode=o=>{let id=String(o.elementId??o.id??('node-'+map.size));if(map.has(id))return map.get(id);let p=o.properties||{},labels=o.labels||[];let label=p.title||p.name||p.label||p.doi||p.recordId||labels[0]||dbShort(id);let n={id:'neo|'+id,type:dbNeoType(labels),label:String(label),description:(labels.length?'Labels: '+labels.join(', ')+' · ':'')+Object.entries(p).slice(0,8).map(([k,v])=>k+'='+dbJsonCell(v)).join(' · '),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n};
 let walk=v=>{if(!v||typeof v!=='object')return;if(Array.isArray(v)){v.forEach(walk);return}if(Array.isArray(v.labels)&&(v.elementId!==undefined||v.id!==undefined)){addNode(v);return}if(v.type&&(v.startNodeElementId!==undefined||v.startNode!==undefined)&&(v.endNodeElementId!==undefined||v.endNode!==undefined)){rels.push(v);return}if(Array.isArray(v.nodes))v.nodes.forEach(walk);if(Array.isArray(v.relationships))v.relationships.forEach(walk);for(let z of Object.values(v))if(z&&typeof z==='object')walk(z)};x.values.forEach(walk);
 for(let r of rels){let aId=String(r.startNodeElementId??r.startNode),bId=String(r.endNodeElementId??r.endNode),a=map.get(aId),b=map.get(bId);if(!a){a={id:'neo|'+aId,type:'dbNode',label:dbShort(aId),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(aId,a);nodes.push(a)}if(!b){b={id:'neo|'+bId,type:'dbNode',label:dbShort(bId),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(bId,b);nodes.push(b)}edges.push({a,b,relation:String(r.type||'RELATED_TO').replace(/_/g,' ').toLowerCase(),detail:dbJsonCell(r.properties||{})})}
 return{nodes:nodes.slice(0,350),edges:edges.slice(0,700)}}
function dbGraphDbGraph(json){let rows=json?.results?.bindings||[],nodes=[],edges=[],map=new Map(),labels=new Map();for(let row of rows){let s=row.s,p=row.p,o=row.o;if(s&&p&&o&&/label$/i.test(p.value)&&o.type==='literal')labels.set(s.value,o.value)}let add=(b,isObj=false)=>{if(!b)return null;let id=(b.type||'x')+'|'+b.value;if(map.has(id))return map.get(id);let isLit=b.type==='literal'||b.type==='typed-literal';let val=labels.get(b.value)||dbShort(b.value);let type=isLit?'dbLiteral':(/class|type/i.test(b.value)?'dbClass':'dbNode');let n={id:'rdf|'+id,type,label:val,description:(b.type||'value')+': '+b.value,weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n};for(let row of rows){if(!row.s||!row.p||!row.o)continue;let a=add(row.s),b=add(row.o,true);if(!a||!b)continue;let rel=dbShort(row.p.value);edges.push({a,b,relation:rel,detail:row.p.value})}return{nodes:nodes.slice(0,350),edges:edges.slice(0,700)}}
function dbOpenGenericGraph(g,title,desc){if(!g.nodes.length){toast('No graph-shaped data returned');return}riGenericGraph(g,title,desc,'Relationships come directly from the connected database query result. For Neo4j, return nodes and relationships together (for example <b>RETURN n,r,m</b>). For GraphDB, return <b>?s ?p ?o</b> bindings for graph visualization.')}
async function dbTestNeo(){dbSetStatus('neoStatus','busy','Testing Neo4j…');try{let j=await dbNeoFetch('RETURN 1 AS ok');DB_LAST_NEO=j;let x=dbNeoRows(j);dbSetStatus('neoStatus','ok','Connected. Query API responded'+(x.values.length?' successfully.':'.'))}catch(e){dbSetStatus('neoStatus','bad',e.message+' — if this is a browser CORS restriction, use Backend proxy mode.')}}
async function dbRunNeo(){let q=$('#neoQuery').value.trim();if(!q)return;dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','busy','Running Cypher…');try{let j=await dbNeoFetch(q);DB_LAST_NEO=j;$('#neoResult').innerHTML=dbNeoTable(j);let g=dbNeoGraph(j);$('#neoGraphBtn').disabled=!g.nodes.length;dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','ok','Cypher completed. '+dbNeoRows(j).values.length+' row(s) returned.')}catch(e){dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','bad',e.message)}}
async function dbTestGraph(){dbSetStatus('graphStatus','busy','Testing GraphDB…');try{let j=await dbGraphFetch('SELECT (COUNT(*) AS ?triples) WHERE { ?s ?p ?o }');DB_LAST_RDF=j;let v=j?.results?.bindings?.[0]?.triples?.value;dbSetStatus('graphStatus','ok','Connected to SPARQL endpoint'+(v?' · '+Number(v).toLocaleString()+' triples.':'.'))}catch(e){dbSetStatus('graphStatus','bad',e.message+' — if this is a browser CORS restriction, use Backend proxy mode.')}}
async function dbRunGraph(){let q=$('#graphQuery').value.trim();if(!q)return;dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','busy','Running SPARQL…');try{let j=await dbGraphFetch(q);DB_LAST_RDF=j;$('#graphResult').innerHTML=dbRdfTable(j);let g=dbGraphDbGraph(j);$('#graphGraphBtn').disabled=!g.nodes.length;dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','ok','SPARQL completed. '+(j?.results?.bindings?.length||0)+' binding row(s) returned.')}catch(e){dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','bad',e.message)}}
function dbCyEsc(v){return String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/[\r\n]+/g,' ')}
function dbTtlEsc(v){return String(v??'').replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r?\n/g,'\\n')}
function dbSlug(v){let s=norm(v).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,70);return s||'item'}
function dbScopeHits(){let val=$('#dbExportScope')?.value||'100',n=val==='all'?currentResults.length:Number(val);return currentResults.slice(0,n)}
function dbNeoExportText(hits){let lines=['// Academic Library -> Neo4j import script','// Generated from the active ranked result set','CREATE CONSTRAINT paper_record IF NOT EXISTS FOR (p:Paper) REQUIRE p.recordId IS UNIQUE;','CREATE INDEX author_name IF NOT EXISTS FOR (n:Author) ON (n.name);','CREATE INDEX keyword_name IF NOT EXISTS FOR (n:Keyword) ON (n.name);',''];for(let h of hits){let o=recObj(h.i),pid='local-'+h.i;lines.push(`MERGE (p:Paper {recordId:'${dbCyEsc(pid)}'}) SET p.title='${dbCyEsc(o.title)}', p.year=${Number(o.year)||'null'}, p.cites=${Number(o.cites)||0}, p.doi='${dbCyEsc(o.doi)}', p.url='${dbCyEsc(o.url)}', p.issn='${dbCyEsc(o.issn)}', p.abstract='${dbCyEsc(o.abstract)}';`);for(let a of splitAuthors(o.authors))lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (a:Author {name:'${dbCyEsc(a)}'}) MERGE (p)-[:AUTHORED_BY]->(a);`);if(o.source)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (j:Journal {name:'${dbCyEsc(o.source)}'}) MERGE (p)-[:PUBLISHED_IN]->(j);`);for(let k of splitKeywords(o.keywords))lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (k:Keyword {name:'${dbCyEsc(k)}'}) MERGE (p)-[:HAS_KEYWORD]->(k);`);if(o.publisher)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (x:Publisher {name:'${dbCyEsc(o.publisher)}'}) MERGE (p)-[:PUBLISHED_BY]->(x);`);if(o.country)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (c:Country {name:'${dbCyEsc(o.country)}'}) MERGE (p)-[:ASSOCIATED_COUNTRY]->(c);`);if(o.year)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (y:Year {value:${Number(o.year)}}) MERGE (p)-[:PUBLISHED_IN_YEAR]->(y);`);lines.push('')}return lines.join('\n')}
function dbTurtleExportText(hits){let L=['@prefix lib: <https://example.org/academic-library/> .','@prefix dcterms: <http://purl.org/dc/terms/> .','@prefix bibo: <http://purl.org/ontology/bibo/> .','@prefix foaf: <http://xmlns.com/foaf/0.1/> .','@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .',''];let declared=new Set();let entity=(kind,label)=>'lib:'+kind+'-'+dbSlug(label);for(let h of hits){let o=recObj(h.i),p='lib:paper-'+h.i,props=[`a bibo:AcademicArticle`,`dcterms:title "${dbTtlEsc(o.title)}"`];if(o.year)props.push(`dcterms:issued "${o.year}"^^xsd:gYear`);if(o.doi)props.push(`bibo:doi "${dbTtlEsc(o.doi)}"`);if(o.issn)props.push(`bibo:issn "${dbTtlEsc(o.issn)}"`);if(o.url)props.push(`dcterms:identifier <${o.url.replace(/>/g,'%3E')}>`);if(o.abstract)props.push(`dcterms:abstract "${dbTtlEsc(o.abstract)}"`);for(let a of splitAuthors(o.authors)){let u=entity('author',a);props.push(`dcterms:creator ${u}`);if(!declared.has(u)){L.push(`${u} a foaf:Person ; foaf:name "${dbTtlEsc(a)}" .`);declared.add(u)}}if(o.source){let u=entity('journal',o.source);props.push(`dcterms:isPartOf ${u}`);if(!declared.has(u)){L.push(`${u} a bibo:Journal ; dcterms:title "${dbTtlEsc(o.source)}" .`);declared.add(u)}}for(let k of splitKeywords(o.keywords)){let u=entity('concept',k);props.push(`dcterms:subject ${u}`);if(!declared.has(u)){L.push(`${u} a lib:ResearchConcept ; dcterms:title "${dbTtlEsc(k)}" .`);declared.add(u)}}if(o.publisher){let u=entity('publisher',o.publisher);props.push(`dcterms:publisher ${u}`);if(!declared.has(u)){L.push(`${u} a foaf:Organization ; foaf:name "${dbTtlEsc(o.publisher)}" .`);declared.add(u)}}if(o.country){let u=entity('country',o.country);props.push(`lib:associatedCountry ${u}`);if(!declared.has(u)){L.push(`${u} a lib:Country ; dcterms:title "${dbTtlEsc(o.country)}" .`);declared.add(u)}}L.push(`${p} ${props.join(' ;\n  ')} .\n`)}return L.join('\n')}
function dbDownloadNeo(){let hits=dbScopeHits();if(!hits.length){toast('Run a search first');return}download('academic_library_neo4j.cypher',dbNeoExportText(hits),'text/plain;charset=utf-8');toast('Neo4j Cypher export created')}
function dbDownloadRdf(){let hits=dbScopeHits();if(!hits.length){toast('Run a search first');return}download('academic_library_graphdb.ttl',dbTurtleExportText(hits),'text/turtle;charset=utf-8');toast('GraphDB Turtle export created')}
function dbTemplate(kind,name){let map={neo:{sample:'MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 75',papers:"MATCH (p:Paper) RETURN p ORDER BY coalesce(p.cites,0) DESC LIMIT 50",authors:'MATCH (p:Paper)-[r:AUTHORED_BY]->(a:Author) RETURN p,r,a LIMIT 100',concepts:'MATCH (p:Paper)-[r:HAS_KEYWORD]->(k:Keyword) RETURN p,r,k LIMIT 120'},rdf:{sample:'SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100',papers:'PREFIX bibo: <http://purl.org/ontology/bibo/>\nPREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s a bibo:AcademicArticle . ?s ?p ?o } LIMIT 120',authors:'PREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s dcterms:creator ?o . BIND(dcterms:creator AS ?p) } LIMIT 120',concepts:'PREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s dcterms:subject ?o . BIND(dcterms:subject AS ?p) } LIMIT 120'}};return map[kind][name]||map[kind].sample}
function dbBindTabs(){$$('.db-tab').forEach(b=>b.onclick=()=>{$$('.db-tab').forEach(x=>x.classList.remove('active'));$$('.db-pane').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#dbPane-'+b.dataset.tab).classList.add('active')})}
function dbIntegrationModal(){showModal(`<div class="db-modal-title"><span class="db-mark">⬡</span><h2>Neo4j + GraphDB Integration Center</h2><span class="badge">Local / server connector</span></div><div class="db-banner"><b>Purpose:</b> connect this academic search portal to a property graph (Neo4j) and/or semantic RDF graph (GraphDB), query them, and visualize returned relationships. Password fields stay only in page memory and are never written to localStorage.</div><div class="db-architecture"><div class="db-archbox"><b>Academic Search UI</b><br><span class="db-mini">27,825 local records</span></div><div class="db-arrow">⇄</div><div class="db-archbox"><b>Neo4j</b><br><span class="db-mini">Cypher property graph</span></div><div class="db-arrow">+</div><div class="db-archbox"><b>GraphDB</b><br><span class="db-mini">SPARQL / RDF semantics</span></div></div><div class="db-tabs"><button class="db-tab active" data-tab="connect">Connections</button><button class="db-tab" data-tab="neo">Cypher Console</button><button class="db-tab" data-tab="rdf">SPARQL Console</button><button class="db-tab" data-tab="export">Build Graph Data</button><button class="db-tab" data-tab="schema">Relationship Model</button></div>
<div class="db-pane active" id="dbPane-connect"><div class="db-card"><h3>Connection mode</h3><p>Direct mode is useful on a local trusted machine. Backend proxy mode is recommended when you publish the website because credentials must not be embedded in public browser code.</p><div class="db-form"><label>Mode<select id="dbMode"><option value="direct">Direct browser → local databases</option><option value="proxy">Backend proxy → databases (recommended for web)</option></select></label><div class="db-security"><b>Security:</b> Do not save production database passwords in this HTML. Enter them only at runtime. A public website should send queries to your own authenticated backend API.</div></div></div><div class="db-links"><div class="db-link-card infra"><b>InfraNodus</b><span>Text-network analysis and knowledge-graph visualisation for research text</span><a href="https://infranodus.com" target="_blank" rel="noopener noreferrer">Open InfraNodus ↗</a></div><div class="db-link-card"><b>Neo4j</b><span>Official website for the Neo4j property-graph database</span><a href="https://neo4j.com" target="_blank" rel="noopener noreferrer">Visit neo4j.com ↗</a></div><div class="db-link-card"><b>GraphDB</b><span>Official website for Ontotext GraphDB (RDF and SPARQL)</span><a href="https://graphdb.ontotext.com" target="_blank" rel="noopener noreferrer">Visit GraphDB ↗</a></div></div><div class="db-grid" style="margin-top:12px"><div class="db-card neo"><h3>Connect to Neo4j</h3><p>Uses the Neo4j HTTP Query API in direct mode.</p><div class="db-form"><label>Neo4j base URL<input id="neoBase" value="${DB_DEFAULTS.neoBase}"></label><div class="db-row"><label>Database<input id="neoDb" value="${DB_DEFAULTS.neoDb}"></label><label>Username<input id="neoUser" value="${DB_DEFAULTS.neoUser}"></label></div><label>Password<input id="neoPass" type="password" autocomplete="off" placeholder="Enter at runtime"></label><label>Proxy endpoint<input id="neoProxy" value="http://localhost:8000/api/neo4j/query"></label></div><div class="db-actions"><button class="primary" id="neoTest">Test Neo4j</button></div><div class="db-status" id="neoStatus"><i></i><span>Not tested</span></div></div><div class="db-card rdf"><h3>Connect to GraphDB</h3><p>Uses the repository SPARQL endpoint in direct mode.</p><div class="db-form"><label>Repository endpoint<input id="graphRepo" value="${DB_DEFAULTS.graphRepo}"></label><div class="db-row"><label>Username (optional)<input id="graphUser" autocomplete="off"></label><label>Password (optional)<input id="graphPass" type="password" autocomplete="off"></label></div><label>Proxy endpoint<input id="graphProxy" value="http://localhost:8000/api/graphdb/query"></label></div><div class="db-actions"><button class="primary" id="graphTest">Test GraphDB</button></div><div class="db-status" id="graphStatus"><i></i><span>Not tested</span></div></div></div></div>
<div class="db-pane" id="dbPane-neo"><div class="db-card neo"><h3>Cypher Query</h3><p>For graph visualization, return nodes and relationships together, e.g. <code>RETURN n,r,m</code>.</p><div class="db-template-row"><button class="ghost" data-neo-t="sample">Sample network</button><button class="ghost" data-neo-t="papers">Top papers</button><button class="ghost" data-neo-t="authors">Author network</button><button class="ghost" data-neo-t="concepts">Concept network</button></div><textarea class="db-query" id="neoQuery">MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 75</textarea><div class="db-actions"><button class="primary" id="neoRun">Run Cypher</button><button class="ghost" id="neoGraphBtn" disabled>Visualize returned graph</button></div><div class="db-status" id="neoStatus2"><i></i><span>Use the Connections tab to test connectivity first.</span></div><div class="db-result" id="neoResult"></div></div></div>
<div class="db-pane" id="dbPane-rdf"><div class="db-card rdf"><h3>SPARQL Query</h3><p>For visualization, use a SELECT query that returns <code>?s ?p ?o</code>.</p><div class="db-template-row"><button class="ghost" data-rdf-t="sample">Sample triples</button><button class="ghost" data-rdf-t="papers">Paper graph</button><button class="ghost" data-rdf-t="authors">Creator links</button><button class="ghost" data-rdf-t="concepts">Subject links</button></div><textarea class="db-query" id="graphQuery">SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100</textarea><div class="db-actions"><button class="primary" id="graphRun">Run SPARQL</button><button class="ghost" id="graphGraphBtn" disabled>Visualize returned graph</button></div><div class="db-status" id="graphStatus2"><i></i><span>Use the Connections tab to test connectivity first.</span></div><div class="db-result" id="graphResult"></div></div></div>
<div class="db-pane" id="dbPane-export"><div class="db-card"><h3>Build graph data from the active library search</h3><p>Export a subset of the current ranked results into database-ready graph formats. This is the safest way to populate your databases before enabling live queries.</p><label class="db-mini">Export scope<select id="dbExportScope" style="margin-left:8px;border:1px solid var(--line);border-radius:8px;padding:7px"><option value="20">Top 20 results</option><option value="100" selected>Top 100 results</option><option value="500">Top 500 results</option><option value="1000">Top 1,000 results</option><option value="all">All current results (large)</option></select></label><div class="db-export-grid" style="margin-top:12px"><div class="db-export-card"><h3>Neo4j property graph</h3><p class="db-mini">Creates Paper, Author, Journal, Keyword, Publisher, Country and Year nodes with explicit bibliographic relationships.</p><button class="primary" id="dbExportNeo">Download .cypher</button></div><div class="db-export-card"><h3>GraphDB semantic graph</h3><p class="db-mini">Creates RDF/Turtle using BIBO, Dublin Core Terms, FOAF and a small project namespace.</p><button class="primary" id="dbExportRdf">Download .ttl</button></div></div><div class="db-security">For your complete 27,825-record corpus, the generated file may be large. Import the file using Neo4j/GraphDB administration tools rather than pasting the whole export into the query console.</div></div></div>
<div class="db-pane" id="dbPane-schema"><div class="db-grid"><div class="db-card neo"><h3>Neo4j relationship model</h3><div class="db-schema"><code>(Paper)-[:AUTHORED_BY]→(Author)</code><br><code>(Paper)-[:PUBLISHED_IN]→(Journal)</code><br><code>(Paper)-[:HAS_KEYWORD]→(Keyword)</code><br><code>(Paper)-[:PUBLISHED_BY]→(Publisher)</code><br><code>(Paper)-[:ASSOCIATED_COUNTRY]→(Country)</code><br><code>(Paper)-[:PUBLISHED_IN_YEAR]→(Year)</code><br><code>(Author)-[:COLLABORATES_WITH]→(Author)</code><br><code>(Keyword)-[:CO_OCCURS_WITH]→(Keyword)</code><br><br>Client-side KG models available: Bibliographic, Co-authorship, Concept co-occurrence, Publishing ecosystem, Temporal impact, NER entity-relation. Later, true citation data can add <code>(Paper)-[:CITES]→(Paper)</code>.</div></div><div class="db-card rdf"><h3>GraphDB semantic model</h3><div class="db-schema"><code>bibo:AcademicArticle</code><br><code>dcterms:creator</code> → <code>foaf:Person</code><br><code>dcterms:isPartOf</code> → <code>bibo:Journal</code><br><code>dcterms:subject</code> → <code>lib:ResearchConcept</code><br><code>dcterms:publisher</code> → <code>foaf:Organization</code><br><code>lib:associatedCountry</code> → <code>lib:Country</code><br><br>NER, research gaps and hypotheses can later be formalized as additional RDF classes and predicates.</div></div></div></div>`);
 dbBindTabs();$('#neoTest').onclick=dbTestNeo;$('#graphTest').onclick=dbTestGraph;$('#neoRun').onclick=dbRunNeo;$('#graphRun').onclick=dbRunGraph;$('#neoGraphBtn').onclick=()=>dbOpenGenericGraph(dbNeoGraph(DB_LAST_NEO),'Neo4j Live Knowledge Graph','Nodes and relationships returned by your Cypher query.');$('#graphGraphBtn').onclick=()=>dbOpenGenericGraph(dbGraphDbGraph(DB_LAST_RDF),'GraphDB Live Semantic Graph','RDF subject–predicate–object bindings returned by your SPARQL query.');$$('[data-neo-t]').forEach(b=>b.onclick=()=>$('#neoQuery').value=dbTemplate('neo',b.dataset.neoT));$$('[data-rdf-t]').forEach(b=>b.onclick=()=>$('#graphQuery').value=dbTemplate('rdf',b.dataset.rdfT));$('#dbExportNeo').onclick=dbDownloadNeo;$('#dbExportRdf').onclick=dbDownloadRdf;
}


/* ===== Related Papers (local, content-based) ===== */
const RP_STOP=new Set('the and for with from into over under using based study studies analysis approach between among about their this that these those toward towards effect effects review case new use used'.split(' '));
function rpTerms(s){return [...new Set(tokens(s||'').filter(w=>w.length>3&&!RP_STOP.has(w)))]}
function relatedPapers(seed,limit=10){
  const base=recObj(seed);
  const bAuth=new Set((base.authors||'').split(';').map(norm).filter(Boolean));
  const bKey=new Set(tokens(base.keywords||'').filter(x=>x.length>2));
  const bTit=new Set(rpTerms(base.title));
  const out=[];
  for(let j=0;j<R.length;j++){
    if(j===seed)continue;
    const o=recObj(j);let score=0;const reasons=[];
    if(o.source&&o.source===base.source){score+=3;reasons.push('same journal')}
    const sh=(o.authors||'').split(';').map(norm).filter(a=>a&&bAuth.has(a));
    if(sh.length){score+=8*sh.length;reasons.push('shared author')}
    const kov=new Set(tokens(o.keywords||'').filter(x=>x.length>2&&bKey.has(x)));
    if(kov.size){score+=2*kov.size;reasons.push('shared keywords')}
    const tov=rpTerms(o.title).filter(t=>bTit.has(t));
    if(tov.length){score+=1.5*tov.length;reasons.push('title terms')}
    if(score>=3)out.push({i:j,score,reasons});
  }
  out.sort((a,b)=>b.score-a.score||(R[b.i][0]-R[a.i][0]));
  return out.slice(0,limit);
}
function rpSeed(){return (currentResults&&currentResults.length)?currentResults[0].i:null}
function rpDraw(seed){
  const base=recObj(seed),list=relatedPapers(seed,12),max=(list[0]&&list[0].score)||1;
  showModal(`<h2>◇ Related papers</h2>
    <p class="tiny">Based on <b>${esc(base.title||'Untitled')}</b>. Ranked locally by shared authors, journal, keywords and title terms, so it works offline.</p>
    <div class="related-list">${list.map(x=>{const o=recObj(x.i);return `<div class="related-item rp-item"><button class="rp-open" type="button" data-open-detail="${x.i}"><b>${esc(o.title||'Untitled')}</b><div class="tiny">${esc(o.authors||'')} · ${o.year||'n/a'} · ${esc(o.source||'')}</div><div class="rp-tags">${x.reasons.map(r=>`<span class="badge">${r}</span>`).join('')}</div><div class="bar"><i style="width:${Math.max(4,x.score/max*100).toFixed(0)}%"></i></div></button><div class="actions"><button type="button" data-rp-seed="${x.i}">Use as seed</button></div></div>`}).join('')||'<div class="note">No strongly related papers found for this record.</div>'}</div>`);
  $$('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)));
  $$('[data-rp-seed]').forEach(b=>b.onclick=()=>rpDraw(Number(b.dataset.rpSeed)));
}
function relatedPapersModal(){
  const seed=rpSeed();
  if(seed===null){showModal('<h2>◇ Related papers</h2><div class="note">Run a search first. Related papers are ranked from the top result, and you can switch the seed paper from inside this window.</div>');return}
  rpDraw(seed);
}
function updateRelatedPanel(){
  const el=document.getElementById('relatedPanelList');if(!el)return;
  const seed=rpSeed();
  if(seed===null){el.innerHTML='<div class="tiny">Run a search to see related papers.</div>';return}
  const list=relatedPapers(seed,5);
  el.innerHTML=list.length?list.map(x=>{const o=recObj(x.i);return `<button class="rp-rec" type="button" data-open-detail="${x.i}"><strong>${esc(o.title||'Untitled')}</strong><span class="tiny">${esc(o.authors||'')}</span></button>`}).join(''):'<div class="tiny">No strongly related papers for the top result.</div>';
  el.querySelectorAll('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)));
}
