
/* ===== KG clarity layer: numbered papers, readable halo labels, focus highlighting, clickable type legend, results + key-findings panel ===== */
(()=>{
'use strict';
if(typeof KG==='undefined'||typeof kgDraw!=='function')return;
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const E=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const TC=t=>KG_COLORS[t]||'#64748b',cut=(s,n)=>{s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s};
const st=document.createElement('style');st.textContent=`
.kgx-leg{position:absolute;left:10px;top:10px;right:10px;display:flex;flex-wrap:wrap;gap:5px;z-index:2;pointer-events:none}
.kgx-chip{pointer-events:auto;display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;background:rgba(255,255,255,.95);border-radius:999px;padding:3px 10px 3px 8px;font:600 12px system-ui,sans-serif;color:#1e293b;cursor:default}
button.kgx-chip{cursor:pointer}button.kgx-chip:hover{background:#eef5fb;border-color:#93b4d3}.kgx-chip.off{opacity:.45;text-decoration:line-through}
.kgx-chip i{width:11px;height:11px;border-radius:50%;display:inline-block}.kgx-chip b{color:#475569;font-weight:700}
.kgx-selbox{position:sticky;top:-12px;z-index:3;background:#fff;border-bottom:2px solid #dbe5f0;margin:-4px -4px 10px;padding:4px 4px 8px;max-height:44%;overflow:auto}
.kgx-sec{border-top:1px solid var(--line);margin-top:10px;padding-top:6px}.kgx-sec>summary{cursor:pointer;font-weight:700;font-size:13px;padding:3px 0}
.kgx-it{display:flex;gap:8px;align-items:flex-start;width:100%;text-align:left;border:1px solid transparent;background:#fff;border-radius:8px;padding:5px 6px;margin:2px 0;font:inherit;font-size:12px;cursor:pointer;color:#1e293b}
.kgx-it:hover,.kgx-it:focus{background:#eef5fb;border-color:#b6cde3}.kgx-it.on{background:#fff4e0;border-color:#f59e0b}
.kgx-rk{flex:none;min-width:22px;height:22px;border-radius:50%;color:#fff;font-weight:700;font-size:11px;display:inline-flex;align-items:center;justify-content:center}
.kgx-tx{flex:1;min-width:0;line-height:1.3}.kgx-tx small{display:block;color:#64748b;font-size:11px}.kgx-ct{flex:none;font-weight:700;color:#475569}
.kgx-sub{font-size:11px;font-weight:700;color:#64748b;margin:8px 0 2px}
`;document.head.appendChild(st);

function label(n){return n.type==='paper'?((n.rank?n.rank+'. ':'')+n.label):n.label}
window.kgDraw=function(){
 if(!KG.ctx||!KG.canvas)return;
 const ctx=KG.ctx,rect=KG.canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);ctx.fillStyle='#fbfcfe';ctx.fillRect(0,0,rect.width,rect.height);
 const foc=KG.selected||KG.hover,off=KG.hiddenRel||new Set(),nb=new Set(),sc=KG.scale,L=[];
 if(foc){nb.add(foc);KG.edges.forEach(e=>{if(e.a===foc||e.b===foc){nb.add(e.a);nb.add(e.b)}})}
 ctx.save();ctx.translate(KG.tx,KG.ty);ctx.scale(sc,sc);ctx.lineCap='round';
 KG.edges.forEach(e=>{if(off.has(e.relation))return;
  const act=foc&&(e.a===foc||e.b===foc),dim=foc&&!act,col=e.relation==='related paper'?'109,40,217':e.hit?'217,119,6':'71,85,105';
  ctx.strokeStyle=`rgba(${col},${dim?.07:act?.95:e.hit?.8:.4})`;ctx.lineWidth=(act?2.8:e.hit?2.1:1.3)/Math.sqrt(sc);
  ctx.beginPath();ctx.moveTo(e.a.x,e.a.y);ctx.lineTo(e.b.x,e.b.y);ctx.stroke();
  const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1,r=kgRadius(e.b)+4,ux=dx/d,uy=dy/d;
  if(!dim&&d>r*3){const tx=e.b.x-ux*r,ty=e.b.y-uy*r;ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(tx-ux*8-uy*4,ty-uy*8+ux*4);ctx.lineTo(tx-ux*8+uy*4,ty-uy*8-ux*4);ctx.fill()}
  if((KG.showEdgeLabels||act)&&sc>.5&&!dim){let ang=Math.atan2(dy,dx);if(ang>Math.PI/2||ang<-Math.PI/2)ang+=Math.PI;ctx.save();ctx.translate((e.a.x+e.b.x)/2,(e.a.y+e.b.y)/2);ctx.rotate(ang);ctx.font='600 10px system-ui';const w=ctx.measureText(e.relation).width;ctx.fillStyle='rgba(255,255,255,.95)';ctx.fillRect(-w/2-3,-8,w+6,13);ctx.fillStyle=e.hit?'#b45309':'#334155';ctx.textAlign='center';ctx.fillText(e.relation,0,2);ctx.restore()}
 });
 KG.nodes.forEach(n=>{
  const kz=Math.min(1.9,1/Math.sqrt(Math.max(.3,sc))),r=Math.max(9,kgRadius(n)+2)*kz,isSel=KG.selected===n,faded=foc&&!nb.has(n);ctx.globalAlpha=faded?.22:1;
  if(isSel){ctx.beginPath();ctx.arc(n.x,n.y,r+7,0,Math.PI*2);ctx.fillStyle='rgba(245,158,11,.28)';ctx.fill()}
  ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);ctx.fillStyle=TC(n.type);ctx.fill();
  ctx.lineWidth=2.5/Math.max(.6,sc);ctx.strokeStyle=isSel?'#111827':n.hit?'#f59e0b':'#ffffff';ctx.stroke();
  if(n.type==='paper'&&n.rank&&r*sc>=7){ctx.fillStyle='#fff';ctx.font='700 '+Math.min(r*1.15,13/sc)+'px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(n.rank),n.x,n.y+.5)}
  const root=n.type==='query'||n.root,show=foc?nb.has(n)||root:(root||n.hit||n.type==='paper'||(n.weight||1)>1||KG.nodes.length<=40);
  if(show)L.push({x:n.x,y:n.y,r,l:cut(root?n.label:n.type==='paper'?n.label:n.label,n.type==='paper'?40:30),pre:n.type==='paper'&&n.rank?'':'',col:n.type==='paper'?'#17314f':TC(n.type),pri:isSel?0:(foc&&nb.has(n))?1:(root||n.hit)?2:n.type==='paper'?3:4,must:foc&&nb.has(n),bold:root||n.hit||isSel,faded});
 });
 ctx.globalAlpha=1;ctx.restore();
 ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.textAlign='center';ctx.textBaseline='alphabetic';ctx.lineJoin='round';
 const boxes=[];
 L.sort((a,b)=>a.pri-b.pri).forEach(o=>{
  const sx=o.x*sc+KG.tx,sy=o.y*sc+KG.ty+o.r*sc+15;if(sx<-80||sx>rect.width+80||sy<-20||sy>rect.height+20)return;
  ctx.font=(o.bold?'700 13px':'600 12px')+' system-ui, sans-serif';
  const w=ctx.measureText(o.l).width+6,x0=sx-w/2,y0=sy-12,h=17;
  if(!o.must&&boxes.some(b=>x0<b.x1&&x0+w>b.x0&&y0<b.y1&&y0+h>b.y0))return;
  boxes.push({x0,x1:x0+w,y0,y1:y0+h});
  ctx.globalAlpha=o.faded?.35:1;ctx.strokeStyle='rgba(255,255,255,.96)';ctx.lineWidth=4;ctx.strokeText(o.l,sx,sy);ctx.fillStyle=o.col;ctx.fillText(o.l,sx,sy);
 });
 ctx.restore();
};
window.kgDrawLabels=function(){};

function legend(){
 const stg=Q('.kg-stage');if(!stg)return;let el=stg.querySelector('.kgx-leg');
 if(!el){el=document.createElement('div');el.className='kgx-leg';stg.appendChild(el);
  el.addEventListener('click',e=>{const b=e.target.closest('[data-kgt]');if(!b)return;const cb=QA('.kgType').find(x=>x.value===b.dataset.kgt);if(cb){cb.checked=!cb.checked;if(cb.onchange)cb.onchange()}})}
 const c={};KG.nodes.forEach(n=>{if(n.type!=='query'&&!n.root)c[n.type]=(c[n.type]||0)+1});
 const cbs=QA('.kgType'),types=[...new Set(['paper',...Object.keys(c),...cbs.map(x=>x.value)])];
 el.innerHTML=types.map(t=>{const cb=cbs.find(x=>x.value===t),n=c[t]||0;if(!cb&&!n)return '';const tag=cb?'button type="button"':'span';
  return `<${tag} class="kgx-chip${cb&&!cb.checked?' off':''}" ${cb?`data-kgt="${t}" title="${cb.checked?'Click to hide':'Click to show'} ${E(KG_NAMES[t]||t)}"`:''}><i style="background:${TC(t)}"></i>${E(KG_NAMES[t]||t)} <b>${n}</b></${cb?'button':'span'}>`}).join('')}

function panel(){
 const dg=new Map();KG.edges.forEach(e=>{dg.set(e.a,(dg.get(e.a)||0)+1);dg.set(e.b,(dg.get(e.b)||0)+1)});
 const ix=n=>KG.nodes.indexOf(n),papers=KG.nodes.filter(n=>n.type==='paper').sort((a,b)=>(a.rank||999)-(b.rank||999)||(b.cites||0)-(a.cites||0));
 let h='';
 if(papers.length)h+=`<details class="kgx-sec" open><summary>Papers in this graph (${papers.length})</summary>${papers.slice(0,60).map(n=>`<button type="button" class="kgx-it" data-kgi="${ix(n)}"><span class="kgx-rk" style="background:${TC('paper')}">${n.rank||'•'}</span><span class="kgx-tx">${E(cut(n.label,90))}<small>${n.year||''}${n.cites!=null?' · cited '+Number(n.cites).toLocaleString()+'×':''}</small></span></button>`).join('')}</details>`;
 const groups=[['author','Authors'],['journal','Journals'],['keyword','Keywords'],['concept','Concepts'],['publisher','Publishers'],['place','Places'],['year','Years']].map(([t,T])=>{const l=KG.nodes.filter(n=>n.type===t).sort((a,b)=>(dg.get(b)||0)-(dg.get(a)||0)).slice(0,5);return l.length?`<div class="kgx-sub">${T}, most connected</div>`+l.map(n=>`<button type="button" class="kgx-it" data-kgi="${ix(n)}"><span class="kgx-tx">${E(cut(n.label,60))}</span><span class="kgx-ct">${dg.get(n)||0}</span></button>`).join(''):''}).join('');
 if(groups)h+=`<details class="kgx-sec" open><summary>Key findings</summary>${groups}</details>`;
 return h}
const _s=window.kgStats;
window.kgStats=function(){const base=_s.apply(this,arguments);try{legend()}catch(e){}let p='';try{p=panel()}catch(e){}return base+p};
const _o=window.kgOpen;
window.kgOpen=function(){
 const r=_o.apply(this,arguments),side=Q('.kg-side'),stats=Q('#kgStats');
 if(side&&!side.dataset.kgx){side.dataset.kgx='1';const h4=QA('.kg-side h4').find(x=>/Selected node/i.test(x.textContent)),sel=Q('#kgSelection');
  if(h4&&sel){const w=document.createElement('div');w.className='kgx-selbox';side.insertBefore(w,side.firstChild);w.appendChild(h4);w.appendChild(sel)}}
 if(stats&&!stats.dataset.kgx){stats.dataset.kgx='1';stats.addEventListener('click',e=>{const b=e.target.closest('[data-kgi]');if(!b)return;const n=KG.nodes[+b.dataset.kgi];if(!n)return;kgSelect(n);
  const rc=KG.canvas.getBoundingClientRect();KG.tx=rc.width/2-n.x*KG.scale;KG.ty=rc.height/2-n.y*KG.scale;kgDraw();
  QA('.kgx-it.on').forEach(x=>x.classList.remove('on'));b.classList.add('on');const sb=Q('.kgx-selbox');if(sb)sb.scrollTop=0})}
 try{legend();kgDraw()}catch(e){}
 return r};
})();
