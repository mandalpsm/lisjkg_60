
/* ===== Shared styles and helpers (dashboard v3 + evaluation lab) ===== */
(()=>{
const st=document.createElement('style');
st.textContent=`
:root{--d3-ink:#111827;--d3-muted:#4b5563;--d3-line:#d1d5db;--d3-bar:#1f4e79;--d3-bar-on:#7c2d12;--d3-focus:#1d4ed8;--d3-paper:#ffffff;--d3-wash:#f9fafb}
#modalCard.x2-wide{width:min(1180px,96vw);max-height:94vh;overflow:auto}
#modalCard .d3-root{color:var(--d3-ink);font-size:14px;line-height:1.5}
#modalCard .d3-root h2{margin:0 0 6px;font-size:20px}
.d3-tabs{display:flex;gap:4px;flex-wrap:wrap;border-bottom:2px solid var(--d3-bar);margin:8px 0 12px}
.d3-tab{border:0;background:transparent;padding:9px 14px;border-radius:8px 8px 0 0;font-weight:700;font-size:14px;color:var(--d3-bar);cursor:pointer;font:inherit;font-weight:700}
.d3-tab[aria-selected="true"]{background:var(--d3-bar);color:#fff}
.d3-tab:focus-visible,.d3-bar:focus-visible,.d3-btn:focus-visible,.d3-link:focus-visible,.d3-root select:focus-visible,.d3-root input:focus-visible,.d3-root summary:focus-visible,[role="button"]:focus-visible{outline:3px solid var(--d3-focus);outline-offset:2px}
.d3-filters{background:var(--d3-wash);border:1px solid var(--d3-line);border-radius:10px;padding:10px 12px;margin-bottom:12px}
.d3-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:4px 0}
.d3-row label,.d3-filters label{font-size:13px;color:var(--d3-muted);display:inline-flex;gap:6px;align-items:center}
.d3-root select,.d3-root input[type=number]{border:1px solid #9ca3af;border-radius:6px;padding:5px 7px;background:#fff;color:var(--d3-ink);font:inherit;font-size:13px}
.d3-btn{border:1px solid #6b7280;background:#fff;color:var(--d3-ink);border-radius:6px;padding:6px 11px;cursor:pointer;font:inherit;font-size:13px}
.d3-btn:hover{background:#f3f4f6}
.d3-btn.primary{background:var(--d3-bar);color:#fff;border-color:var(--d3-bar)}
.d3-btn.primary:hover{background:#173d61}
.d3-chips{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px;min-height:28px}
.d3-chip{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #9ca3af;border-radius:999px;padding:3px 4px 3px 10px;font-size:13px}
.d3-chip button{border:0;background:#e5e7eb;border-radius:999px;width:22px;height:22px;cursor:pointer;font-size:14px;line-height:1}
.d3-muted{color:var(--d3-muted)}
.d3-prov{font-size:13px;color:var(--d3-muted);background:#fff;border-left:4px solid var(--d3-bar);padding:6px 10px;margin:0 0 12px}
.d3-prov p{margin:2px 0}
.d3-prov summary{cursor:pointer;color:var(--d3-bar);font-weight:600;margin-top:4px}
.d3-prov ol{margin:6px 0 2px 18px;padding:0}
.d3-prov li{margin:3px 0}
.d3-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin:0 0 14px}
.d3-kpi{border:1px solid var(--d3-line);border-radius:8px;padding:9px 11px;background:#fff;margin:0}
.d3-kpi dt{font-size:12.5px;color:var(--d3-muted)}
.d3-kpi dd{margin:2px 0 0;font-size:20px;font-weight:700;color:var(--d3-ink)}
.d3-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.d3-card{border:1px solid var(--d3-line);border-radius:10px;padding:12px 14px;background:#fff;min-width:0}
.d3-card.wide{grid-column:1/-1}
.d3-card h3{margin:0 0 4px;font-size:15px;color:var(--d3-ink)}
.d3-desc{margin:0 0 8px;font-size:13px;color:var(--d3-muted)}
.d3-foot{margin:8px 0 0;font-size:12.5px;color:var(--d3-muted)}
.d3-bars{list-style:none;margin:0;padding:0}
.d3-bars li{margin:0}
.d3-bar{display:grid;grid-template-columns:minmax(120px,38%) 1fr auto;gap:10px;align-items:center;width:100%;border:0;background:transparent;padding:4px 6px;margin:0;font:inherit;font-size:13px;text-align:left;color:var(--d3-ink);cursor:pointer;border-radius:6px}
.d3-bar:hover{background:#f3f4f6}
.d3-bar[aria-pressed="true"]{background:#fff7ed;outline:1px solid var(--d3-bar-on)}
.d3-bar.d3-static{cursor:default}
.d3-bar.d3-static:hover{background:transparent}
.d3-lbl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.d3-track{height:12px;background:#e5e7eb;border-radius:3px;overflow:hidden;display:block}
.d3-fill{display:block;height:100%;background:var(--d3-bar)}
.d3-bar[aria-pressed="true"] .d3-fill{background:var(--d3-bar-on)}
.d3-val{font-variant-numeric:tabular-nums;color:var(--d3-muted);white-space:nowrap;font-size:12.5px}
.d3-tbl{margin-top:8px;font-size:13px}
.d3-tbl summary{cursor:pointer;color:var(--d3-bar);font-weight:600}
.d3-root table{width:100%;border-collapse:collapse;font-size:13px}
.d3-root th{text-align:left;background:#f3f4f6;padding:6px 8px;border-bottom:1px solid #9ca3af;font-size:12.5px;color:var(--d3-ink)}
.d3-root td{padding:6px 8px;border-bottom:1px solid var(--d3-line);vertical-align:top;font-variant-numeric:tabular-nums}
.d3-root caption{text-align:left;font-weight:600;padding:4px 0}
.d3-root tr.d3-sel td{background:#fff7ed}
.d3-scroll{overflow-x:auto}
.d3-link{border:0;background:none;color:var(--d3-bar);text-decoration:underline;cursor:pointer;font:inherit;padding:0;text-align:left}
.d3-svg{width:100%;height:auto;display:block;background:#fff;border:1px solid var(--d3-line);border-radius:8px}
.d3-svg g{cursor:pointer}
.d3-svg g:focus{outline:none}
.d3-svg g:focus circle{stroke:var(--d3-focus);stroke-width:3}
.d3-legend{list-style:none;padding:0;margin:8px 0 0;display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12.5px;color:var(--d3-muted)}
.d3-sw{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:5px;vertical-align:middle}
.d3-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.d3-status{font-size:12.5px;color:var(--d3-muted);margin-top:10px}
@media (max-width:820px){.d3-grid{grid-template-columns:1fr}.d3-bar{grid-template-columns:1fr auto}.d3-bar .d3-track{grid-column:1/-1}}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
/* evaluation lab helpers (unchanged look, kept for the Evaluate tabs) */
.x2-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:8px 0 14px}
.x2-kpi{border:1px solid var(--d3-line);border-radius:10px;padding:10px 12px;background:#fff}
.x2-kpi b{display:block;font-size:20px;color:var(--d3-bar)}
.x2-kpi span{font-size:12px;color:var(--d3-muted)}
.x2-note{font-size:12.5px;color:var(--d3-muted);margin:4px 0 10px}
.x2-tbl{width:100%;border-collapse:collapse;font-size:12.5px}
.x2-tbl th{text-align:left;background:#f3f4f6;padding:7px;border-bottom:1px solid #9ca3af;font-size:12px;color:var(--d3-ink)}
.x2-tbl td{padding:7px;border-bottom:1px solid var(--d3-line);vertical-align:top}
.x2-bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}
.x2-badge{display:inline-block;font-size:11px;border-radius:999px;padding:1px 8px;background:#eef5fa;color:var(--d3-bar);border:1px solid #d3e5f0}
.x2-svg{width:100%;height:auto;display:block;background:#fbfcfe;border:1px solid var(--d3-line);border-radius:10px}
.x2-root{}
`;
document.head.appendChild(st);
const fmt=n=>Number(n||0).toLocaleString();
const pc=(x,d=1)=>x==null?'–':(100*x).toFixed(d)+'%';
const kpi=(v,l)=>`<div class="x2-kpi"><b>${v}</b><span>${l}</span></div>`;
const inc=(m,k)=>{if(k===''||k==null||k===0)return;m.set(k,(m.get(k)||0)+1)};
const topN=(m,n)=>[...m.entries()].sort((a,b)=>b[1]-a[1]||String(a[0]).localeCompare(String(b[0]))).slice(0,n).map(([name,count])=>({name:String(name),count}));
const csvOf=rows=>rows.map(r=>r.map(c=>'"'+String(c??'').replace(/"/g,'""')+'"').join(',')).join('\n');

/* ===== Dashboard v3: calculated results with provenance, interactive filters, accessible markup ===== */
const D={otherOpen:false,tab:'overview',scope:'all',from:'',to:'',topN:10,minKw:3,model:'bibliographic',limit:20,filters:[],resRef:null,memo:new Map(),snap:{},hubs:[],computed:null};
const DTABS=[['overview','Overview'],['query','Query explorer'],['kg','Knowledge graph'],['export','Export']];
const BANDS=[['Below 10',0,10],['10 to 24',10,25],['25 to 49',25,50],['50 to 99',50,100],['100 or more',100,Infinity]];
const FIELD_ORDER=['Title','Authors','Keywords','Journal','Abstract','DOI'];
const METHOD=[
  'Counts: a record is counted for a journal, publisher, country, year, keyword or author only when that field has a value. Records without a value are reported as missing, not as zero.',
  'Keywords and authors are grouped case- and accent-insensitively, the same way search matches them. The most frequent spelling is displayed.',
  'Share = records in a row ÷ records in the base (the active scope and filters).',
  'Citations: mean = total citations ÷ records; median = middle value, or the mean of the two middle values when the count is even.',
  'Term match: a term matches when it occurs as a substring of the normalised text, the same rule search scoring uses. For example, “literacy” also matches “illiteracy”.',
  'Term coverage = matches containing the term ÷ matches. Collection share = collection records containing the term ÷ all collection records. Enrichment = coverage ÷ collection share.',
  'Related keyword lift = share of matches with the keyword ÷ share of the whole collection with it. Only keywords with at least the minimum number of matching records are listed.',
  'Knowledge graph: nodes are merged by type and normalised label; links come from the selected model schema. Density = 2E ÷ (N(N−1)). Components are connected groups found on undirected links. The graph is built from the top-ranked matches, and the number used is shown.',
  'Hub map: nodes sit on a circle for readability, so distances carry no meaning. Circle size grows with the number of links.',
  'Average precision, ROC-AUC and nDCG are reported on the Evaluate tabs, not here.'
];

const NUM=n=>Number(n||0).toLocaleString();
const PCT=(x,d=1)=>(x==null||!isFinite(x))?'n/a':(100*x).toFixed(d)+'%';
const DEC=(x,d=2)=>(x==null||!isFinite(x))?'n/a':Number(x).toFixed(d);

/* memoised per result set: invalidated when a new search replaces currentResults */
function memo(kind,key,fn){
  if(D.resRef!==currentResults){D.memo.clear();D.resRef=currentResults}
  const k=kind+'|'+key;
  if(!D.memo.has(k)){if(D.memo.size>80)D.memo.clear();D.memo.set(k,fn())}
  return D.memo.get(k);
}
const allIds=()=>memo('all','',()=>R.map((_,i)=>i));
const filterKey=()=>JSON.stringify([D.from,D.to,D.filters]);

function matchFilter(i,f){
  const r=R[i];
  switch(f.field){
    case 'journal':   return (S[r[4]]||'')===f.value;
    case 'publisher': return (PUB[r[5]]||'')===f.value;
    case 'country':   return (CO[r[7]]||'')===f.value;
    case 'year':      return r[3]===Number(f.value);
    case 'keyword':   return splitKeywords(r[11]).some(k=>norm(k)===f.key);
    case 'author':    return splitAuthors(r[1]).some(a=>norm(a)===f.key);
  }
  return true;
}
function applyFilters(ids){
  let out=ids;
  if(D.from||D.to)out=out.filter(i=>(!D.from||R[i][3]>=Number(D.from))&&(!D.to||R[i][3]<=Number(D.to)));
  for(const f of D.filters)out=out.filter(i=>matchFilter(i,f));
  return out;
}
/* Base of the overview: whole collection or current results, then the year range and dashboard filters */
const baseIds=()=>memo('base',D.scope+'|'+filterKey(),()=>applyFilters(D.scope==='results'?currentResults.map(h=>h.i):allIds()));
/* Matches of the current query, ranked order kept */
const matchIds=()=>memo('match',filterKey(),()=>applyFilters(currentResults.map(h=>h.i)));

/* grouping helpers */
function plainAdd(map,key){if(key==='')return;map.set(key,(map.get(key)||0)+1)}
function groupAdd(map,names){
  const seen=new Set();
  for(const name of names){
    const k=norm(name).trim();
    if(!k||seen.has(k))continue;
    seen.add(k);
    let e=map.get(k);if(!e){e={count:0,forms:new Map()};map.set(k,e)}
    e.count++;e.forms.set(name,(e.forms.get(name)||0)+1);
  }
}
function groupName(e){let best=null,bc=-1;for(const [f,c] of e.forms){if(c>bc||(c===bc&&f<best)){best=f;bc=c}}return best}
function rowsFrom(entries,n,topN){
  return entries.sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name)).slice(0,topN).map(e=>({...e,share:n?e.count/n:null}));
}

/* Core statistics for any set of record indices. Every number is computed from the records; nothing is estimated. */
function computeStats(ids){
  const n=ids.length;
  const miss={journal:0,publisher:0,country:0,year:0,keywords:0,authors:0,doi:0,abstract:0,url:0};
  const js=new Map(),pb=new Map(),co=new Map(),yr=new Map(),kw=new Map(),au=new Map(),cit=[];
  let sum=0,zero=0,max=0;
  for(const i of ids){
    const r=R[i],c=Number(r[0])||0;
    cit.push(c);sum+=c;if(c===0)zero++;if(c>max)max=c;
    const j=S[r[4]]||'';if(j)plainAdd(js,j);else miss.journal++;
    const p=PUB[r[5]]||'';if(p)plainAdd(pb,p);else miss.publisher++;
    const cc=CO[r[7]]||'';if(cc)plainAdd(co,cc);else miss.country++;
    if(r[3]>0)plainAdd(yr,r[3]);else miss.year++;
    const ks=splitKeywords(r[11]);if(!ks.length)miss.keywords++;groupAdd(kw,ks);
    const as=splitAuthors(r[1]);if(!as.length)miss.authors++;groupAdd(au,as);
    if(!r[9])miss.doi++;if(!r[12])miss.abstract++;if(!r[8])miss.url++;
  }
  cit.sort((a,b)=>a-b);
  const median=n?(n%2?cit[(n-1)/2]:(cit[n/2-1]+cit[n/2])/2):null;
  const years=[...yr.keys()];
  const ylo=years.length?Math.min(...years):null,yhi=years.length?Math.max(...years):null;
  const series=[];if(ylo!=null)for(let y=ylo;y<=yhi;y++)series.push({year:y,count:yr.get(y)||0,share:n?(yr.get(y)||0)/n:null});
  const buckets=[['0 citations',0,0],['1 to 4',1,4],['5 to 9',5,9],['10 to 24',10,24],['25 to 49',25,49],['50 to 99',50,99],['100 or more',100,Infinity]]
    .map(([label,a,b])=>{const c=cit.filter(x=>x>=a&&x<=b).length;return {label,count:c,share:n?c/n:null}});
  const most=[...ids].sort((a,b)=>(R[b][0]-R[a][0])||(a-b)).slice(0,10);
  return {n,miss,sum,mean:n?sum/n:null,median,max:n?max:null,zero,buckets,series,
    ylo,yhi,
    distinct:{journals:js.size,publishers:pb.size,countries:co.size,keywords:kw.size,authors:au.size},
    journals:rowsFrom([...js].map(([k,c])=>({name:k,count:c})),n,D.topN),
    publishers:rowsFrom([...pb].map(([k,c])=>({name:k,count:c})),n,D.topN),
    countries:rowsFrom([...co].map(([k,c])=>({name:k,count:c})),n,D.topN),
    keywords:rowsFrom([...kw.values()].map(e=>({name:groupName(e),count:e.count,key:norm(groupName(e))})),n,D.topN),
    authors:rowsFrom([...au.values()].map(e=>({name:groupName(e),count:e.count,key:norm(groupName(e))})),n,D.topN),
    most:most.map(i=>({i,title:R[i][2],year:R[i][3],source:S[R[i][4]]||'',cites:R[i][0]||0}))};
}
const overviewStats=()=>memo('ov',D.scope+'|'+filterKey()+'|'+D.topN,()=>computeStats(baseIds()));

/* Query explorer: what the current query finds */
let FIELD_TEXT=null;
function fieldTexts(){if(!FIELD_TEXT)FIELD_TEXT=INDEX.map(x=>x.t+' '+x.a+' '+x.k+' '+x.s+' '+x.b);return FIELD_TEXT}
function fieldOf(label){
  if(/DOI/.test(label))return 'DOI';
  if(/keyword/.test(label))return 'Keywords';
  if(/author/.test(label))return 'Authors';
  if(/journal/.test(label))return 'Journal';
  if(/abstract/.test(label))return 'Abstract';
  return 'Title';
}
function queryStats(){
  return memo('q',filterKey()+'|'+D.minKw+'|'+D.topN+'|'+state.query.trim(),()=>{
    const q=state.query.trim(),ids=matchIds(),M=ids.length,N=R.length;
    const toks=[...new Set(tokens(q.replace(/"[^"]*"/g,' ')))];
    const phr=[...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean);
    const hitOf=new Map(currentResults.map(h=>[h.i,h]));
    const txt=fieldTexts(),ttl=INDEX;
    const fieldCount=new Map(),bandCount=BANDS.map(()=>0),scores=[];
    let allTitle=0,anyTerm=0;
    for(const i of ids){
      const h=hitOf.get(i);
      scores.push(h.score);
      new Set((h.why||[]).map(w=>fieldOf(w[0]))).forEach(f=>plainAdd(fieldCount,f));
      const b=BANDS.findIndex(([,lo,hi])=>h.score>=lo&&h.score<hi);if(b>=0)bandCount[b]++;
      if(toks.every(t=>ttl[i].t.includes(t))&&phr.every(p=>ttl[i].t.includes(p)))allTitle++;
      if(toks.some(t=>txt[i].includes(t)))anyTerm++;
    }
    scores.sort((a,b)=>a-b);
    const medScore=M?(M%2?scores[(M-1)/2]:(scores[M/2-1]+scores[M/2])/2):null;
    const meanScore=M?scores.reduce((s,x)=>s+x,0)/M:null;
    const collTerm=memo('termcoll',toks.join('|'),()=>toks.map(t=>{let c=0;for(let i=0;i<N;i++)if(txt[i].includes(t))c++;return c}));
    const terms=toks.map((t,k)=>{
      const inM=ids.filter(i=>txt[i].includes(t)).length,inT=ids.filter(i=>ttl[i].t.includes(t)).length;
      const cov=M?inM/M:null,cs=collTerm[k]/N;
      return {term:t,inMatches:inM,inTitle:inT,inCollection:collTerm[k],coverage:cov,collectionShare:cs,enrichment:(cs&&cov!=null)?cov/cs:null};
    });
    const collKw=memo('kwcoll','',()=>{const m=new Map();for(let i=0;i<N;i++)groupAdd(m,splitKeywords(R[i][11]));return m});
    const mkw=new Map();ids.forEach(i=>groupAdd(mkw,splitKeywords(R[i][11])));
    const qSet=new Set(toks.map(t=>norm(t)));
    const related=[];
    for(const [key,e] of mkw){
      if(e.count<D.minKw||qSet.has(key))continue;
      const cc=(collKw.get(key)||{count:e.count}).count;
      const cov=e.count/M,cs=cc/N;
      related.push({name:groupName(e),key,count:e.count,share:cov,lift:cs?cov/cs:null,collection:cc});
    }
    related.sort((a,b)=>(b.lift-a.lift)||(b.count-a.count)||a.name.localeCompare(b.name));
    const st=computeStats(ids);
    return {q,M,N,share:N?M/N:null,toks,phr,allTitle,anyTerm,topScore:scores.length?scores[scores.length-1]:null,medScore,meanScore,
      fields:FIELD_ORDER.filter(f=>fieldCount.has(f)).map(f=>({name:f,count:fieldCount.get(f),share:M?fieldCount.get(f)/M:null})),
      bands:BANDS.map((b,k)=>({label:b[0],count:bandCount[k],share:M?bandCount[k]/M:null})),
      terms,related:related.slice(0,D.topN),relatedTotal:related.length,st};
  });
}

/* Knowledge graph for the top-ranked matches */
const KG_COL={paper:'#1f4e79',author:'#2f6f8f',journal:'#6b46c1',publisher:'#92400e',keyword:'#166534',year:'#4b5563',place:'#0f766e',doi:'#9f1239',url:'#374151',country:'#9d174d'};
function graphStats(g){
  const N=g.nodes.length,E=g.edges.length,adj=new Map(),deg=new Map();
  g.nodes.forEach(n=>{adj.set(n,[]);deg.set(n,0)});
  g.edges.forEach(e=>{if(!adj.has(e.a)||!adj.has(e.b))return;adj.get(e.a).push(e.b);adj.get(e.b).push(e.a);deg.set(e.a,deg.get(e.a)+1);deg.set(e.b,deg.get(e.b)+1)});
  const seen=new Set();let comps=0,largest=0;
  g.nodes.forEach(n=>{
    if(seen.has(n))return;comps++;let size=0;const stack=[n];seen.add(n);
    while(stack.length){const x=stack.pop();size++;adj.get(x).forEach(y=>{if(!seen.has(y)){seen.add(y);stack.push(y)}})}
    largest=Math.max(largest,size);
  });
  const types=new Map(),rels=new Map();
  g.nodes.forEach(n=>plainAdd(types,n.type));
  g.edges.forEach(e=>plainAdd(rels,e.relation));
  const hubs=[...g.nodes].sort((a,b)=>deg.get(b)-deg.get(a)||String(a.label).localeCompare(String(b.label)));
  return {N,E,comps,largest,density:N>1?2*E/(N*(N-1)):null,avgDeg:N?2*E/N:null,maxDeg:hubs.length?deg.get(hubs[0]):0,
    isolatedPapers:g.nodes.filter(n=>n.type==='paper'&&deg.get(n)===0).length,
    types:[...types].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count),
    rels:[...rels].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count),
    hubs,deg};
}
function graphData(){
  return memo('graph',D.model+'|'+D.limit+'|'+filterKey(),()=>{
    const ids=matchIds(),L=Math.min(D.limit,ids.length);
    const hits=ids.slice(0,L).map(i=>({i}));
    const sel=KG_MODELS[D.model]||KG_MODELS.bibliographic;
    const g=kgBuildByModel(hits,sel.id,{limit:L});
    const s=graphStats(g);
    const cmp=Object.values(KG_MODELS).map(m=>{const x=graphStats(kgBuildByModel(hits,m.id,{limit:L}));return {id:m.id,label:m.label,N:x.N,E:x.E,comps:x.comps,density:x.density,avgDeg:x.avgDeg}});
    return {model:sel,L,M:ids.length,s,cmp,edges:g.edges};
  });
}

/* ---------- presentation helpers ---------- */
const attr=s=>esc(s);
function kpiHTML(items){return `<dl class="d3-kpis">${items.map(([v,l,title])=>`<div class="d3-kpi"><dt>${esc(l)}</dt><dd title="${attr(title||'')}">${v}</dd></div>`).join('')}</dl>`}
function barCard({title,desc,rows,field,base,missing,label='Value',interactive=true,unitNote,valueFn}){
  const mx=Math.max(1,...rows.map(r=>r.count));
  const active=r=>D.filters.some(f=>f.field===field&&(field==='keyword'||field==='author'?f.key===r.key:f.value===r.name));
  const items=rows.map((r,k)=>{
    const val=valueFn?valueFn(r):`${NUM(r.count)} · ${PCT(r.share)}`;
    const lab=`${title}: ${r.name}, ${NUM(r.count)} records, ${PCT(r.share)} of base`;
    const inner=`<span class="d3-lbl">${esc(r.name||'(blank)')}</span><span class="d3-track" aria-hidden="true"><span class="d3-fill" style="width:${(100*r.count/mx).toFixed(2)}%"></span></span><span class="d3-val">${esc(val)}</span>`;
    return interactive&&field?`<li><button type="button" class="d3-bar" aria-pressed="${active(r)}" aria-label="${attr(lab)}. ${active(r)?'Filter active; press to remove.':'Press to filter the dashboard.'}" data-d3f="${field}" data-d3v="${attr(r.name)}" data-d3k="${attr(r.key||'')}">${inner}</button></li>`
                    :`<li><div class="d3-bar d3-static" role="text" aria-label="${attr(lab)}">${inner}</div></li>`;
  }).join('');
  const tbl=`<table><caption>${esc(title)} (data table)</caption><thead><tr><th scope="col">${esc(label)}</th><th scope="col">Records</th><th scope="col">Share of base</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.name||'(blank)')}</td><td>${NUM(r.count)}</td><td>${PCT(r.share)}</td></tr>`).join('')}</tbody></table>`;
  return `<section class="d3-card" aria-labelledby="h-${esc(title.replace(/\W+/g,'-'))}">
    <h3 id="h-${esc(title.replace(/\W+/g,'-'))}">${esc(title)}</h3>
    <p class="d3-desc">${esc(desc)}</p>
    ${rows.length?`<ul class="d3-bars">${items}</ul>`:'<p class="d3-muted">No values in this base.</p>'}
    <p class="d3-foot">${NUM(base-missing)} of ${NUM(base)} records have a value${missing?`; ${NUM(missing)} missing and excluded`:''}.${unitNote?' '+esc(unitNote):''}</p>
    <details class="d3-tbl"><summary>Show as data table</summary>${tbl}</details>
  </section>`;
}
function tableCard({title,desc,head,rows,foot}){
  return `<section class="d3-card wide" aria-labelledby="h-${esc(title.replace(/\W+/g,'-'))}"><h3 id="h-${esc(title.replace(/\W+/g,'-'))}">${esc(title)}</h3><p class="d3-desc">${esc(desc)}</p>
    <div class="d3-scroll"><table><thead><tr>${head.map(h=>`<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>${foot?`<p class="d3-foot">${foot}</p>`:''}</section>`;
}
function provHTML(base,extra){
  const scopeTxt=D.scope==='results'?(state.query.trim()?`current search results for “${esc(state.query.trim())}”`:'current results (no query, so all records passing the search facets)'):'whole collection';
  const filt=[D.from?`year ≥ ${D.from}`:'',D.to?`year ≤ ${D.to}`:'',...D.filters.map(f=>`${FIELD_LABEL[f.field]}: ${f.value}`)].filter(Boolean);
  return `<div class="d3-prov" role="note">
    <p><b>Source:</b> embedded bibliographic dataset, ${NUM(R.length)} records. <b>Base:</b> ${NUM(base)} records from ${scopeTxt}${filt.length?`; filters: ${filt.map(esc).join('; ')}`:''}.
    ${extra?esc(extra)+' ':''}<b>Computed:</b> ${D.computed?D.computed.toLocaleString():'—'}.</p>
    <details><summary>Method and definitions</summary><ol>${METHOD.map(m=>`<li>${esc(m)}</li>`).join('')}</ol></details>
  </div>`;
}
const FIELD_LABEL={journal:'Journal',publisher:'Publisher',country:'Country',year:'Year',keyword:'Keyword',author:'Author'};
function filterBarHTML(){
  const chips=D.filters.map((f,k)=>`<span class="d3-chip">${FIELD_LABEL[f.field]}: ${esc(f.value)} <button type="button" data-d3rm="${k}" aria-label="Remove filter ${attr(FIELD_LABEL[f.field]+': '+f.value)}">×</button></span>`).join('');
  return `<div class="d3-filters" role="region" aria-label="Dashboard controls">
    <div class="d3-row">
      <label>Base <select data-d3scope><option value="all" ${D.scope==='all'?'selected':''}>Whole collection</option><option value="results" ${D.scope==='results'?'selected':''}>Current search results</option></select></label>
      <label>Year from <input type="number" inputmode="numeric" data-d3from value="${attr(D.from)}" style="width:84px"></label>
      <label>to <input type="number" inputmode="numeric" data-d3to value="${attr(D.to)}" style="width:84px"></label>
      <label>Show top <select data-d3topn>${[10,20,50].map(v=>`<option value="${v}" ${D.topN===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <button type="button" class="d3-btn" data-d3reset>Reset controls</button>
    </div>
    <div class="d3-chips" aria-label="Active dashboard filters">${chips||'<span class="d3-muted">No filters. Press any bar or year to filter every panel on this tab.</span>'}
      ${D.filters.length?`<button type="button" class="d3-btn" data-d3clear>Clear all filters</button><button type="button" class="d3-btn primary" data-d3apply title="Copies these filters into the search facets and runs the search">Apply to search</button>`:''}
    </div>
  </div>`;
}

/* ---------- tab bodies ---------- */
/* ---------- Publishing share (pie chart) ---------- */
const PIE_COL=['#1f4e79','#b45309','#166534','#6b46c1','#9f1239','#0f766e','#7c2d12','#1d4ed8','#86198f','#4d7c0f'];
const PIE_OTHER='#6b7280';
function pubShareData(ids){
  return memo('pubshare',D.scope+'|'+filterKey()+'|'+D.topN,()=>{
    const m=new Map();let known=0;
    for(const i of ids){const p=PUB[R[i][5]]||'';if(p){plainAdd(m,p);known++}}
    const all=[...m].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name));
    const k=Math.min(D.topN,10),slices=all.slice(0,k).map(e=>({...e,share:known?e.count/known:null,other:false}));
    const rest=all.slice(k),rc=rest.reduce((t,e)=>t+e.count,0);
    if(rc)slices.push({name:`Other publishers (${NUM(rest.length)})`,count:rc,share:known?rc/known:null,other:true,rest:rest.map(e=>({name:e.name,count:e.count}))});
    return {known,distinct:all.length,slices,missing:ids.length-known};
  });
}
function pubShareCard(ids,n){
  const d=pubShareData(ids),sl=d.slices,cx=110,cy=110,r=100;
  const col=(e,k)=>e.other?PIE_OTHER:PIE_COL[k%PIE_COL.length];
  const active=e=>!e.other&&D.filters.some(f=>f.field==='publisher'&&f.value===e.name);
  let a0=-Math.PI/2,paths='';
  if(sl.length===1){
    const e=sl[0];
    paths=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${col(e,0)}" stroke="${active(e)?'#111827':'#fff'}" stroke-width="${active(e)?3:1.5}" class="d3-slice click" data-d3pie="0"><title>${attr(e.name)}: ${NUM(e.count)} records, ${PCT(e.share)}</title></circle><text class="d3-pie-lbl" x="${cx}" y="${cy+4}" text-anchor="middle">100%</text>`;
  }else{
    sl.forEach((e,k)=>{
      const a1=a0+2*Math.PI*(e.count/d.known),x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),big=(a1-a0)>Math.PI?1:0;
      paths+=`<path d="M${cx} ${cy}L${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${big} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}Z" fill="${col(e,k)}" stroke="${active(e)?'#111827':'#fff'}" stroke-width="${active(e)?3:1.5}" class="d3-slice click" data-d3pie="${k}"><title>${attr(e.name)}: ${NUM(e.count)} records, ${PCT(e.share)}</title></path>`;
      if(e.share>=0.06){const am=(a0+a1)/2;paths+=`<text class="d3-pie-lbl" x="${(cx+r*.64*Math.cos(am)).toFixed(1)}" y="${(cy+r*.64*Math.sin(am)+4).toFixed(1)}" text-anchor="middle">${PCT(e.share,0)}</text>`}
      a0=a1;
    });
  }
  const leg=sl.map((e,k)=>{
    const inner=`<span class="sw" style="background:${col(e,k)}" aria-hidden="true"></span><span class="nm" title="${attr(e.name)}">${esc(e.name)}</span><span class="vl">${NUM(e.count)} &middot; ${PCT(e.share)}</span>`;
    return e.other?`<li><button type="button" class="d3-pieb" aria-expanded="${D.otherOpen?'true':'false'}" aria-controls="d3OtherList" title="Show every smaller publisher" data-d3other="1" data-d3pieb="${k}">${inner}</button></li>`
      :`<li><button type="button" class="d3-pieb" aria-pressed="${active(e)}" aria-label="${attr(`Publisher ${e.name}, ${NUM(e.count)} records, ${PCT(e.share)} of records with a publisher. ${active(e)?'Filter active; press to remove.':'Press to filter the dashboard.'}`)}" data-d3f="publisher" data-d3v="${attr(e.name)}" data-d3k="" data-d3pieb="${k}">${inner}</button></li>`;
  }).join('');
  const tbl=`<table><caption>Publishing share (data table)</caption><thead><tr><th scope="col">Publisher</th><th scope="col">Records</th><th scope="col">Share of records with a publisher</th></tr></thead><tbody>${sl.map(e=>`<tr><td>${esc(e.name)}</td><td>${NUM(e.count)}</td><td>${PCT(e.share)}</td></tr>`).join('')}</tbody></table>`;
  const rest=d.distinct>Math.min(D.topN,10)?` The ${NUM(d.distinct-Math.min(D.topN,10))} smaller publishers are grouped as Other.`:'';
  const oth=sl.find(e=>e.other);
  const otherPanel=oth&&D.otherOpen?`<div id="d3OtherList" class="d3-other" role="region" aria-label="All smaller publishers"><div class="d3-other-h"><b>All other publishers (${NUM(oth.rest.length)})</b><button type="button" class="d3-btn" data-d3other="1">Close</button></div><p class="d3-muted">Select a publisher to filter every panel on this tab. Select it again to remove the filter.</p><ul>${oth.rest.map(e=>`<li><button type="button" class="d3-pieb" aria-pressed="${D.filters.some(f=>f.field==='publisher'&&f.value===e.name)}" data-d3f="publisher" data-d3v="${attr(e.name)}" data-d3k=""><span class="sw" style="background:${PIE_OTHER}"></span><span class="nm">${esc(e.name)}</span><span class="vl">${NUM(e.count)}</span></button></li>`).join('')}</ul></div>`:'';
  return `<section class="d3-card" aria-labelledby="h-Publishing-share">
    <h3 id="h-Publishing-share">Publishing share</h3>
    <p class="d3-desc">Each slice is one publisher's share of the records that name a publisher. Select a slice or a legend row to filter every panel.</p>
    ${d.known?`<div class="d3-pie"><svg viewBox="0 0 220 220" role="img" aria-label="Pie chart of publishing share. ${attr(sl.slice(0,3).map(e=>e.name+' '+PCT(e.share)).join(', '))}${sl.length>3?' and others':''}.">${paths}</svg><ul class="d3-pie-leg">${leg}</ul></div>`:'<p class="d3-muted">No publisher values in this base.</p>'}
    <p class="d3-foot">${NUM(d.known)} of ${NUM(n)} records have a publisher${d.missing?`; ${NUM(d.missing)} missing and excluded`:''}.${rest}</p>
    ${otherPanel}
    <details class="d3-tbl"><summary>Show as data table</summary>${tbl}</details>
  </section>`;
}

function htmlOverview(){
  const ids=baseIds(),st=overviewStats(),n=st.n;
  if(!n)return `${provHTML(0)}<p class="d3-muted" role="status">No records in this base. Remove a filter or widen the year range.</p>`;
  const kp=kpiHTML([
    [NUM(n),'Records in base','Records after scope, year range and filters'],
    [st.ylo!=null?`${st.ylo}–${st.yhi}`:'n/a','Year span','Earliest and latest known year (records with no year are excluded)'],
    [NUM(st.distinct.journals),'Journals','Distinct non-blank journal names'],
    [NUM(st.distinct.publishers),'Publishers','Distinct non-blank publisher names'],
    [NUM(st.distinct.countries),'Countries','Distinct non-blank countries'],
    [NUM(st.distinct.authors),'Distinct authors','Authors grouped case- and accent-insensitively'],
    [NUM(st.distinct.keywords),'Distinct keywords','Keywords grouped case- and accent-insensitively'],
    [NUM(st.sum),'Total citations','Sum of citation counts in the base'],
    [DEC(st.mean,1),'Mean citations','Total citations ÷ records'],
    [st.median==null?'n/a':NUM(st.median),'Median citations','Middle value of citation counts'],
    [NUM(st.zero),'Uncited records','Records with zero citations']
  ]);
  const cov=[['DOI',st.miss.doi],['Abstract',st.miss.abstract],['Article link',st.miss.url],['Keywords',st.miss.keywords],['Authors',st.miss.authors],['Journal',st.miss.journal],['Publisher',st.miss.publisher],['Country',st.miss.country],['Year',st.miss.year]];
  const covRows=cov.map(([f,m])=>`<tr><td>${f}</td><td>${NUM(n-m)}</td><td>${NUM(m)}</td><td>${PCT((n-m)/n)}</td></tr>`).join('');
  D.snap.overview={scope:D.scope,filters:D.filters.map(f=>({field:f.field,value:f.value})),yearFrom:D.from||null,yearTo:D.to||null,base:n,missing:st.miss,distinct:st.distinct,totalCitations:st.sum,meanCitations:st.mean,medianCitations:st.median,years:st.series,journals:st.journals,keywords:st.keywords,authors:st.authors,countries:st.countries,publishers:st.publishers,publishingShare:pubShareData(ids).slices.map(e=>({publisher:e.name,records:e.count,share:e.share,groupedOther:!!e.other}))};
  const yearRows=st.series.map(y=>({name:String(y.year),count:y.count,share:y.share}));
  const yearCard=barCard({title:'Records per publication year',desc:'Each bar is one publication year. Select a year to filter every panel.',rows:yearRows,field:'year',base:n,missing:st.miss.year,label:'Year',unitNote:'Years run from the earliest to the latest known year, so gap years show zero.'});
  const cit=barCard({title:'Citation distribution',desc:'Records grouped by citation count. Not a filter.',rows:st.buckets.map(b=>({name:b.label,count:b.count,share:b.share})),field:null,base:n,missing:0,label:'Citations',interactive:false});
  return `${provHTML(n)}${kp}
    <div class="d3-grid">
      ${yearCard}
      ${barCard({title:'Top journals',desc:`Journals by record count, top ${D.topN}.`,rows:st.journals,field:'journal',base:n,missing:st.miss.journal,label:'Journal'})}
      ${barCard({title:'Top keywords',desc:`Keywords by record count (grouped case- and accent-insensitively), top ${D.topN}.`,rows:st.keywords,field:'keyword',base:n,missing:st.miss.keywords,label:'Keyword'})}
      ${barCard({title:'Top countries',desc:`Countries by record count, top ${D.topN}.`,rows:st.countries,field:'country',base:n,missing:st.miss.country,label:'Country'})}
      ${barCard({title:'Top publishers',desc:`Publishers by record count, top ${D.topN}.`,rows:st.publishers,field:'publisher',base:n,missing:st.miss.publisher,label:'Publisher'})}
      ${pubShareCard(ids,n)}
      ${barCard({title:'Top authors',desc:`Authors by record count (grouped case- and accent-insensitively), top ${D.topN}.`,rows:st.authors,field:'author',base:n,missing:st.miss.authors,label:'Author'})}
      ${cit}
      ${tableCard({title:'Field completeness',desc:'How many records in the base have each field. Missing values are excluded from every other figure.',head:['Field','Records with value','Missing','Completeness'],rows:covRows})}
      ${tableCard({title:`Most cited records (top 10)`,desc:'Ranked by citation count, then by dataset order. Select a title to open its detail view.',head:['#','Title','Year','Journal','Citations'],rows:st.most.map((m,k)=>`<tr><td>${k+1}</td><td><button type="button" class="d3-link" data-d3open="${m.i}">${esc(m.title)}</button></td><td>${m.year||'n/a'}</td><td>${esc(m.source)}</td><td>${NUM(m.cites)}</td></tr>`).join('')})}
    </div>`;
}

function htmlQuery(){
  if(!state.query.trim())return `${provHTML(0)}<p class="d3-muted" role="status">No active search. Enter a query in the search box, then return here. This tab explores the records that match it.</p>`;
  if(!currentResults.length)return `${provHTML(0)}<p class="d3-muted" role="status">No records match “${esc(state.query.trim())}”.</p>`;
  const q=queryStats(),M=q.M;
  if(!M)return `${provHTML(0)}<p class="d3-muted" role="status">No matches remain after the year range and filters. Widen them to see results.</p>`;
  const kp=kpiHTML([
    [NUM(M),'Matches in base','Ranked search results after year range and filters'],
    [PCT(q.share,2),'Share of collection','Matches ÷ all records'],
    [NUM(q.allTitle),'All terms in title','Matches whose title contains every term and phrase'],
    [NUM(q.anyTerm),'At least one term','Matches whose title, authors, keywords, journal or abstract contains a term'],
    [DEC(q.topScore,1),'Top relevance score','Highest search score among matches'],
    [DEC(q.medScore,1),'Median relevance score','Median search score among matches']
  ]);
  D.snap.query={query:q.q,matches:M,collectionRecords:q.N,shareOfCollection:q.share,terms:q.terms,related:q.related,allTermsInTitle:q.allTitle,atLeastOneTerm:q.anyTerm,fields:q.fields,scoreBands:q.bands};
  const fieldRows=q.fields.map(f=>({name:f.name,count:f.count,share:f.share,key:f.name}));
  const termRows=q.terms.map(t=>`<tr><td>${esc(t.term)}</td><td>${NUM(t.inMatches)}</td><td>${NUM(t.inTitle)}</td><td>${PCT(t.coverage)}</td><td>${PCT(t.collectionShare)}</td><td>${t.enrichment==null?'n/a':t.enrichment.toFixed(2)+'×'}</td></tr>`).join('');
  const relRows=q.related.map(r=>({name:r.name,key:r.key,count:r.count,share:r.share}));
  const relCard=barCard({title:'Related keywords',desc:`Keywords over-represented in the matches (at least ${D.minKw} matches). The value shows the lift: match share ÷ collection share. Select a keyword to filter.`,rows:relRows,field:'keyword',base:M,missing:0,label:'Keyword',valueFn:r=>`${NUM(r.count)} · lift ${DEC(q.related.find(x=>x.key===r.key).lift,2)}`,unitNote:`${NUM(q.relatedTotal)} keywords meet the minimum; the top ${D.topN} are shown.`});
  const fieldCard=barCard({title:'Fields that matched',desc:'Number of matches in which each field contributed to the score. A record can match in more than one field.',rows:fieldRows,field:null,base:M,missing:0,label:'Field',interactive:false});
  const bandCard=barCard({title:'Relevance score bands',desc:'Matches grouped by search score. Not a filter.',rows:q.bands.map(b=>({name:b.label,count:b.count,share:b.share})),field:null,base:M,missing:0,label:'Score',interactive:false});
  const stM=q.st;
  return `${provHTML(M,`Query terms: ${q.toks.map(esc).join(', ')||'none'}${q.phr.length?`; quoted phrases: ${q.phr.length}`:''}.`)}${kp}
    <div class="d3-grid">
      <section class="d3-card wide" aria-labelledby="h-terms"><h3 id="h-terms">Query term coverage</h3>
        <p class="d3-desc">How each term appears in the matches, compared with the whole collection. Enrichment above 1× means the term is more common among matches than in the collection.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Term</th><th scope="col">Matches containing it</th><th scope="col">Titles containing it</th><th scope="col">Coverage of matches</th><th scope="col">Collection share</th><th scope="col">Enrichment</th></tr></thead><tbody>${termRows||'<tr><td colspan="6">No searchable terms (phrase-only query).</td></tr>'}</tbody></table></div>
        <p class="d3-foot">Matching is a substring test, the same rule search scoring uses.</p></section>
      ${fieldCard}
      ${bandCard}
      ${relCard}
      <section class="d3-card" aria-labelledby="h-minkw"><h3 id="h-minkw">Keyword threshold</h3><p class="d3-desc">Keywords appear in the related list only when they occur in at least this many matches.</p>
        <label>Minimum matches <select data-d3minkw>${[2,3,5,10].map(v=>`<option value="${v}" ${D.minKw===v?'selected':''}>${v}</option>`).join('')}</select></label></section>
      ${barCard({title:'Matches per year',desc:'Each bar is a publication year among the matches. Select a year to filter.',rows:stM.series.map(y=>({name:String(y.year),count:y.count,share:y.share})),field:'year',base:M,missing:stM.miss.year,label:'Year'})}
      ${barCard({title:'Top journals in matches',desc:`Journals among the matches, top ${D.topN}.`,rows:stM.journals,field:'journal',base:M,missing:stM.miss.journal,label:'Journal'})}
    </div>`;
}

function htmlGraph(){
  if(!state.query.trim())return `${provHTML(0)}<p class="d3-muted" role="status">Run a search to build a knowledge graph from its matches.</p>`;
  if(!currentResults.length)return `${provHTML(0)}<p class="d3-muted" role="status">No matches, so there is no graph to build.</p>`;
  const gd=graphData();
  if(!gd.L)return `${provHTML(gd.M)}<p class="d3-muted" role="status">No matches remain after filters.</p>`;
  const s=gd.s,hubs=s.hubs.slice(0,30);
  D.hubs=hubs;
  const cx=260,cy=205,Rr=160,pos=new Map();
  hubs.forEach((n,i)=>{const a=-Math.PI/2+2*Math.PI*i/hubs.length;pos.set(n,{x:cx+Rr*Math.cos(a),y:cy+Rr*Math.sin(a)})});
  const svgEdges=(gd.edges).filter(e=>pos.has(e.a)&&pos.has(e.b)).map(e=>{const A=pos.get(e.a),B=pos.get(e.b);return `<line x1="${A.x.toFixed(1)}" y1="${A.y.toFixed(1)}" x2="${B.x.toFixed(1)}" y2="${B.y.toFixed(1)}" stroke="#aab7c6" stroke-width="1"/>`}).join('');
  const svgNodes=hubs.map((n,i)=>{
    const p=pos.get(n),d=s.deg.get(n),r=4+Math.min(9,Math.sqrt(d)*1.6),col=KG_COL[n.type]||'#4b5563',right=p.x>=cx;
    const lab=i<14?`<text x="${(p.x+(right?r+4:-r-4)).toFixed(1)}" y="${(p.y+3).toFixed(1)}" font-size="10" text-anchor="${right?'start':'end'}" fill="#111827">${esc(String(n.label).slice(0,28))}</text>`:'';
    return `<g role="button" tabindex="0" data-d3hub="${i}" aria-label="${attr(`${n.label}, ${n.type}, ${d} links. Press to explore.`)}"><circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}"/>${lab}</g>`;
  }).join('');
  const legend=s.types.map(t=>`<li><span class="d3-sw" style="background:${KG_COL[t.name]||'#4b5563'}" aria-hidden="true"></span>${esc(t.name)}: ${NUM(t.count)} nodes</li>`).join('');
  const hubRows=s.hubs.slice(0,15).map((n,i)=>`<tr><td><button type="button" class="d3-link" data-d3hub="${i}">${esc(n.label)}</button></td><td>${esc(n.type)}</td><td>${NUM(s.deg.get(n))}</td></tr>`).join('');
  const cmpRows=gd.cmp.map(c=>`<tr ${c.id===gd.model.id?'class="d3-sel"':''}><td>${esc(c.label)}${c.id===gd.model.id?' <span class="d3-muted">(shown)</span>':''}</td><td>${NUM(c.N)}</td><td>${NUM(c.E)}</td><td>${NUM(c.comps)}</td><td>${DEC(c.density,3)}</td><td>${DEC(c.avgDeg,1)}</td></tr>`).join('');
  D.snap.graph={model:gd.model.id,recordsUsed:gd.L,matches:gd.M,nodes:s.N,edges:s.E,components:s.comps,largestComponent:s.largest,density:s.density,avgDegree:s.avgDeg,maxDegree:s.maxDeg,isolatedPapers:s.isolatedPapers,nodeTypes:s.types,relations:s.rels,topHubs:s.hubs.slice(0,15).map(n=>({label:n.label,type:n.type,links:s.deg.get(n)})),models:gd.cmp};
  return `${provHTML(gd.M,`Graph built from the top ${NUM(gd.L)} ranked matches of ${NUM(gd.M)}.`)}
    <div class="d3-row">
      <label>Model <select data-d3model>${Object.values(KG_MODELS).map(m=>`<option value="${m.id}" ${m.id===gd.model.id?'selected':''}>${esc(m.label)}</option>`).join('')}</select></label>
      <label>Records <select data-d3limit>${[20,50,100].map(v=>`<option value="${v}" ${D.limit===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <button type="button" class="d3-btn primary" data-d3kg>Open full knowledge graph</button>
    </div>
    ${kpiHTML([
      [NUM(s.N),'Nodes','Distinct entities and records in the graph'],
      [NUM(s.E),'Edges','Relationships from the model schema'],
      [NUM(s.comps),'Connected components','Groups that are linked internally but not to each other'],
      [NUM(s.largest),'Largest component','Nodes in the biggest connected group'],
      [DEC(s.density,3),'Density','2E ÷ (N(N−1)); 1 means every pair is linked'],
      [DEC(s.avgDeg,1),'Average links per node','2E ÷ N'],
      [NUM(s.maxDeg),'Largest hub (links)','Highest number of links on any node'],
      [NUM(s.isolatedPapers),'Records with no links','Matched records with no entity links in this model']
    ])}
    <div class="d3-grid">
      <section class="d3-card" aria-labelledby="h-map"><h3 id="h-map">Hub map</h3>
        <p class="d3-desc">The 30 most-linked nodes. Select a node to explore it. Keyboard: Tab to a node, then press Enter.</p>
        <svg viewBox="0 0 520 420" class="d3-svg" role="img" aria-labelledby="map-t map-d"><title id="map-t">Knowledge graph hub map</title><desc id="map-d">${hubs.length} most-linked nodes, with links between them. Full list in the table beside it.</desc>${svgEdges}${svgNodes}</svg>
        <ul class="d3-legend">${legend}</ul></section>
      <section class="d3-card" aria-labelledby="h-hubs"><h3 id="h-hubs">Top hubs</h3><p class="d3-desc">Most-linked nodes in the graph, by number of links.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Entity</th><th scope="col">Type</th><th scope="col">Links</th></tr></thead><tbody>${hubRows}</tbody></table></div></section>
      <section class="d3-card" aria-labelledby="h-rel"><h3 id="h-rel">Relations in the graph</h3><p class="d3-desc">Edges counted by relation type.</p>
        <table><thead><tr><th scope="col">Relation</th><th scope="col">Edges</th></tr></thead><tbody>${s.rels.map(r=>`<tr><td>${esc(r.name)}</td><td>${NUM(r.count)}</td></tr>`).join('')}</tbody></table></section>
      <section class="d3-card wide" aria-labelledby="h-cmp"><h3 id="h-cmp">Compare the six models (same ${NUM(gd.L)} records)</h3>
        <p class="d3-desc">The same records built under each model. Differences show how the schema changes the structure.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Model</th><th scope="col">Nodes</th><th scope="col">Edges</th><th scope="col">Components</th><th scope="col">Density</th><th scope="col">Avg links</th></tr></thead><tbody>${cmpRows}</tbody></table></div></section>
    </div>`;
}

/* ---------- Evaluation Lab extension ---------- */
const EV_OLD=[['judge','Relevance judgments'],['diag','Result diagnostics'],['lab','Query lab'],['kg','KG model audit'],['sess','Session log'],['sus','Usability (SUS)']];
/* ---- Precision, Recall and F1 (pool-based: relevant = judged grade 1 or 2; unjudged results count as not relevant) ---- */
let PRF_K=10,PRF_ROWS=[];
function prfAt(ranking,J,K){
  const total=Object.values(J).filter(v=>+v>0).length;
  const top=ranking.slice(0,K);
  const tp=top.filter(x=>(+J[x.i]||0)>0).length;
  const judged=top.filter(x=>J[x.i]!==undefined).length;
  const P=top.length?tp/top.length:null,Rc=total?tp/total:null;
  const F1=(P!=null&&Rc!=null&&P+Rc>0)?2*P*Rc/(P+Rc):null;
  return {K,retrieved:top.length,tp,relevant:total,P,R:Rc,F1,judgedShare:top.length?judged/top.length:null};
}
function prfBody(){
  const all=judgments(),q=state.query.trim(),qs=Object.keys(all).filter(x=>Object.keys(all[x]).length);
  if(!qs.length)return `<p class="x2-note">No judged queries yet. Grade results in “Relevance judgments” first, then return here.</p>`;
  const Ks=[...new Set([5,10,20,depth()])].sort((a,b)=>a-b);
  if(!Ks.includes(PRF_K))PRF_K=10;
  const rows=[];
  qs.forEach(qq=>{const rk=rankFor(qq);rows.push(...Ks.map(K=>({q:qq,...prfAt(rk,all[qq],K)})))});
  PRF_ROWS=rows;
  const at=rows.filter(r=>r.K===PRF_K);
  const mean=(arr,k)=>{const v=arr.map(r=>r[k]).filter(x=>x!=null);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
  const P=mean(at,'P'),Rc=mean(at,'R'),F=mean(at,'F1');
  const cur=q&&all[q]?prfAt(rankFor(q),all[q],PRF_K):null;
  const sweep=Ks.map(K=>{const a=rows.filter(r=>r.K===K);return {K,P:mean(a,'P'),R:mean(a,'R'),F1:mean(a,'F1')}});
  const f=x=>x==null?'–':x.toFixed(3),pc=x=>x==null?'–':(100*x).toFixed(1)+'%';
  return `<div class="x2-note">Precision = relevant results in the top K ÷ K. Recall = relevant results in the top K ÷ all relevant records judged for the query. F1 = 2 · P · R ÷ (P + R). Unjudged results count as not relevant, so grade the top K before reading precision.</div>
  <div class="x2-bar"><label>K <select id="x2PrfK">${Ks.map(K=>`<option value="${K}" ${K===PRF_K?'selected':''}>${K}</option>`).join('')}</select></label><button class="ghost" id="x2PrfCsv" type="button">⇩ Export (CSV)</button></div>
  <div class="x2-kpis">${[[f(P),'Mean precision@'+PRF_K],[f(Rc),'Mean recall@'+PRF_K],[f(F),'Mean F1@'+PRF_K],[at.length,'Queries']].map(([v,l])=>`<div class="x2-kpi"><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  ${cur?`<div class="x2-note"><b>Current query “${esc(q)}” at K = ${PRF_K}:</b> precision ${f(cur.P)} · recall ${f(cur.R)} · F1 ${f(cur.F1)} (${cur.tp} relevant in top ${cur.retrieved} of ${cur.relevant} relevant judged)</div>`:''}
  <table class="x2-tbl"><tr><th>Query</th><th>Retrieved (K)</th><th>Relevant retrieved</th><th>Relevant judged</th><th>Precision</th><th>Recall</th><th>F1</th><th>Top K judged</th></tr>
  ${at.map(r=>`<tr><td>${esc(r.q)}</td><td>${r.retrieved}</td><td>${r.tp}</td><td>${r.relevant}</td><td>${f(r.P)}</td><td>${f(r.R)}</td><td>${f(r.F1)}</td><td>${pc(r.judgedShare)}</td></tr>`).join('')}
  <tr><td><b>Macro average</b></td><td></td><td></td><td></td><td><b>${f(P)}</b></td><td><b>${f(Rc)}</b></td><td><b>${f(F)}</b></td><td></td></tr></table>
  <h4 style="margin:14px 0 6px;font-size:12px;color:var(--brand);text-transform:uppercase;letter-spacing:.05em">Macro averages by cutoff K</h4>
  <table class="x2-tbl"><tr><th>K</th><th>Precision</th><th>Recall</th><th>F1</th></tr>${sweep.map(s=>`<tr><td>${s.K}</td><td>${f(s.P)}</td><td>${f(s.R)}</td><td>${f(s.F1)}</td></tr>`).join('')}</table>`;
}
const EV_NEW=[['batch','Batch metrics'],['curve','PR curve & AUC'],['prf','Precision, Recall & F1'],['auto','Heuristic grading']];
const judgments=()=>{try{return JSON.parse(localStorage.getItem('are_judg')||'{}')}catch{return{}}};
const autoGrades=()=>{try{return JSON.parse(localStorage.getItem('are_auto')||'{}')}catch{return{}}};
const saveJudgments=j=>localStorage.setItem('are_judg',JSON.stringify(j));
const depth=()=>Number(localStorage.getItem('are_depth'))||20;
const rankCache=new Map();
/* Ranking identical to the app's default relevance order (score, then citations), no facet filters. */
function rankFor(q){
  if(rankCache.has(q))return rankCache.get(q);
  const o=[];
  for(let i=0;i<R.length;i++){const r=relevance(i,q),s=typeof r==='number'?r:r.score;if(s>0)o.push({i,s})}
  o.sort((a,b)=>b.s-a.s||R[b.i][0]-R[a.i][0]);
  rankCache.set(q,o);return o;
}
function queryMetrics(ranking,J){
  const TOT=Object.values(J).filter(v=>+v>0).length;
  const gains=ranking.map(x=>+J[x.i]||0),top10=gains.slice(0,10),top20=gains.slice(0,20);
  const p10=top10.filter(x=>x>0).length/10;
  const r10=TOT?top10.filter(x=>x>0).length/TOT:null;
  const dcg=a=>a.reduce((s,r,i)=>s+r/Math.log2(i+2),0);
  const ideal=Object.values(J).map(Number).filter(x=>x>0).sort((a,b)=>b-a);
  const idcg=dcg(ideal.slice(0,10));
  const ndcg=idcg?dcg(top10)/idcg:null;
  let seen=0,ap=0;top20.forEach((x,k)=>{if(x>0){seen++;ap+=seen/(k+1)}});
  return {judged:Object.keys(J).length,TOT,p10,r10,ndcg,ap:TOT?ap/TOT:null};
}
function batchBody(){
  const all=judgments(),qs=Object.keys(all).filter(q=>Object.keys(all[q]).length);
  if(!qs.length)return `<p class="x2-note">No judged queries yet. Run searches and grade results in “Relevance judgments”. Every judged query appears here.</p>`;
  const rows=qs.map(q=>({q,...queryMetrics(rankFor(q),all[q])}));
  const mean=k=>{const v=rows.map(r=>r[k]).filter(x=>x!=null);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
  const m={p10:mean('p10'),r10:mean('r10'),ndcg:mean('ndcg'),ap:mean('ap')};
  batchRows=rows;
  return `<div class="x2-kpis">${kpi(rows.length,'Judged queries')}${kpi(pc(m.p10),'Mean P@10')}${kpi(pc(m.r10),'Mean R@10')}${kpi(m.ndcg==null?'–':m.ndcg.toFixed(2),'Mean nDCG@10')}${kpi(m.ap==null?'–':m.ap.toFixed(2),'MAP')}</div>
    <p class="x2-note">Macro averages over judged queries. Ranking uses the default relevance order without facet filters. Unjudged results count as not relevant. Judge pool depth: top ${depth()}.</p>
    <table class="x2-tbl"><tr><th>Query</th><th>Judged</th><th>Relevant</th><th>P@10</th><th>R@10</th><th>nDCG@10</th><th>AP</th></tr>
    ${rows.map(r=>`<tr><td>${esc(r.q)}</td><td>${r.judged}</td><td>${r.TOT}</td><td>${pc(r.p10,0)}</td><td>${pc(r.r10,0)}</td><td>${r.ndcg==null?'–':r.ndcg.toFixed(2)}</td><td>${r.ap==null?'–':r.ap.toFixed(2)}</td></tr>`).join('')}</table>
    <div class="x2-bar" style="margin-top:10px"><button class="ghost" id="x2BatchCsv" type="button">⇩ Export batch metrics (CSV)</button></div>`;
}
let batchRows=[];

function curveBody(){
  const q=state.query.trim();
  if(!q||!currentResults.length)return `<p class="x2-note">Run a search and judge some results first.</p>`;
  const J=judgments()[q]||{},TOT=Object.values(J).filter(v=>+v>0).length;
  if(!TOT)return `<p class="x2-note">Mark at least one result as relevant (grade 1 or 2) in “Relevance judgments” to draw the precision–recall curve.</p>`;
  const top=currentResults.slice(0,50);
  let relSeen=0;
  const pts=top.map((h,k)=>{if((+J[h.i]||0)>0)relSeen++;return {r:relSeen/TOT,p:relSeen/(k+1)}});
  let prev=0,ap=0;pts.forEach(pt=>{if(pt.r>prev){ap+=(pt.r-prev)*pt.p;prev=pt.r}});
  const score=i=>{const r=relevance(i,q);return typeof r==='number'?r:r.score};
  const pos=[],neg=[];
  Object.entries(J).forEach(([i,v])=>(+v>0?pos:neg).push(score(+i)));
  let wins=0;pos.forEach(p=>neg.forEach(n=>{wins+=p>n?1:p===n?0.5:0}));
  const auc=pos.length&&neg.length?wins/(pos.length*neg.length):null;
  const W=560,H=340,m=44,X=r=>m+r*(W-2*m),Y=p=>H-m-p*(H-2*m);
  const grid=[0,.25,.5,.75,1].map(t=>`<line x1="${X(t)}" y1="${m}" x2="${X(t)}" y2="${H-m}" stroke="#eef1f5"/><line x1="${m}" y1="${Y(t)}" x2="${W-m}" y2="${Y(t)}" stroke="#eef1f5"/><text x="${X(t)}" y="${H-m+16}" font-size="10" text-anchor="middle" fill="#687386">${t}</text><text x="${m-8}" y="${Y(t)+3}" font-size="10" text-anchor="end" fill="#687386">${t}</text>`).join('');
  const line=[[0,1],...pts.map(pt=>[pt.r,pt.p])].map(([r,p])=>`${X(r).toFixed(1)},${Y(p).toFixed(1)}`).join(' ');
  const dots=pts.map(pt=>`<circle cx="${X(pt.r).toFixed(1)}" cy="${Y(pt.p).toFixed(1)}" r="2.6" fill="#d97706"/>`).join('');
  const p10=pts[9]?pts[9].p:null;
  return `<div class="x2-kpis">${kpi(ap.toFixed(3),'Average precision (top 50)')}${kpi(auc==null?'–':auc.toFixed(3),'Score ROC-AUC')}${kpi(pc(p10),'Precision@10')}${kpi(fmt(TOT),'Relevant judged')}${kpi(fmt(pts.filter((_,k)=>top[k]&&(+J[top[k].i]||0)>0).length),'Relevant in top 50')}</div>
    <svg viewBox="0 0 ${W} ${H}" class="x2-svg" role="img" aria-label="Precision recall curve">${grid}<line x1="${m}" y1="${H-m}" x2="${W-m}" y2="${H-m}" stroke="#9aa6b8"/><line x1="${m}" y1="${m}" x2="${m}" y2="${H-m}" stroke="#9aa6b8"/>
      <polyline points="${line}" fill="none" stroke="#184e77" stroke-width="2.5"/>${dots}
      <text x="${W/2}" y="${H-8}" font-size="11" text-anchor="middle" fill="#334">Recall</text>
      <text x="14" y="${H/2}" font-size="11" text-anchor="middle" fill="#334" transform="rotate(-90 14 ${H/2})">Precision</text></svg>
    <p class="x2-note">Each dot is one rank of the current results (top 50). Precision = relevant ÷ rank. Recall = relevant so far ÷ all relevant judged for this query. ROC-AUC is the chance that a relevant record scores above a non-relevant one, using the relevance score (0.5 = random).</p>`;
}

function autoBody(){
  const q=state.query.trim();
  if(!q||!currentResults.length)return `<p class="x2-note">Run a search first.</p>`;
  const top=currentResults.slice(0,depth());
  const qt=[...new Set(tokens(q.replace(/"[^"]*"/g,' ')))];
  const ph=[...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean);
  const grade=i=>{
    const x=INDEX[i];
    const inTitle=qt.filter(t=>x.t.includes(t)).length;
    const inAny=qt.filter(t=>(x.t+' '+x.k+' '+x.b).includes(t)).length;
    if((ph.length&&ph.every(p=>x.t.includes(p)))||(qt.length&&inTitle===qt.length))return {g:2,why:'all terms in title'};
    if(qt.length&&inAny>=Math.ceil(qt.length/2))return {g:1,why:'half or more terms in title, keywords or abstract'};
    return {g:0,why:'few or no terms'};
  };
  const auto=autoGrades();auto[q]={};
  const human=judgments()[q]||{};
  const rows=top.map((h,k)=>{const a=grade(h.i);auto[q][h.i]=a.g;return {k,i:h.i,a,h:human[h.i]}});
  localStorage.setItem('are_auto',JSON.stringify(auto));
  const both=rows.filter(r=>typeof r.h==='number');
  let agree=null,kappa=null;
  if(both.length){
    const n=both.length,po=both.filter(r=>r.a.g===r.h).length/n;
    const pe=[0,1,2].reduce((s,c)=>s+(both.filter(r=>r.a.g===c).length/n)*(both.filter(r=>r.h===c).length/n),0);
    agree=po;kappa=(po-pe)/((1-pe)||1);
  }
  const unjudged=rows.filter(r=>typeof r.h!=='number').length;
  return `<div class="x2-kpis">${kpi(fmt(rows.length),'Results graded')}${kpi(fmt(both.length),'Also human-judged')}${kpi(pc(agree),'Agreement with human')}${kpi(kappa==null?'–':kappa.toFixed(2),'Cohen’s κ')}</div>
    <p class="x2-note">Automatic grades are a baseline, not ground truth: 2 = all query terms in the title, 1 = at least half in title, keywords or abstract, 0 = otherwise. Compare them with human grades before relying on them.</p>
    <table class="x2-tbl"><tr><th>#</th><th>Result</th><th>Auto</th><th>Reason</th><th>Human</th></tr>
    ${rows.map(r=>`<tr><td>${r.k+1}</td><td>${esc(R[r.i][2])}</td><td><span class="x2-badge">${r.a.g}</span></td><td>${esc(r.a.why)}</td><td>${typeof r.h==='number'?r.h:'–'}</td></tr>`).join('')}</table>
    <div class="x2-bar" style="margin-top:10px"><button class="primary" id="x2Accept" type="button">Accept suggestions for ${fmt(unjudged)} unjudged results</button><button class="ghost" id="x2AutoCsv" type="button">⇩ Export (CSV)</button></div>`;
}

const EV_BODY={batch:batchBody,curve:curveBody,prf:prfBody,auto:autoBody};
function bindEV(t){
  if(t==='prf'){const k=$('#x2PrfK');if(k)k.onchange=e=>{PRF_K=+e.target.value;evalModal('prf')};const c=$('#x2PrfCsv');if(c)c.onclick=()=>download('precision-recall-f1.csv',csvOf([['query','k','retrieved','relevant_retrieved','relevant_judged','precision','recall','f1','judged_share'],...PRF_ROWS.map(r=>[r.q,r.K,r.retrieved,r.tp,r.relevant,r.P,r.R,r.F1,r.judgedShare])]),'text/csv')}
  if(t==='batch'){const b=$('#x2BatchCsv');if(b)b.onclick=()=>download('batch-metrics.csv',csvOf([['query','judged','relevant','p10','r10','ndcg10','ap'],...batchRows.map(r=>[r.q,r.judged,r.TOT,r.p10,r.r10??'',r.ndcg??'',r.ap??''])]),'text/csv')}
  if(t==='auto'){
    const q=state.query.trim();
    const a=$('#x2Accept');
    if(a)a.onclick=()=>{
      const auto=autoGrades()[q]||{},human=judgments();human[q]=human[q]||{};
      Object.entries(auto).forEach(([i,g])=>{if(human[q][i]===undefined)human[q][i]=g});
      saveJudgments(human);toast('Suggestions accepted as judgments');evalModal('auto');
    };
    const c=$('#x2AutoCsv');
    if(c)c.onclick=()=>{const human=judgments()[q]||{},auto=autoGrades()[q]||{};download('heuristic-grades.csv',csvOf([['record_index','title','auto','human'],...Object.keys(auto).map(i=>[i,R[i][2],auto[i],human[i]??''])]),'text/csv')};
  }
}
function evShell(t){
  $('#modalCard').classList.add('x2-wide');
  showModal(`<h2>Evaluation Lab</h2><p class="x2-note">Measure how well this interface finds, ranks and relates records for the current search. Judgments and scores stay in this browser.</p><div class="ev-tabs">${[...EV_OLD,...EV_NEW].map(([k,l])=>`<button class="ev-tab ${k===t?'on':''}" data-t="${k}" type="button">${l}</button>`).join('')}</div><div id="evBody"></div>`);
  $$('.ev-tab').forEach(b=>b.onclick=()=>window.evalModal(b.dataset.t));
  $('#evBody').innerHTML=EV_BODY[t]();
  bindEV(t);
}


/* ---------- wire up: wrap the existing Evaluate and Dashboard entry points ---------- */
const _evalOld=window.evalModal;
window.evalModal=function(t){
  if(EV_BODY[t])return evShell(t);
  _evalOld.call(this,t);
  const tabs=$('.ev-tabs');
  if(tabs&&!tabs.querySelector('[data-t="batch"]'))EV_NEW.forEach(([k,l])=>{
    const b=document.createElement('button');b.className='ev-tab';b.dataset.t=k;b.type='button';b.textContent=l;
    b.onclick=()=>window.evalModal(k);tabs.appendChild(b);
  });
};
const _closeOld=window.closeModal;
window.closeModal=function(){$('#modalCard').classList.remove('x2-wide');return _closeOld.apply(this,arguments)};


/* ---------- export (every figure comes from the same computed snapshot) ---------- */
function exportPayload(){
  const base=baseIds().length;
  return {
    schema:'academic-explorer-dashboard/v3',
    generated:new Date().toISOString(),
    dataset:{records:R.length,description:'embedded bibliographic dataset'},
    scope:{base:D.scope,yearFrom:D.from||null,yearTo:D.to||null,filters:D.filters.map(f=>({field:f.field,value:f.value}))},
    recordsInBase:base,
    query:state.query.trim()||null,
    method:METHOD,
    overview:D.snap.overview||null,
    query_explorer:D.snap.query||null,
    knowledge_graph:D.snap.graph||null
  };
}
function exportCsv(kind){
  const o=D.snap.overview,qq=D.snap.query,g=D.snap.graph;
  const map={
    years:()=>o&&[['year','records','share_of_base'],...o.years.map(y=>[y.year,y.count,y.share])],
    journals:()=>o&&[['journal','records','share_of_base'],...o.journals.map(r=>[r.name,r.count,r.share])],
    keywords:()=>o&&[['keyword','records','share_of_base'],...o.keywords.map(r=>[r.name,r.count,r.share])],
    authors:()=>o&&[['author','records','share_of_base'],...o.authors.map(r=>[r.name,r.count,r.share])],
    countries:()=>o&&[['country','records','share_of_base'],...o.countries.map(r=>[r.name,r.count,r.share])],
    terms:()=>qq&&[['term','matches_containing','titles_containing','coverage','collection_share','enrichment'],...qq.terms.map(t=>[t.term,t.inMatches,t.inTitle,t.coverage,t.collectionShare,t.enrichment])],
    related:()=>qq&&[['keyword','matches','share_of_matches','collection_records','lift'],...qq.related.map(r=>[r.name,r.count,r.share,r.collection,r.lift])],
    hubs:()=>g&&[['entity','type','links'],...g.topHubs.map(h=>[h.label,h.type,h.links])],
    models:()=>g&&[['model','nodes','edges','components','density','avg_links'],...g.models.map(m=>[m.label,m.N,m.E,m.comps,m.density,m.avgDeg])]
  };
  const rows=map[kind]&&map[kind]();
  if(!rows)return toast('Open the matching tab first, so the figures are computed');
  download(`dashboard-${kind}.csv`,csvOf(rows),'text/csv');
}

/* ---------- controller ---------- */
const TAB_IDS={overview:'d3tab-overview',query:'d3tab-query',kg:'d3tab-kg',export:'d3tab-export'};
function setStatus(msg){const s=$('#d3Status');if(s)s.textContent=msg}
function renderDash(){
  const panel=$('#d3Panel');if(!panel)return;
  setStatus('Computing…');
  setTimeout(()=>{
    let html;
    try{
      D.computed=new Date();
      if(D.tab==='overview')html=htmlOverview();
      else if(D.tab==='query')html=htmlQuery();
      else if(D.tab==='kg')html=htmlGraph();
      else html=htmlExport();
    }catch(e){
      console.error(e);
      html=`<p role="alert" class="d3-muted">The dashboard could not compute this view: ${esc(e.message)}</p>`;
    }
    $('#d3Filters').innerHTML=D.tab==='export'?'':filterBarHTML();
    panel.innerHTML=html;
    $$('.d3-tab').forEach(b=>{b.setAttribute('aria-selected',String(b.dataset.d3tab===D.tab));b.tabIndex=b.dataset.d3tab===D.tab?0:-1});
    panel.setAttribute('aria-labelledby',TAB_IDS[D.tab]);
    if(D.tab==='export')setStatus(`Updated ${D.computed.toLocaleTimeString()}.`);
    else if(D.tab==='query')setStatus(`Matches: ${NUM(matchIds().length)}. Updated ${D.computed.toLocaleTimeString()}.`);
    else setStatus(`Records in base: ${NUM(baseIds().length)}. Updated ${D.computed.toLocaleTimeString()}.`);
  },0);
}
function htmlExport(){
  const have=k=>!!D.snap[k];
  const payloadNote=`${provHTML(baseIds().length)}`;
  const csvBtn=(k,label,ok)=>`<button type="button" class="d3-btn" data-d3csv="${k}" ${ok?'':'aria-describedby="exp-note"'}>${label}</button>`;
  return `${payloadNote}
    <section class="d3-card wide" aria-labelledby="h-exp"><h3 id="h-exp">Export</h3>
      <p class="d3-desc">Downloads contain the figures exactly as shown. The JSON file also contains the scope, filters, query and method notes, so a figure can be traced back to its definition. CSV files exist only for sections you have opened in this session.</p>
      <div class="d3-row"><button type="button" class="d3-btn primary" data-d3json>Download full summary (JSON)</button></div>
      <div class="d3-row" role="group" aria-label="CSV downloads">
        ${csvBtn('years','Years (CSV)',have('overview'))}${csvBtn('journals','Journals (CSV)',have('overview'))}${csvBtn('keywords','Keywords (CSV)',have('overview'))}${csvBtn('authors','Authors (CSV)',have('overview'))}${csvBtn('countries','Countries (CSV)',have('overview'))}
        ${csvBtn('terms','Query terms (CSV)',have('query'))}${csvBtn('related','Related keywords (CSV)',have('query'))}
        ${csvBtn('hubs','Graph hubs (CSV)',have('graph'))}${csvBtn('models','Model comparison (CSV)',have('graph'))}
      </div>
      <p id="exp-note" class="d3-foot">Buttons stay available; if a file is missing, open its tab first.</p>
    </section>`;
}
function openDash(){
  if(!R||!R.length){toast('Dataset is still loading…');return}
  $('#modalCard').classList.add('x2-wide');
  showModal(`<div id="d3Root" class="d3-root">
    <h2>Dashboard</h2>
    <div class="d3-tabs" role="tablist" aria-label="Dashboard sections">${DTABS.map(([k,l])=>`<button type="button" role="tab" id="${TAB_IDS[k]}" class="d3-tab" data-d3tab="${k}" aria-selected="${D.tab===k}" aria-controls="d3Panel" tabindex="${D.tab===k?0:-1}">${l}</button>`).join('')}</div>
    <div id="d3Filters"></div>
    <div id="d3Panel" role="tabpanel" aria-labelledby="${TAB_IDS[D.tab]}"></div>
    <div id="d3Status" class="d3-status" role="status" aria-live="polite"></div>
  </div>`);
  const root=$('#d3Root');
  root.addEventListener('click',onDashClick);
  root.addEventListener('change',onDashChange);
  root.addEventListener('keydown',onDashKey);
  renderDash();
}
function setTab(t){D.tab=t;renderDash();const b=document.getElementById(TAB_IDS[t]);if(b)b.focus()}
function toggleFilter(field,value,key){
  const idx=D.filters.findIndex(f=>f.field===field&&(field==='keyword'||field==='author'?f.key===key:f.value===value));
  if(idx>=0)D.filters.splice(idx,1);
  else D.filters.push({field,value:String(value),key:key||norm(value)});
  renderDash();
}
function onDashClick(e){
  const pp=e.target.closest('[data-d3pie]');
  if(pp){const pb=document.querySelector('[data-d3pieb="'+pp.dataset.d3pie+'"]');if(pb)pb.click();return}
  const t=e.target.closest('button,[role="button"]');
  if(!t)return;
  if(t.dataset.d3other!==undefined){D.otherOpen=!D.otherOpen;renderDash();const ol=document.getElementById('d3OtherList');if(ol)ol.scrollIntoView({block:'nearest'});return}
  if(t.dataset.d3tab){setTab(t.dataset.d3tab);return}
  if(t.dataset.d3f){toggleFilter(t.dataset.d3f,t.dataset.d3v,t.dataset.d3k);return}
  if(t.dataset.d3rm!==undefined){D.filters.splice(Number(t.dataset.d3rm),1);renderDash();return}
  if('d3clear' in t.dataset){D.filters=[];renderDash();return}
  if('d3reset' in t.dataset){D.scope='all';D.from='';D.to='';D.topN=10;D.minKw=3;D.filters=[];D.limit=20;renderDash();return}
  if('d3apply' in t.dataset){applyToSearch();return}
  if(t.dataset.d3hub!==undefined){openHub(D.hubs[Number(t.dataset.d3hub)]);return}
  if(t.dataset.d3open!==undefined){closeModal();detail(Number(t.dataset.d3open));return}
  if('d3kg' in t.dataset){closeModal();kgOpen(currentResults.slice(0,D.limit),'results');return}
  if('d3json' in t.dataset){download('dashboard-summary.json',JSON.stringify(exportPayload(),null,2),'application/json');return}
  if(t.dataset.d3csv){exportCsv(t.dataset.d3csv);return}
}
function onDashChange(e){
  const t=e.target;
  if('d3scope' in t.dataset){D.scope=t.value;renderDash();return}
  if('d3from' in t.dataset){D.from=t.value.trim();renderDash();return}
  if('d3to' in t.dataset){D.to=t.value.trim();renderDash();return}
  if('d3topn' in t.dataset){D.topN=Number(t.value);renderDash();return}
  if('d3minkw' in t.dataset){D.minKw=Number(t.value);renderDash();return}
  if('d3model' in t.dataset){D.model=t.value;renderDash();return}
  if('d3limit' in t.dataset){D.limit=Number(t.value);renderDash();return}
}
function onDashKey(e){
  const tab=e.target.closest('.d3-tab');
  if(tab&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){
    const order=DTABS.map(d=>d[0]);
    const k=(order.indexOf(tab.dataset.d3tab)+(e.key==='ArrowRight'?1:order.length-1))%order.length;
    e.preventDefault();setTab(order[k]);return;
  }
  const hub=e.target.closest('[data-d3hub][role="button"]');
  if(hub&&(e.key==='Enter'||e.key===' ')){e.preventDefault();openHub(D.hubs[Number(hub.dataset.d3hub)])}
}
function openHub(n){
  if(!n)return;
  if(n.type==='paper'){closeModal();detail(n.paperIndex);return}
  if(n.type==='country'){closeModal();const idx=CO.findIndex(x=>x===n.label);if(idx>=0){state.country=String(idx);$('#countryFilter').value=state.country}state.page=1;doSearch();return}
  if(['journal','publisher','keyword','author','year','place'].includes(n.type)){kgSearchByNode(n);return}
  toast('Use the search box to look up this '+n.type);
}
/* Copies dashboard filters into the search facets, then runs the search */
function applyToSearch(){
  closeModal();
  const jf=D.filters.find(f=>f.field==='journal');
  const pf=D.filters.find(f=>f.field==='publisher');
  const cf=D.filters.find(f=>f.field==='country');
  const yf=D.filters.filter(f=>f.field==='year');
  const kf=D.filters.find(f=>f.field==='keyword'||f.field==='author');
  if(jf){state.source=String(S.indexOf(jf.value));$('#sourceFilter').value=state.source}
  if(pf){state.publisher=String(PUB.indexOf(pf.value));$('#publisherFilter').value=state.publisher}
  if(cf){state.country=String(CO.indexOf(cf.value));$('#countryFilter').value=state.country}
  if(yf.length){state.yearSet=new Set(yf.map(f=>Number(f.value)));$$('[data-year]').forEach(x=>x.checked=state.yearSet.has(Number(x.dataset.year)))}
  if(D.from)state.yearFrom=Number(D.from);
  if(D.to)state.yearTo=Number(D.to);
  if(kf){state.query=`"${kf.value}"`;$('#q').value=state.query}
  state.page=1;doSearch();
  toast('Dashboard filters applied to the search');
}

/* ---------- wire up (dashboard entry point) ---------- */
window.openDashboard=openDash;
let dbBtn=document.getElementById('dashBtn');
if(!dbBtn){
  dbBtn=document.createElement('button');
  dbBtn.className='ghost';dbBtn.id='dashBtn';dbBtn.type='button';
  dbBtn.innerHTML='▦ <span>Dashboard</span>';
  const anchor=document.getElementById('evalBtn')||document.querySelector('.toolbar .nav-spacer');
  if(anchor&&anchor.parentNode)anchor.parentNode.insertBefore(dbBtn,anchor);
  else document.querySelector('.toolbar')?.appendChild(dbBtn);
}
dbBtn.onclick=openDash;

})();

