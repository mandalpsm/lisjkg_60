
/* ===== Hypotheses v7: alternative hypotheses (H1 variants) and (+) detail toggles ===== */
(()=>{const st=document.createElement('style');st.id='hyp-v7-css';st.textContent='.hyp-card{position:relative;padding-right:46px}.hyp-plus{position:absolute;right:12px;top:12px}.hyp-alt{margin:6px 0 0;padding-left:18px}.hyp-alt li{margin:5px 0;font-size:13px;line-height:1.45}.hyp-more{margin-top:10px;padding:10px 12px;border-left:3px solid #7c3aed;background:#f7f3ff;border-radius:6px;font-size:13px;line-height:1.5}.hyp-more[hidden]{display:none}.hyp-more button.ghost{margin:3px 6px 3px 0;font-size:12px}';if(!document.getElementById('hyp-v7-css'))document.head.appendChild(st)})();
function hypAlts(h){
  const out=[],ps=(h.papers||[]).map(i=>recObj(i)),n=ps.length,A=h.concepts[0]||'the focal concept',B=h.concepts[1]||'the second concept';
  const top=arr=>{const m=new Map();arr.forEach(v=>{if(v!==''&&v!=null)m.set(v,(m.get(v)||0)+1)});return [...m].sort((a,b)=>b[1]-a[1])[0]||null};
  const j=top(ps.map(o=>o.source)),y=top(ps.map(o=>o.year));
  if(n>=2&&j&&j[1]>=Math.ceil(n/2))out.push({label:'H1a',text:`The link between “${A}” and “${B}” reflects publication venue rather than the topics: ${j[1]} of ${n} supporting records appear in “${j[0]}”.`,basis:'Venue concentration among supporting records'});
  if(n>=2&&y&&y[1]>=Math.ceil(n/2))out.push({label:'H1b',text:`The link reflects publication timing rather than a stable association: ${y[1]} of ${n} supporting records were published in ${y[0]}.`,basis:'Year concentration among supporting records'});
  if(h.support<=2)out.push({label:'H1c',text:`The pattern rests on ${h.support} record${h.support===1?'':'s'}, so it may not generalise beyond these papers.`,basis:'Small support count'});
  out.push({label:'H1d',text:`The relationship between “${A}” and “${B}” depends on context (population, setting or method) and is not a general association.`,basis:'Context dependence; test by stratifying the sample'});
  return out;
}
function hypCardHtml(h,i){
  const alts=hypAlts(h),ps=(h.papers||[]).slice(0,3);
  const vars=h.concepts.length>1?`predictor / concept A = “${esc(h.concepts[0])}”; concept B = “${esc(h.concepts[1])}”`:`focal concept = “${esc(h.concepts[0])}”`;
  return `<div class="hyp-card"><button class="gap-plus hyp-plus" type="button" aria-expanded="false" title="Show alternative hypotheses, variables and falsification criteria" onclick="hypToggle(this)">+</button>
    <div class="confidence ${h.confidence}">${esc(h.type)} · ${h.confidence} corpus signal</div>
    <h3>H${i+1}: ${esc(h.statement)}</h3>
    <div class="tiny"><b>Null hypothesis (H0):</b> ${esc(h.null)}</div>
    <div class="ri-tagrow">${h.concepts.map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}<span class="ri-tag">${h.support} supporting record${h.support===1?'':'s'}</span></div>
    <div class="hyp-more" hidden>
      <div><b>Alternative hypotheses (H1 variants):</b><ul class="hyp-alt">${alts.map(a=>`<li><b>${a.label}:</b> ${esc(a.text)} <span class="tiny">(${esc(a.basis)})</span></li>`).join('')}</ul></div>
      <div><b>Variables:</b> ${vars}</div>
      <div><b>Falsification:</b> Reject H1 if the association is not detectable in the target sample at the chosen significance level, or if it disappears once the alternatives above are controlled for.</div>
      <div><b>Supporting records:</b> ${ps.map(p=>`<button class="ghost" type="button" onclick="detail(${Number(p)})">${esc(recObj(p).title||'Untitled')}</button>`).join(' ')||'none'}</div>
    </div></div>`;
}
function hypToggle(btn){const m=btn.parentElement.querySelector('.hyp-more');if(!m)return;const open=m.hidden;m.hidden=!open;btn.textContent=open?'−':'+';btn.setAttribute('aria-expanded',String(open));btn.title=open?'Hide details':'Show alternative hypotheses, variables and falsification criteria'}
