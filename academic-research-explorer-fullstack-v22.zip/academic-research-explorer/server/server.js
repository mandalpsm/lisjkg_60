// Express back end: serves the built app and a small JSON API (dataset, drafts, health).
const express=require('express'),fs=require('fs'),path=require('path'),zlib=require('zlib');
const root=path.join(__dirname,'..'),app=express(),PORT=process.env.PORT||3000,DRAFTS=path.join(root,'data/drafts.json');
app.use(express.json({limit:'5mb'}));
app.get('/api/health',(q,r)=>r.json({ok:true}));
// decoded bibliographic dataset: { m: metadata, r: records[] }
let cache;app.get('/api/dataset',(q,r)=>{
  if(!cache){const t=fs.readFileSync(path.join(root,'data/embedded-dataset.txt'),'utf8').trim();
    cache=t.startsWith('GZB64:')?JSON.parse(zlib.gunzipSync(Buffer.from(t.slice(6),'base64'))):JSON.parse(t)}
  r.json(cache)});
// server-side literature review drafts
const rd=()=>{try{return JSON.parse(fs.readFileSync(DRAFTS,'utf8'))}catch{return{}}};
app.get('/api/drafts',(q,r)=>r.json(Object.keys(rd())));
app.get('/api/drafts/:id',(q,r)=>{const d=rd()[q.params.id];d?r.json(d):r.sendStatus(404)});
app.put('/api/drafts/:id',(q,r)=>{const d=rd();d[q.params.id]=q.body;fs.writeFileSync(DRAFTS,JSON.stringify(d));r.json({saved:q.params.id})});
app.delete('/api/drafts/:id',(q,r)=>{const d=rd();delete d[q.params.id];fs.writeFileSync(DRAFTS,JSON.stringify(d));r.sendStatus(204)});
app.use(express.static(path.join(root,'dist')));
app.listen(PORT,()=>console.log(`Academic Research Explorer on http://localhost:${PORT}`));
