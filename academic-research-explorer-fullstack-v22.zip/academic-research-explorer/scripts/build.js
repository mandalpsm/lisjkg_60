// Re-assembles src/ into one self-contained dist/index.html (the original single-file app).
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
let t=fs.readFileSync(path.join(root,'src/index.template.html'),'utf8');
t=t.replace(/<!--@(css|js|data):([^|]+)\|([^>]*?)-->/g,(m,k,f,attrs)=>{
  const dir=k==='data'?'data':'src/'+k,body=fs.readFileSync(path.join(root,dir,f),'utf8'),a=attrs?' '+attrs:'';
  return k==='css'?`<style${a}>${body}</style>`:`<script${a}>${body}</script>`;});
fs.mkdirSync(path.join(root,'dist'),{recursive:true});
fs.writeFileSync(path.join(root,'dist/index.html'),t);
console.log('built dist/index.html',(t.length/1e6).toFixed(1)+' MB');
